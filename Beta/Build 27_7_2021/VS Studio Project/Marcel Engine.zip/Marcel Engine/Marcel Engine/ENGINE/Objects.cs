﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Engine
{
    ///<summary>
    ///Random data for Objects.
    ///<para /> Has an Object-Type Dictionary
    ///</summary>
    class ObjectMiscData
    {
        private Dictionary<string, int> ObjectTypes;
        public ObjectMiscData ()
        {
            InitialiseObjectTypeList();
        }
        ///<summary>
        ///Here you can get the Typenumber of an Object with the Type String. (example: "Player" is typenum 1)
        ///</summary>
        public int GetObjectTypeNumber (string t)
        {
            return ObjectTypes[t];
        }

        private void InitialiseObjectTypeList ()
        {
            ObjectTypes = new Dictionary<string, int>
            {
                { "Player", 1 },
                { "Text", 2 }
            };
        }
    }

    ///<summary>
    ///A Scene.
    ///</summary>
    class Scene
    {
        public string SceneName;
        public List<Object> SceneObjects;
        public Scene ()
        {
            SceneObjects = new List<Object>();
            SceneName = "";
        }
        public Scene (string _name)
        {
            SceneObjects = new List<Object>();
            SceneName = _name;
        }
        ///<summary>
        ///Generates a clone of this Scene.
        ///</summary>
        public Scene Clone()
        {
            return (Scene)this.MemberwiseClone();
        }
    }

    ///<summary>
    ///Objects go brrrrrrr
    ///</summary>
    class Object
    {
        ///<summary>
        ///A Player Object.
        ///</summary>
        public PlayerObject Player { get; set; }
        ///<summary>
        ///A Text Object.
        ///</summary>
        public TextObject Text { get; set; }
        ///<summary>
        ///Sets the active Subobject of this Object. (Look at the OBJ_MISC class!)
        ///</summary>
        public int ActiveObjectType { get; set; }
        ///<summary>
        ///Sets the layer that the Object is on. (0 is backround. 1 is infront of 0 and 10 is infront of 5 etc)
        ///</summary>
        public int Layer { get; set; }
        ///<summary>
        ///Decides if the Object gets shown
        ///</summary>
        public bool Shown { get; set; }
        ///<summary>
        ///The position of the Object. It is a tuple.
        ///</summary>s
        public (int x, int y) Position { get; set; }

        ///<summary>
        ///Decides if the Object gets updated next frame.
        ///</summary>
        public bool UpdateOnNextFrame { get; set; }

        public Object()
        {
            UpdateOnNextFrame = true;
            ActiveObjectType = -1;
            Player = new PlayerObject(this);
            Text = new TextObject(this);
            Layer = 0;
            Shown = true;
            Position = (0, 0);
        }
        ///<summary>
        ///Updates the object in the screen buffer on the next frame.
        ///</summary>
        public void Update()
        {
            UpdateOnNextFrame = true;
            if (ActiveObjectType == 2)
            {
                Text.UpdateText();
            }
        }
        ///<summary>
        ///Moves the Object. (Requires a tuple (x, y))
        ///</summary>
        public void Move((int x, int y) pos)
        {
            Position = (Position.x + pos.x, Position.y + pos.y);
            Update();
        }
        ///<summary>
        ///Moves the Object on the X-Axis.
        ///</summary>
        public void MoveX(int amount)
        {
            Position = (Position.x + amount, Position.y);
            Update();
        }
        ///<summary>
        ///Moves the Object on the Y-Axis.
        ///</summary>
        public void MoveY(int amount)
        {
            Position = (Position.x, Position.y + amount);
            Update();
        }

        ///<summary>
        ///Generates a clone of this Object.
        ///</summary>
        public Object Clone ()
        {
            Object temp = (Object)this.MemberwiseClone();
            temp.Player = temp.Player.Clone();
            temp.Text = temp.Text.Clone();
            return temp;
        }


        ///<summary>
        ///A Player Object. It can show Sprites and animate them and has an inbuilt Sprite Library.
        ///</summary>
        public class PlayerObject
        {
            ///<summary>
            ///Sets the active shown Sprite. (If its not being animated)
            ///</summary>
            public Graphics.Sprite ActiveSprite { get; set; }
            ///<summary>
            ///Sets the active shown Sprite. (If its being animated)
            ///</summary>
            public Graphics.Sprite ActiveAnimationSprite { get; set; }
            ///<summary>
            ///A Sprite Library where you can add Sprites into, if you want to have different sprites saved in one Object.
            ///</summary>
            public Graphics.Sprite_Lib SpriteLibrary { get; set; }

            ///<summary>
            ///Parent Object.
            ///</summary>
            public Object Parent { get; set; }

            ///<summary>
            ///The rotation of the Player.
            ///</summary>
            public double Rotation;
            ///<summary>
            ///The scale of the Player.
            ///</summary>
            public double Scale;

            ///<summary>
            ///Tells if the Player Object has to be animated
            ///</summary>
            public bool IsSpriteAnimated;
            ///<summary>
            ///Here are the spriteframes that should be animated. You can add normal sprites to it.
            ///</summary>
            public Graphics.Sprite_Lib AnimationLibrary { get; set; }
            ///<summary>
            ///The frame the animation is currently on.
            ///</summary>
            public int AnimationFrame;
            ///<summary>
            ///Sets how many frames should pass until the animation goes to the next frame. Defaults to 1
            ///</summary>
            public int AnimationSpeed;

            private int _animationSubCounter;


            ///<summary>
            ///Turns to an Object.
            ///</summary>
            public void TurnTo(Object obj)
            {
                TurnTo(obj.Position);
            }
            ///<summary>
            ///Turns to a position.
            ///</summary>
            public void TurnTo((int x, int y) pos)
            {
                (int x, int y) pos_relative;
                pos_relative = ((pos.x - Parent.Position.x),(pos.y - Parent.Position.y));
                double oldRot = Rotation;
                Rotation = GetAngle(pos_relative);
                if (Rotation != oldRot)
                {
                    UpdateSprite();
                    Parent.UpdateOnNextFrame = true;
                }
            }


            private double GetAngle((int x, int y) pos)
            {
                double conv = 180 / Math.PI;
                double radius = Math.Sqrt(pos.x * pos.x + pos.y * pos.y);

                double angle = Math.Asin(pos.y / radius) * conv;
                if (pos.x < 0)
                {
                    angle = 180 - angle;
                }
                return angle;
            }

            public PlayerObject(Object parent_)
            {
                Parent = parent_;
                Rotation = 0;
                Scale = 1;
                SpriteLibrary = new Graphics.Sprite_Lib();
                ActiveSprite = new Graphics.Sprite();
                ActiveAnimationSprite = new Graphics.Sprite();

                IsSpriteAnimated = false;
                AnimationLibrary = new Graphics.Sprite_Lib();
                AnimationFrame = 0;
                AnimationSpeed = 1;
                _animationSubCounter = 0;
             }
            ///<summary>
            ///Tells the animation part that one frame has passed.
            ///</summary>
            public void UpdateAnimation()
            {
                if (_animationSubCounter >= AnimationSpeed)
                {
                    ActiveAnimationSprite.SourceImageData = AnimationLibrary.Sprites.ElementAt(AnimationFrame).Value.SourceImageData;
                    ActiveAnimationSprite.Rotation = Rotation;
                    ActiveAnimationSprite.Scale = Scale;
                    ActiveAnimationSprite.UpdateImage();
                    AnimationFrame++;
                    if (AnimationFrame >= AnimationLibrary.Sprites.Count)
                    {
                        AnimationFrame = 0;
                    }
                }
                //Update_Sprite();
                _animationSubCounter++;
            }

            ///<summary>
            ///Updates the currently displayed Sprite. (Rotation and Scaling)
            ///</summary>
            public void UpdateSprite()
            {
                ActiveSprite.Rotation = Rotation;
                ActiveSprite.Scale = Scale;
                ActiveSprite.UpdateImage();
            }

            ///<summary>
            ///Generates a clone of this Playerobject.
            ///</summary>
            public PlayerObject Clone()
            {
                PlayerObject temp = (PlayerObject)this.MemberwiseClone();
                temp.ActiveAnimationSprite = temp.ActiveAnimationSprite.Clone();
                temp.ActiveSprite = temp.ActiveSprite.Clone();
                temp.AnimationLibrary = temp.AnimationLibrary.Clone();
                temp.SpriteLibrary = temp.SpriteLibrary.Clone();
                return temp;
            }
        }

        ///<summary>
        ///A simple Text Object. It can show text.
        ///</summary>
        public class TextObject
        {
            ///<summary>
            ///Parent Object.
            ///</summary>
            public Object Parent { get; set; }
            ///<summary>
            ///Text to be displayed.
            ///</summary>
            public string Text { get; set; }
            ///<summary>
            ///Colour of the text.
            ///</summary>
            public (int col_b, int col_f) TextColour { get; set; }
            ///<summary>
            ///Charpixeldata (Just the data of the "sprite")
            ///</summary>
            public List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> CharPixeldata;
            ///<summary>
            ///Decides if the backroundcolour of the text gets ignored and replaced by the pixel it is on.
            ///</summary>
            public bool IsBackroundTransparent { get; set; }

            public TextObject(Object parent_)
            {
                Parent = parent_;
                IsBackroundTransparent = false;
                TextColour = (0,10);
                Text = "";
                CharPixeldata = new List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)>();
            }
            ///<summary>
            ///Updates the "Sprite" data of the text. Do this if you want to update the changes of text.
            ///</summary>
            public void UpdateText()
            {
                CharPixeldata = new List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)>();
                int i = 0;
                foreach (char x in Text)
                {
                    CharPixeldata.Add((x,(0, TextColour.col_b, TextColour.col_f),(i, 0))); 
                    //Console.Title = $"TEST: {(char)x}";
                    i++;
                }
            }

            ///<summary>
            ///Generates a clone of this Textobject.
            ///</summary>
            public TextObject Clone()
            {
                return (TextObject)this.MemberwiseClone();
            }
        }
    }
}
