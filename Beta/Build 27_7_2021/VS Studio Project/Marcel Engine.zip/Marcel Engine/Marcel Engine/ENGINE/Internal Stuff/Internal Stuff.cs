﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;

namespace Engine
{
    ///<summary>
    ///Internal Stuff
    ///</summary>
    class Internals
    {
        ///<summary>
        ///Boot Object (Basically the Splashscreen)
        ///</summary>
        public Object SplashscreenObject { get; }
        public bool FastBoot { get; set; }
        private Graphics.Sprite BootSprite { get; }
        public Internals()
        {
            FastBoot = false;
            string image_dir = "Engine\\Internals\\";
            image_dir += "Splashscreen.mesf";
            BootSprite = new Graphics.Sprite(image_dir, false);
            SplashscreenObject = new Object
            {
                ActiveObjectType = 1
            };
            SplashscreenObject.Player.ActiveSprite = BootSprite;
            SplashscreenObject.Position = (5, 5);
        }

        public class Debug_Logger
        {
            static readonly int MaxRetryCount = 6;
            public Debug_Logger()
            {
                Clear(0);

                Process p = new Process();
                p.StartInfo.WorkingDirectory = "Engine\\Internals\\Debug";
                p.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Normal;
                p.StartInfo.FileName = "logreader.exe";
                p.Start();
                //System.Diagnostics.Process.Start("Engine\\Internals\\Debug\\logreader.exe", "");
            }

            public void Wait(int _t)
            {
                if (_t < MaxRetryCount)
                {
                    try
                    {
                        StreamReader reader = new StreamReader("Engine\\Internals\\Debug\\Debug.out");
                        bool temp = !reader.EndOfStream;
                        reader.Close();
                        if (temp)
                        {
                            System.Threading.Thread.Sleep(10);
                            Wait(_t + 1);
                        }
                    }
                    catch //(Exception t)
                    {
                        System.Threading.Thread.Sleep(10);
                        Wait(_t + 1);
                    }
                }
            }


            public void Log(string data)
            {
                Log_(data, 0);
            }

            private void Log_(string data, int _t)
            {
                if (_t < MaxRetryCount)
                {
                    try
                    {
                        Wait(0);
                        StreamWriter writer = new StreamWriter("Engine\\Internals\\Debug\\Debug.out");
                        writer.WriteLine(data);
                        writer.Close();
                    }
                    catch //(Exception t)
                    {
                        Log_(data, _t + 1);
                    }
                }
            }

            static void Clear(int _t)
            {
                if (_t < MaxRetryCount)
                {
                    try
                    {
                        StreamWriter writer = new StreamWriter("Engine\\Internals\\Debug\\Debug.out");
                        writer.Close();
                    }
                    catch //(Exception t)
                    {
                        Clear(_t + 1);
                    }
                }
            }

            public void Set_title(string name)
            {
                Log("#TITLE " + name);
            }
        }
    }





}
