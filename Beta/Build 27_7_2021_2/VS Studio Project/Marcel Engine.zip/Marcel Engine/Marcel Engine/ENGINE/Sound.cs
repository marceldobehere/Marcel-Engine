﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Media;
using System.Threading;
using System.Windows;

namespace Engine
{
    ///<summary>
    ///Sound Player
    ///</summary>
    class Sound
    {
        ///<summary>
        ///The Filename of the Object.
        ///</summary>
        public string Filename { get; set; }

        private Thread PlayThread;

        private TimeSpan Zero = new TimeSpan();

        private bool playing { get; set; }

        private bool looping;

        private bool stop;

        public int MaximumQueueLength { get; set; }

        private int queue;

        public Sound(string filename)
        {
            Filename = filename;
            playing = false;
            looping = false;
            stop = false;
            MaximumQueueLength = 10;
            queue = 0;
        }
        public void New_File(string filename)
        {
            Stop();
            Filename = filename;
        }


        private void __Play()
        {
            MediaPlayer test = new MediaPlayer();
            test.Open(new Uri(Filename, UriKind.RelativeOrAbsolute));
            while (test.NaturalDuration == Duration.Automatic)
            {
            }
            if (looping)
            {
                while (true)
                {
                    test.Play();
                    Thread.Sleep((int)Math.Round(test.NaturalDuration.TimeSpan.TotalMilliseconds));
                    test.Position = Zero;
                }
            }
            else
            {
                test.Play();
                Thread.Sleep((int)Math.Round(test.NaturalDuration.TimeSpan.TotalMilliseconds));
                playing = false;
                queue--;
            }
        }
        private void _Play()
        {
            queue++;
            if (playing && looping)
            {
                queue--;
                return;
            }
            else
            {
                if (playing && !looping)
                {
                    while (playing && !stop)
                    {
                        Thread.Sleep(5);
                    }
                }
            }
            if (!playing && !stop)
            {
                playing = true;
                PlayThread = new Thread(() => __Play());
                PlayThread.IsBackground = true;
                try
                {
                    PlayThread.Start();
                }
                catch
                {
                    Stop();
                    playing = false;
                    queue--;
                }
            }
        }

        public void Play(bool loop)
        {
            looping = loop;
            if (queue < MaximumQueueLength)
            {
            new Thread(() => _Play()).Start();
            }
        }



        public void Stop()
        {

            stop = true;
            Thread.Sleep(5);
            PlayThread.Abort();
            playing = false;
            looping = false;
            queue = 0;
            PlayThread.Abort();
            Thread.Sleep(5);
            stop = false;
        }


    }
}
