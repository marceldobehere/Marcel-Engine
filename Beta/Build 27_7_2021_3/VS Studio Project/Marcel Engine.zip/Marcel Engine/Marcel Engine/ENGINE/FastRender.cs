﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;

namespace Engine
{
    ///<summary>
    ///A Clas designed for really fast rendering of the console.
    ///<para /> Code modified to fit the engine. 
    ///<para /> Code from: https://stackoverflow.com/users/314028/chris-taylor (https://stackoverflow.com/questions/2754518/how-can-i-write-fast-colored-output-to-console)
    ///</summary>
    class FastConsoleRenderer
    {
        ///<summary>
        ///brightness of the colours go brrrrrr
        ///</summary>
        //static readonly char[] CharColours = { '░', '▒', '▓' };
        static public readonly char[] CharColours = { (char)176, (char)177, (char)178 };
        //░▒▓ 176 177 178

        static public readonly string CONVERSION_CHARS = " ☺☻♥♦♣♠•◘○◙♂♀♪♫☼►◄↕‼¶§▬↨↑↓→←∟↔▲▼ !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~⌂ÇüéâäàåçêëèïîìÄÅÉæÆôöòûùÿÖÜø£Ø×ƒáíóúñÑªº¿®¬½¼¡«»░▒▓│┤ÁÂÀ©╣║╗╝¢¥┐└┴┬├─┼ãÃ╚╔╩╦╠═╬¤ðÐÊËÈıÍÎÏ┘┌█▄¦Ì▀ÓßÔÒõÕµþÞÚÛÙýÝ¯´­±‗¾¶§÷¸°¨·¹³²■ ";

        ///<summary>
        ///The colour list. Basically just all consolecolours but with an index
        ///</summary>
        static readonly System.ConsoleColor[] ConsoleColours =
            {
                System.ConsoleColor.Black,
                System.ConsoleColor.Blue,
                System.ConsoleColor.Cyan,
                System.ConsoleColor.DarkBlue,
                System.ConsoleColor.DarkCyan,
                System.ConsoleColor.DarkGray,
                System.ConsoleColor.DarkGreen,
                System.ConsoleColor.DarkMagenta,
                System.ConsoleColor.DarkRed,
                System.ConsoleColor.DarkYellow,
                System.ConsoleColor.Gray,
                System.ConsoleColor.Green,
                System.ConsoleColor.Magenta,
                System.ConsoleColor.Red,
                System.ConsoleColor.White,
                System.ConsoleColor.Yellow,
            };

        static int ConvConsoleNum(int input)
        {
            //int x = (int)ConsoleColours[input];// ConsoleColor.Red;
            return (int)ConsoleColours[input];
        }


        static SafeFileHandle _handle;
        public FastConsoleRenderer()
        {
            Console.OutputEncoding = System.Text.Encoding.Unicode;
            _handle = FastConsoleRenderer.CreateFile("CONOUT$", 0x40000000, 2, IntPtr.Zero, FileMode.Open, 0, IntPtr.Zero);
        }





        public struct Pixel
        {
            public char text;
            public byte backgroundColour;
            public byte foregroundColour;
        }


        //List<(char chr, (int bri, int col_b, int col_f))>[,] screen


        public void WriteScreen(ref List<(char chr, (int bri, int col_b, int col_f) col)>[,] screen)
        {
            if (!_handle.IsInvalid)
            {
                FastConsoleRenderer.CharInfo[] buf = new FastConsoleRenderer.CharInfo[screen.Length*2];
                FastConsoleRenderer.SmallRect rect = new FastConsoleRenderer.SmallRect() { Left = 0, Top = 0, Right = (short)(screen.GetLength(0)*2), Bottom = (short)screen.GetLength(1) };

                int pos = 0;
                for (int y = 0; y < screen.GetLength(1); y++)
                {
                    for (int x = 0; x < screen.GetLength(0); x++)
                    {
                        //ConvConsoleNum()
                        

                        (char chr, (int bri, int col_b, int col_f) col) temp_pixel = screen[x, y][screen[x, y].Count - 1];
                        //screen[x, y];
                        short attr = (short)(ConvConsoleNum(temp_pixel.col.col_f) | (ConvConsoleNum(temp_pixel.col.col_b) << 4));
                        buf[pos].Attributes = attr;
                        if (temp_pixel.chr == 0)
                        {
                            //System.Text.Encoding.Convert();

                            //System.Text.Encoding.Unicode.

                            buf[pos].CharUnion_.UnicodeChar = CharColours[temp_pixel.col.bri];
                            pos++;
                            buf[pos] = buf[pos - 1];
                            pos++;
                        }
                        else
                        {
                            buf[pos].CharUnion_.UnicodeChar = (char)CONVERSION_CHARS.IndexOf(temp_pixel.chr);
                            pos++;
                            buf[pos].Attributes = attr;
                            buf[pos].CharUnion_.UnicodeChar = ' ';
                            pos++;
                        }
                    }
                }

                FastConsoleRenderer.WriteConsoleOutput(_handle, buf,
                          new FastConsoleRenderer.Coord() { X = (short)(screen.GetLength(0)*2), Y = (short)screen.GetLength(1) },
                          new FastConsoleRenderer.Coord() { X = 0, Y = 0 },
                          ref rect);
            }
            else
            {
                Console.WriteLine("Invalid Handle!");
            }
        }



        public void WriteScreen(Pixel[,] screen)
        {
            if (!_handle.IsInvalid)
            {
                FastConsoleRenderer.CharInfo[] buf = new FastConsoleRenderer.CharInfo[screen.Length];
                FastConsoleRenderer.SmallRect rect = new FastConsoleRenderer.SmallRect() { Left = 0, Top = 0, Right = (short)screen.GetLength(0), Bottom = (short)screen.GetLength(1) };

                int pos = 0;
                for (int y = 0; y < screen.GetLength(1); y++)
                {
                    for (int x = 0; x < screen.GetLength(0); x++)
                    {
                        //screen[x, y];
                        buf[pos].Attributes = (short)(screen[x, y].foregroundColour | (screen[x, y].backgroundColour << 4));
                        buf[pos].CharUnion_.UnicodeChar = screen[x, y].text;
                        pos++;
                    }
                }

                FastConsoleRenderer.WriteConsoleOutput(_handle, buf,
                          new FastConsoleRenderer.Coord() { X = (short)screen.GetLength(0), Y = (short)screen.GetLength(1) },
                          new FastConsoleRenderer.Coord() { X = 0, Y = 0 },
                          ref rect);
            }
            else
            {
                Console.WriteLine("Invalid Handle!");
            }
        }


        public void WriteScreen(ref CharInfo[] screen, (int x, int y) dimensions)
        {
            if (!_handle.IsInvalid)
            {
                FastConsoleRenderer.SmallRect rect = new FastConsoleRenderer.SmallRect() { Left = 0, Top = 0, Right = (short)dimensions.x, Bottom = (short)dimensions.y };

                FastConsoleRenderer.WriteConsoleOutput(_handle, screen,
                          new FastConsoleRenderer.Coord() { X = (short)dimensions.x, Y = (short)dimensions.y },
                          new FastConsoleRenderer.Coord() { X = 0, Y = 0 },
                          ref rect);
            }
            else
            {
                Console.WriteLine("Invalid Handle!");
            }
        }


        //(int x1, int y1, int x2, int y2)

        public void WriteScreen(ref CharInfo[] screen, (int x1, int y1, int x2, int y2) border, (int x, int y) dimensions)
        {
            if (!_handle.IsInvalid)
            {
                //Console.Clear();
                (short x, short y) bordersize = ((short)((border.x2 - border.x1) + 1), (short)((border.y2 - border.y1) + 1));

                FastConsoleRenderer.SmallRect rect = new FastConsoleRenderer.SmallRect() { Left = (short)border.x1, Top = (short)border.y1, Right = (short)border.x2, Bottom = (short)border.y2 };

                //FastConsoleRenderer.SmallRect rect = new FastConsoleRenderer.SmallRect() { Left = 0, Top = 0, Right = (short)(bordersize.x - 1), Bottom = (short)(bordersize.y - 1) };


                CharInfo[] buffer = new CharInfo[(bordersize.x) * bordersize.y];
                int pos = 0;
                /*for (pos = 0; pos < bordersize.x * bordersize.y; pos++)
                {
                    buffer[pos] = new FastConsoleRenderer.CharInfo { Attributes = (short)(0 | (15 << 4)), CharUnion_ = new FastConsoleRenderer.CharUnion { UnicodeChar = 'X' } };
                }*/
                
                for (int y = border.y1; y <= border.y2; y++)
                {
                    for (int x = border.x1; x <= border.x2; x++)
                    {
                        buffer[pos] = screen[x + y * dimensions.x];
                        //buffer[pos] = new FastConsoleRenderer.CharInfo { Attributes = (short)(0 | (((pos)%16) << 4)), CharUnion_ = new FastConsoleRenderer.CharUnion { UnicodeChar = 'X' } };
                        pos++;
                    }
                }


                FastConsoleRenderer.WriteConsoleOutput(_handle, buffer,
                          new FastConsoleRenderer.Coord() { X = (short)(bordersize.x ), Y = (short)(bordersize.y) },
                          new FastConsoleRenderer.Coord() { X = 0, Y = 0 },
                          ref rect);
                //int xa = int.Parse(Console.ReadLine());
                /*
                                 FastConsoleRenderer.WriteConsoleOutput(_handle, buffer,
                          new FastConsoleRenderer.Coord() { X = bordersize.x, Y = bordersize.y },
                          new FastConsoleRenderer.Coord() { X = (short)border.x1, Y = (short)border.y1 },
                          ref rect);
                 */
                pos++;
            }
            else
            {
                Console.WriteLine("Invalid Handle!");
            }
        }


        [DllImport("Kernel32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        static public extern SafeFileHandle CreateFile(
            string fileName,
            [MarshalAs(UnmanagedType.U4)] uint fileAccess,
            [MarshalAs(UnmanagedType.U4)] uint fileShare,
            IntPtr securityAttributes,
            [MarshalAs(UnmanagedType.U4)] FileMode creationDisposition,
            [MarshalAs(UnmanagedType.U4)] int flags,
            IntPtr template);

        [DllImport("kernel32.dll", SetLastError = true)]
        static public extern bool WriteConsoleOutput(
          SafeFileHandle hConsoleOutput,
          CharInfo[] lpBuffer,
          Coord dwBufferSize,
          Coord dwBufferCoord,
          ref SmallRect lpWriteRegion);

        [StructLayout(LayoutKind.Sequential)]
        public struct Coord
        {
            public short X;
            public short Y;

            public Coord(short X, short Y)
            {
                this.X = X;
                this.Y = Y;
            }
        };

        [StructLayout(LayoutKind.Explicit)]
        public struct CharUnion
        {
            [FieldOffset(0)] public byte AsciiChar;
            [FieldOffset(0)] public char UnicodeChar;
        }

        [StructLayout(LayoutKind.Explicit)]
        public struct CharInfo
        {
            [FieldOffset(0)] public CharUnion CharUnion_;
            [FieldOffset(2)] public short Attributes;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct SmallRect
        {
            public short Left;
            public short Top;
            public short Right;
            public short Bottom;
        }











    }


}
