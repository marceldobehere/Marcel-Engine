﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;



namespace Engine
{
    ///<summary>
    ///Screen go brrrrrrrr and oooof
    ///</summary>
    class Screen
    {
        ///<summary>
        ///Don't ask
        ///</summary>
        [DllImport("user32.dll")]
        public static extern bool ShowWindow(System.IntPtr hWnd, int cmdShow);
        ///<summary>
        ///Maxmizes the Window
        ///</summary>
        private static void Maximize()
        {
            Process p = Process.GetCurrentProcess();
            ShowWindow(p.MainWindowHandle, 3);
        }

        ///<summary>
        ///brightness of the colours go brrrrrr
        ///</summary>
        static readonly string[] CharColours = { "░░", "▒▒", "▓▓" };
        ///<summary>
        ///The colour list. Basically just all consolecolours but with an index
        ///</summary>
        static readonly System.ConsoleColor[] ConsoleColours =
            {
                System.ConsoleColor.Black,
                System.ConsoleColor.Blue,
                System.ConsoleColor.Cyan,
                System.ConsoleColor.DarkBlue,
                System.ConsoleColor.DarkCyan,
                System.ConsoleColor.DarkGray,
                System.ConsoleColor.DarkGreen,
                System.ConsoleColor.DarkMagenta,
                System.ConsoleColor.DarkRed,
                System.ConsoleColor.DarkYellow,
                System.ConsoleColor.Gray,
                System.ConsoleColor.Green,
                System.ConsoleColor.Magenta,
                System.ConsoleColor.Red,
                System.ConsoleColor.White,
                System.ConsoleColor.Yellow,
            };

        static int ConvConsoleNum(int input)
        {
            //int x = (int)ConsoleColours[input];// ConsoleColor.Red;
            return (int)ConsoleColours[input];
        }



        ///<summary>
        ///Size of the Window
        ///</summary>
        public static (int x, int y, int size) WindowSize;
        ///<summary>
        ///fps count
        ///</summary>
        public static double FPS { get; set; }
        ///<summary>
        ///The position of the Camera. It is a tuple.
        ///</summary>s
        public (int x, int y) CameraPosition { get; set; }

        ///<summary>
        ///Updates the title with the current fps
        ///</summary>
        public void UpdateFPS(double fps_)
        {
            FPS = fps_;
            Console.Title = $"Marcel Engine - FPS: {Math.Round(FPS, 1)}";
        }


        ///<summary>
        ///Screendata.
        ///</summary>
        List<(char chr, (int bri, int col_b, int col_f))>[,] ScreenData;
        ///<summary>
        ///Screendata Objects.
        ///</summary>
        List<Object>[,] ScreenDataObjects;

        ///<summary>
        ///The Screen Buffer.
        ///</summary>
        FastConsoleRenderer.CharInfo[] ActualScreenBuffer;


        ///<summary>
        ///Just an Object that claims all the backroundpixels.
        ///</summary>
        private readonly Object BackroundObject;

        ///<summary>
        ///Dictionary, where each object stores all Pixel position that it covers.
        ///</summary>
        private Dictionary<Object, List<(int x, int y)>> ObjectPixelPositions;

        static FastConsoleRenderer fastScreenRenderer;

        private Internals.Debug_Logger logger;


        ///<summary>
        ///Initialises the screen with a size
        ///</summary>
        public Screen((int x, int y, int size) size, bool maximize, string font)
        {
            FPS = 1;
            Console.Title = "Marcel Engine";
            Console.Clear();
            Console.WriteLine("Marcel Engine loading...");
            Console.SetWindowSize(1, 1);
            ConsoleHelper.SetCurrentFont(font, (short)size.size);
            if (maximize)
            {
                Maximize();
            }
            if (size.x > Console.LargestWindowWidth)
            {
                Console.WriteLine($"Decreasing X-Size from {size.x} to {Console.LargestWindowWidth}.");
                size.x = Console.LargestWindowWidth;
                //Console.ReadLine();
            }
            if (size.y > Console.LargestWindowHeight)
            {
                Console.WriteLine($"Decreasing Y-Size from {size.y} to {Console.LargestWindowHeight}.");
                size.y = Console.LargestWindowHeight;
                //Console.ReadLine();
            }
            WindowSize = size;

            CameraPosition = (0, 0);

            BackroundObject = new Object();
            //update_pos = new List<((char chr, int bri, int col_b, int col_f) coldata, (int x, int y) pos)>();
            ClearScreenMemory();

            fastScreenRenderer = new FastConsoleRenderer();

            //logger = new Internals.Debug_Logger();
            //logger.Set_title("Test Hitboxes");


            Console.CursorVisible = false;
            //Console.ReadLine();
            ClearScreen();
        }


        ///<summary>
        ///Clears the Screen Memory.
        ///</summary>
        private void ClearScreenMemory()
        {
            ObjectPixelPositions = new Dictionary<Object, List<(int x, int y)>>();
            _updateBorder = new List<(int x1, int y1, int x2, int y2)>();
            ActualScreenBuffer = new FastConsoleRenderer.CharInfo[WindowSize.x * 2 * WindowSize.y];
            ScreenData = new List<(char chr, (int bri, int col_b, int col_f))>[WindowSize.x, WindowSize.y];
            ScreenDataObjects = new List<Object>[WindowSize.x, WindowSize.y];
            int pos = 0;
            for (int y = 0; y < WindowSize.y; y++)
            {
                for (int x = 0; x < WindowSize.x; x++)
                {
                    ScreenData[x, y] = new List<(char chr, (int bri, int col_b, int col_f))>() { (' ', (0, 0, 0)) };
                    ScreenDataObjects[x, y] = new List<Object>() { BackroundObject };
                    //buf[pos].Char.UnicodeChar = screen[x, y].text;
                    ActualScreenBuffer[pos] = new FastConsoleRenderer.CharInfo { Attributes = (short)(0 | (0 << 4)), CharUnion_ = new FastConsoleRenderer.CharUnion { UnicodeChar = ' ' } };
                    pos++;
                    ActualScreenBuffer[pos] = new FastConsoleRenderer.CharInfo { Attributes = (short)(0 | (0 << 4)), CharUnion_ = new FastConsoleRenderer.CharUnion { UnicodeChar = ' ' } };
                    pos++;
                }
            }
        }


        ///<summary>
        ///Clears the Screen.
        ///</summary>
        public void ClearScreenandMemory()
        {
            ObjectPixelPositions = new Dictionary<Object, List<(int x, int y)>>();
            _updateBorder = new List<(int x1, int y1, int x2, int y2)>();
            ActualScreenBuffer = new FastConsoleRenderer.CharInfo[WindowSize.x * 2 * WindowSize.y];
            ScreenData = new List<(char chr, (int bri, int col_b, int col_f))>[WindowSize.x, WindowSize.y];
            ScreenDataObjects = new List<Object>[WindowSize.x, WindowSize.y];
            int pos = 0;
            for (int y = 0; y < WindowSize.y; y++)
            {
                for (int x = 0; x < WindowSize.x; x++)
                {
                    ScreenData[x, y] = new List<(char chr, (int bri, int col_b, int col_f))>() { (' ', (0, 0, 0)) };
                    ScreenDataObjects[x, y] = new List<Object>() { BackroundObject };
                    //buf[pos].Char.UnicodeChar = screen[x, y].text;
                    ActualScreenBuffer[pos] = new FastConsoleRenderer.CharInfo { Attributes = (short)(0 | (0 << 4)), CharUnion_ = new FastConsoleRenderer.CharUnion { UnicodeChar = ' ' } };
                    pos++;
                    ActualScreenBuffer[pos] = new FastConsoleRenderer.CharInfo { Attributes = (short)(0 | (0 << 4)), CharUnion_ = new FastConsoleRenderer.CharUnion { UnicodeChar = ' ' } };
                    pos++;
                }
            }
            Frame();
        }





        private (char chr, (int bri, int col_b, int col_f)) GetPixelAt((int x, int y) pos)
        {
            if (!((pos.x < 0) || (pos.y < 0) || (pos.x >= WindowSize.x) || (pos.y >= WindowSize.y)))
            {
                (char chr, (int bri, int col_b, int col_f)) x = ScreenData[pos.x, pos.y][ScreenData[pos.x, pos.y].Count - 1];
                return (x.chr, (x.Item2.bri, x.Item2.col_b, x.Item2.col_f));
            }
            return ((char)0, (0, 0, 0));
        }

        public void UpdatePixelAt((int x, int y) pos)
        {
            int buff_pos = pos.x * 2 + (pos.y * WindowSize.x * 2);

            (char chr, (int bri, int col_b, int col_f) col) x = ScreenData[pos.x, pos.y][ScreenData[pos.x, pos.y].Count - 1];

            //screen[x, y];
            short attr = (short)(ConvConsoleNum(x.col.col_f) | (ConvConsoleNum(x.col.col_b) << 4));
            ActualScreenBuffer[buff_pos].Attributes = attr;
            if (x.chr == 0)
            {
                //System.Text.Encoding.Convert();

                //System.Text.Encoding.Unicode.

                ActualScreenBuffer[buff_pos].CharUnion_.UnicodeChar = FastConsoleRenderer.CharColours[x.col.bri];
                buff_pos++;
                ActualScreenBuffer[buff_pos] = ActualScreenBuffer[buff_pos - 1];
            }
            else
            {
                ActualScreenBuffer[buff_pos].CharUnion_.UnicodeChar = (char)FastConsoleRenderer.CONVERSION_CHARS.IndexOf(x.chr);
                buff_pos++;
                ActualScreenBuffer[buff_pos].Attributes = attr;
                ActualScreenBuffer[buff_pos].CharUnion_.UnicodeChar = ' ';
            }
        }


        private void SetPixel((char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos) data, Object obj)
        {
            if (!((data.pos.x < 0) || (data.pos.y < 0) || (data.pos.x >= WindowSize.x) || (data.pos.y >= WindowSize.y)))
            {
                if (ScreenDataObjects[data.pos.x, data.pos.y].Contains(obj))
                {
                    int indx2 = ScreenDataObjects[data.pos.x, data.pos.y].IndexOf(obj);
                    ScreenDataObjects[data.pos.x, data.pos.y].RemoveAt(indx2);
                    ScreenData[data.pos.x, data.pos.y].RemoveAt(indx2);
                }

                //Screen_data[data.pos.x, data.pos.y].A
                int max = ScreenDataObjects[data.pos.x, data.pos.y].Count;
                int indx = max - 1;
                if (indx >= 0)
                {
                    while (ScreenDataObjects[data.pos.x, data.pos.y][indx].Layer > obj.Layer && indx > 0)
                    {
                        indx--;
                    }
                }
                indx++;
                (int x, int y) pos = data.pos;
                ScreenData[pos.x, pos.y].Insert(indx, (data.chr, data.col));
                ScreenDataObjects[pos.x, pos.y].Insert(indx, obj);

                if (!ObjectPixelPositions.ContainsKey(obj))
                {
                    ObjectPixelPositions.Add(obj, new List<(int x, int y)>());
                }
                ObjectPixelPositions[obj].Add(data.pos);

                UpdatePixelAt(pos);
            }
        }

        ///<summary>
        ///Reset/Clears the screen
        ///</summary>
        private void ClearScreen()
        {
            Console.BackgroundColor = System.ConsoleColor.Black;
            Console.ForegroundColor = System.ConsoleColor.Black;
            Console.Clear();
        }

        ///<summary>
        ///Renders a Frame.
        ///</summary>
        public void Frame()
        {
            DrawScreen();
        }


        ///<summary>
        ///Delets all Pixels from a given Object in Memory.
        ///</summary>
        public void DeleteOnscreenPixelsFromObject(Object OBJ)
        {
            bool border_set = false;
            (int x1, int y1, int x2, int y2) border = (0,0,0,0);
            if (ObjectPixelPositions.ContainsKey(OBJ))
            {
                foreach ((int x, int y) in ObjectPixelPositions[OBJ])
                {
                    if (ScreenDataObjects[x, y].Contains(OBJ))
                    {
                        _changeBorder((x, y), ref border_set, ref border);
                        int indx = ScreenDataObjects[x, y].IndexOf(OBJ);
                        ScreenData[x, y].RemoveAt(indx);
                        ScreenDataObjects[x, y].RemoveAt(indx);
                        UpdatePixelAt((x, y));
                    }
                }
                ObjectPixelPositions.Remove(OBJ);
            }
            /*
            for (int y = 0; y < WindowSize.y; y++)
            {
                for (int x = 0; x < WindowSize.x; x++)
                {
                    if (ScreenDataObjects[x, y].Contains(OBJ))
                    {
                        _changeBorder((x,y), ref border_set, ref border);
                        int indx = ScreenDataObjects[x, y].IndexOf(OBJ);
                        ScreenData[x, y].RemoveAt(indx);
                        ScreenDataObjects[x, y].RemoveAt(indx);
                        UpdatePixelAt((x, y));
                    }
                }
            }
            */

            if (!border_set)
            {
                border.x1 = -1;
            }
            else
            {
                border.x2++;
                _updateBorder.Add(border);
            }

            
        }




        ///<summary>
        ///Gets all Pixels from a given Object.
        ///</summary>
        public List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> GetPixelsFromObject(Object OBJ, bool to_screen)
        {
            List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> pixels_from_obj = new List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)>();

            List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> te;

            if (OBJ.ActiveObjectType == 1)
            {

                if (OBJ.Player.IsSpriteAnimated)
                {
                    te = OBJ.Player.ActiveAnimationSprite.ImageData;
                }
                else
                {
                    te = OBJ.Player.ActiveSprite.ImageData;
                }

                if (to_screen)
                {
                    for (int i = 0; i < te.Count; i++)
                    {
                        SetPixel((te[i].chr, te[i].col, ((OBJ.Position.x + te[i].pos.x - CameraPosition.x), (OBJ.Position.y + te[i].pos.y + CameraPosition.y))), OBJ);
                    }
                }
                else
                {
                    for (int i = 0; i < te.Count; i++)
                    {
                        pixels_from_obj.Add((te[i].chr, te[i].col, ((te[i].pos.x + OBJ.Position.x), (te[i].pos.y + OBJ.Position.y))));
                    }
                }

            }
            if (OBJ.ActiveObjectType == 2)
            {
                if (OBJ.Text.IsBackroundTransparent)
                {
                    te = OBJ.Text.CharPixeldata;
                    if (to_screen)
                    {
                        for (int i = 0; i < te.Count; i++)
                        {
                            (int x, int y) pos = ((te[i].pos.x + OBJ.Position.x - CameraPosition.x), (te[i].pos.y + OBJ.Position.y + CameraPosition.y));
                            (_, (int bri, int col_b, int col_f) col) = GetPixelAt(pos);
                            SetPixel((te[i].chr, (te[i].col.bri, col.col_b, te[i].col.col_f), pos), OBJ);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < te.Count; i++)
                        {
                            (_, (int bri, int col_b, int col_f) col) = GetPixelAt(((te[i].pos.x + OBJ.Position.x - CameraPosition.x), (te[i].pos.y + OBJ.Position.y + CameraPosition.y)));
                            pixels_from_obj.Add((te[i].chr, (te[i].col.bri, col.col_b, te[i].col.col_f), ((te[i].pos.x + OBJ.Position.x), (te[i].pos.y + OBJ.Position.y))));
                        }
                    }
                }
                else
                {
                    te = OBJ.Text.CharPixeldata;
                    if (to_screen)
                    {
                        for (int i = 0; i < te.Count; i++)
                        {
                            SetPixel((te[i].chr, te[i].col, ((te[i].pos.x + OBJ.Position.x - CameraPosition.x), (te[i].pos.y + OBJ.Position.y + CameraPosition.y))), OBJ);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < te.Count; i++)
                        {
                            pixels_from_obj.Add((te[i].chr, te[i].col, ((te[i].pos.x + OBJ.Position.x), (te[i].pos.y + OBJ.Position.y))));
                        }
                    }
                }
            }



            return pixels_from_obj;
        }


        private void _changeBorder((int x, int y) pos, ref bool border_set, ref (int x1, int y1, int x2, int y2) border)
        {
            //logger.Log($"Border at {pos.x}|{pos.y}");
            if (!((pos.x < 0) || (pos.y < 0) || (pos.x >= WindowSize.x) || (pos.y >= WindowSize.y)))
            {
                if (!border_set)
                {
                    border_set = true;
                    border.x1 = pos.x * 2;
                    border.x2 = pos.x * 2;
                    border.y1 = pos.y;
                    border.y2 = pos.y;
                }
                if (pos.x * 2 < border.x1)
                {
                    border.x1 = pos.x * 2;
                }
                if (pos.y < border.y1)
                {
                    border.y1 = pos.y;
                }
                if (pos.x * 2 > border.x2)
                {
                    border.x2 = pos.x * 2;
                }
                if (pos.y > border.y2)
                {
                    border.y2 = pos.y;
                }
            }
        }




        ///<summary>
        ///Draws all Pixels from a given Object.
        ///</summary>
        public void GetScreenPixelsFromObject(Object OBJ)
        {
            bool border_set = false;
            (int x1, int y1, int x2, int y2) border = (0,0,0,0);
            List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> pixels_from_obj = new List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)>();

            List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> te;

            if (OBJ.ActiveObjectType == 1)
            {

                if (OBJ.Player.IsSpriteAnimated)
                {
                    te = OBJ.Player.ActiveAnimationSprite.ImageData;
                }
                else
                {
                    te = OBJ.Player.ActiveSprite.ImageData;
                }


                for (int i = 0; i < te.Count; i++)
                {
                    (int x, int y) pos = (((OBJ.Position.x + te[i].pos.x - CameraPosition.x), (OBJ.Position.y + te[i].pos.y + CameraPosition.y)));
                    _changeBorder(pos, ref border_set, ref border);
                    SetPixel((te[i].chr, te[i].col, pos), OBJ);
                }


            }
            if (OBJ.ActiveObjectType == 2)
            {
                if (OBJ.Text.IsBackroundTransparent)
                {
                    te = OBJ.Text.CharPixeldata;

                    for (int i = 0; i < te.Count; i++)
                    {
                        (int x, int y) pos = ((te[i].pos.x + OBJ.Position.x - CameraPosition.x), (te[i].pos.y + OBJ.Position.y + CameraPosition.y));
                        _changeBorder(pos, ref border_set, ref border);
                        (_, (int bri, int col_b, int col_f) col) = GetPixelAt(pos);
                        SetPixel((te[i].chr, (te[i].col.bri, col.col_b, te[i].col.col_f), pos), OBJ);
                    }

                }
                else
                {
                    te = OBJ.Text.CharPixeldata;

                    for (int i = 0; i < te.Count; i++)
                    {
                        (int x, int y) pos = ((te[i].pos.x + OBJ.Position.x - CameraPosition.x), (te[i].pos.y + OBJ.Position.y + CameraPosition.y));
                        _changeBorder(pos, ref border_set, ref border);
                        SetPixel((te[i].chr, te[i].col, pos), OBJ);
                    }

                }
            }

            if (!border_set)
            {
                border.x1 = -1;
            }
            else
            {
                border.x2++;
                _updateBorder.Add(border);
            }
        }








        private List<(int x1, int y1, int x2, int y2)> _updateBorder;

        ///<summary>
        ///Renders a List of Objects into the Screen.
        ///</summary>
        public void RenderObjects(List<Object> objects)
        {
            foreach (Object OBJ in objects)
            {
                if (OBJ.ActiveObjectType == 1)
                {
                    if (OBJ.Player.IsSpriteAnimated)
                    {
                        OBJ.Player.UpdateAnimation();
                        OBJ.UpdateOnNextFrame = true;
                    }
                }
                if (OBJ.ActiveObjectType == 2)
                {
                    if (OBJ.Text.IsBackroundTransparent)
                    {
                        OBJ.UpdateOnNextFrame = true;
                    }
                }


                if (OBJ.UpdateOnNextFrame)
                {
                    OBJ.UpdateOnNextFrame = false;
                    DeleteOnscreenPixelsFromObject(OBJ);
                    if (OBJ.Shown)
                    {
                        GetScreenPixelsFromObject(OBJ);
                    }
                }

            }
        }

        ///<summary>
        ///Combines overlapping borders lol
        ///</summary>
        private void CombineBorders()
        {
            for (int b1 = 0; b1 < _updateBorder.Count; b1++)
            {
                for (int b2 = 0; b2 < _updateBorder.Count; b2++)
                {
                    if (BordersOverlap(_updateBorder[b1], _updateBorder[b2]))
                    {
                        if (b2 != b1)
                        {
                            _updateBorder[b1] = CombineBorders(_updateBorder[b1], _updateBorder[b2]);
                            _updateBorder.RemoveAt(b2);
                            b2--;
                            if (b1 > b2)
                            {
                                b1--;
                            }
                        }
                    }
                }
            }
        }

        ///<summary>
        ///Combines overlapping borders lol
        ///</summary>
        private (int x1, int y1, int x2, int y2) CombineBorders((int x1, int y1, int x2, int y2) border_1, (int x1, int y1, int x2, int y2) border_2)
        {
            bool border_set = false;
            (int x1, int y1, int x2, int y2) new_border = border_1;

            if (border_2.x1 < new_border.x1)
            {
                new_border.x1 = border_2.x1;
            }
            if (border_2.y1 < new_border.y1)
            {
                new_border.y1 = border_2.y1;
            }
            if (border_2.x2 > new_border.x2)
            {
                new_border.x2 = border_2.x2;
            }
            if (border_2.y2 > new_border.y2)
            {
                new_border.y2 = border_2.y2;
            }

            return new_border;
        }


        ///<summary>
        ///Checks if two borders overlap
        ///</summary>
        private bool BordersOverlap((int x1, int y1, int x2, int y2) border_1, (int x1, int y1, int x2, int y2) border_2)
        {
            if (border_1.x1 < border_2.x1)
            {
                (int x1, int y1, int x2, int y2) border_t = border_2;
                border_2 = border_1;
                border_1 = border_t;
            }

            if (border_1.x1 <= border_2.x2)
            {
                if (border_1.y1 >= border_2.y1)
                {
                    if (border_1.y1 <= border_2.y2)
                    {
                        return true;
                    }
                }
                else
                {
                    if (border_2.y1 <= border_1.y2)
                    {
                        return true;
                    }
                }
            }

            return false;
        }


        ///<summary>
        ///Draws the Screen.
        ///</summary>
        private void DrawScreen()
        {
            //fastScreenRenderer.WriteScreen(ref ScreenData);
            //fastScreenRenderer.WriteScreen(ref ActualScreenBuffer, (WindowSize.x * 2, WindowSize.y));

            //fastScreenRenderer.WriteScreen(ref ActualScreenBuffer, (10,0,100,99), (WindowSize.x * 2, WindowSize.y));

            CombineBorders();
            foreach ((int x1, int y1, int x2, int y2) border in _updateBorder)
            {
                //logger.Log($"load box from {border.x1}|{border.y1} to {border.x2}|{border.y2}");
                fastScreenRenderer.WriteScreen(ref ActualScreenBuffer, border, (WindowSize.x * 2, WindowSize.y));
                //Console.ReadLine();
            }

            Console.BackgroundColor = System.ConsoleColor.Black;
            Console.ForegroundColor = System.ConsoleColor.White;
            Console.SetCursorPosition(0, 0);
            Console.CursorVisible = false;
            _updateBorder = new List<(int x1, int y1, int x2, int y2)>();
        }
    }
}
