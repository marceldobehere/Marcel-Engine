﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;

namespace Testing_the_engine_lol
{
    
    class Program
    {
        static void Main()
        {
            MainEngine engine = new MainEngine((100, 100, 10), true, "Consolas");
            ObjectMiscData obj = new ObjectMiscData();
            Input inp = new Input();

            //create new Object
            Engine.Object Player = new Engine.Object();
            // Set Object type to Player
            Player.ActiveObjectType = obj.GetObjectTypeNumber("Player");

            // Add Sprite Library
            Graphics.Sprite_Lib spr = new Graphics.Sprite_Lib();
            // Add Player Sprite with an Image
            spr.Sprites.Add("Player_1", new Graphics.Sprite("Engine\\Sprites\\Animation test\\P_middle.mesf", true));
            // Set Players active Sprite to "Player_1" Sprite
            Player.Player.ActiveSprite = spr.Sprites["Player_1"];
            // Set the layer of Player to 1
            Player.Layer = 2;

            // Add Player animation frames
            Player.Player.AnimationLibrary.Sprites.Add("1", new Graphics.Sprite("Engine\\Sprites\\Animation test\\P_middle.mesf", true));
            Player.Player.AnimationLibrary.Sprites.Add("2", new Graphics.Sprite("Engine\\Sprites\\Animation test\\P_left.mesf", true));
            Player.Player.AnimationLibrary.Sprites.Add("3", new Graphics.Sprite("Engine\\Sprites\\Animation test\\P_middle.mesf", true));
            Player.Player.AnimationLibrary.Sprites.Add("4", new Graphics.Sprite("Engine\\Sprites\\Animation test\\P_right.mesf", true));

            // Set the animation speed to once every 10 frames
            Player.Player.AnimationSpeed = 10;

            // Turn on animation
            Player.Player.IsSpriteAnimated = true;

            // New Player Object P2
            Engine.Object P2 = new Engine.Object();
            P2.ActiveObjectType = 1;
            spr.Sprites.Add("Player_2", new Graphics.Sprite("Engine\\Sprites\\sprite2.mesf", true));
            //spr.Sprites.Add("Player_2", new Graphics.Sprite("Engine\\Internals\\Splashscreen.mesf", true));
            P2.Player.ActiveSprite = spr.Sprites["Player_2"];
            P2.Layer = 4;
            P2.Player.Scale = 3;
            P2.Player.UpdateSprite();

            // New Text Object saying Hello!
            Engine.Object Test_txt = new Engine.Object();
            Test_txt.ActiveObjectType = obj.GetObjectTypeNumber("Text");
            Test_txt.Text.Text = "Hello!";
            Test_txt.Text.UpdateText();
            Test_txt.Layer = 3;
            Test_txt.Text.IsBackroundTransparent = true;

            // New Text Object for testing collision
            Engine.Object TXT_2 = new Engine.Object();
            TXT_2.ActiveObjectType = obj.GetObjectTypeNumber("Text");
            TXT_2.Text.Text = "Collision? -";
            TXT_2.Text.UpdateText();
            TXT_2.Layer = 5;
            TXT_2.Text.IsBackroundTransparent = true;

            // Set all positions
            P2.Position = (20, 2);
            TXT_2.Position = (0, 1);
            Player.Position = (10, 10);

            // Add all Objects to the scene.
            engine.AddObjectToScene(Player);
            engine.AddObjectToScene(P2);
            engine.AddObjectToScene(Test_txt);
            engine.AddObjectToScene(TXT_2);

            // Render Frame
            engine.RenderFrame(100);

            //Engine_Internal.Debug_Logger logger = new Engine_Internal.Debug_Logger();
            //logger.Set_title("Test Title");
            //logger.Log("This is a Test!");

            //Player.Player.rotation = 0;

            Engine.Object player2 = Player.Clone();

            Scene testscene = new Scene("Test");
            testscene.SceneObjects.Add(player2);

            Scene og_scene = engine.ActiveScene.Clone();
            engine.ActiveScene = og_scene;
            //inp.KeyPressed(Input.Key.KEY_GOES_HERE) checks if a given Key is pressed



            Sound x = new Sound("Engine\\Sounds\\test.wav");
            x.MaximumQueueLength = 1;




            while (!inp.KeyPressed(Input.Key.Q))
            {
                (int x, int y) POS_2 = P2.Position;

                //Move Player according to input
                if (inp.KeyPressed(Input.Key.RightArrow))
                {
                    Player.MoveX(1);
                    player2.MoveX(1);
                }
                if (inp.KeyPressed(Input.Key.LeftArrow))
                {
                    Player.MoveX(-1);
                    player2.MoveX(-1);
                }
                if (inp.KeyPressed(Input.Key.DownArrow))
                {
                    Player.MoveY(1);
                    player2.MoveY(1);
                }
                if (inp.KeyPressed(Input.Key.UpArrow))
                {
                    Player.MoveY(-1);
                    player2.MoveY(-1);
                }

                POS_2.x += inp.KeyPressed(Input.Key.D) ? 1 : 0;
                POS_2.x -= inp.KeyPressed(Input.Key.A) ? 1 : 0;
                POS_2.y += inp.KeyPressed(Input.Key.S) ? 1 : 0;
                POS_2.y -= inp.KeyPressed(Input.Key.W) ? 1 : 0;

                if (inp.KeyPressed(Input.Key.W) || inp.KeyPressed(Input.Key.A) || inp.KeyPressed(Input.Key.S) || inp.KeyPressed(Input.Key.D))
                {
                    P2.Update();
                }

                if (inp.KeyPressed(Input.Key.Three))
                {
                    //Player.rotation--;
                    //logger.Log("Rotation Left");
                    Player.Player.Rotation--;
                    Player.Player.UpdateSprite();
                    Player.Update();
                }
                if (inp.KeyPressed(Input.Key.Four))
                {
                    //Player.rotation++;
                    //logger.Log("Rotation Right");
                    Player.Player.Rotation++;
                    Player.Player.UpdateSprite();
                    Player.Update();
                }

                if (inp.KeyPressed(Input.Key.Five))
                {
                    Player.Player.Scale -= 0.5;
                    Player.Player.UpdateSprite();
                    Player.Update();
                }
                if (inp.KeyPressed(Input.Key.Six))
                {
                    Player.Player.Scale += 0.5;
                    Player.Player.UpdateSprite();
                    Player.Update();
                }

                if (inp.KeyPressed(Input.Key.U))
                {
                    engine.MoveXCameraPosition(-1);
                }
                if (inp.KeyPressed(Input.Key.I))
                {
                    engine.MoveXCameraPosition(1);
                }
                if (inp.KeyPressed(Input.Key.O))
                {
                    engine.MoveYCameraPosition(1);
                }
                if (inp.KeyPressed(Input.Key.P))
                {
                    engine.MoveYCameraPosition(-1);
                }

                P2.Player.TurnTo(Player);



                if (inp.KeyPressed(Input.Key.Spacebar))
                {
                    Player.Shown = !Player.Shown;
                    Player.Update();
                    System.Threading.Thread.Sleep(100);
                }
                if (inp.KeyPressed(Input.Key.Two))
                {
                    Player.Player.IsSpriteAnimated = !Player.Player.IsSpriteAnimated;
                    Player.Update();
                    System.Threading.Thread.Sleep(100);
                }
                if (inp.KeyPressed(Input.Key.One))
                {
                    P2.Shown = !P2.Shown;
                    P2.Update();
                    System.Threading.Thread.Sleep(100);
                }

                //Shows Collision of Player and Player2 Objects.
                TXT_2.Text.Text = $"Collision? {engine.CheckObjectCollision(Player, P2)} | rot: {Math.Round(Player.Player.Rotation,2)}° | frame: {Player.Player.AnimationFrame} | rot (2): {P2.Player.Rotation}";
                TXT_2.Update();


                P2.Position = POS_2;

                if (inp.KeyPressed(Input.Key.Zero))
                {
                    if (engine.ActiveScene.SceneName == "Main")
                    {
                        engine.ChangeActiveScene(testscene);
                    }
                    else
                    {
                        engine.ChangeActiveScene(og_scene);
                    }
                    System.Threading.Thread.Sleep(1000);
                }


                if (inp.KeyPressed(Input.Key.H))
                {
                    x.Play(false);
                    //System.Threading.Thread.Sleep(100);
                }
                if (inp.KeyPressed(Input.Key.I))
                {
                    x.Play(true);
                    //System.Threading.Thread.Sleep(100);
                }
                if (inp.KeyPressed(Input.Key.J))
                {
                    x.Stop();
                }


                engine.RenderFrame(60);
            }





            //engine.Rem_Obj_from_scene(Test_txt);

            Graphics.Sprite amogus = new Graphics.Sprite();
            amogus.SetImageFromFile("Engine\\Sprites\\among us.mesf", true);
            P2.Player.ActiveSprite = amogus;
            P2.Shown = true;

            TXT_2.Shown = false;


            Player.Player.ActiveSprite = new Graphics.Sprite("Engine\\Sprites\\Animation test\\P_middle.mesf", false);
            Player.Player.IsSpriteAnimated = false;
            Player.Position = (5, 5);
            P2.Position = (30, 5);
            Test_txt.Position = (10, 2);
            P2.Player.UpdateSprite();

            while (true)
            {
                (int x, int y) POS = Player.Position;
                (int x, int y) POS2 = P2.Position;
                (int x, int y) POS3 = Test_txt.Position;

                for (int i = 0; i < 20; i++)
                {
                    POS.x++;
                    POS2.x++;
                    POS3.x++;
                    Player.Position = POS;
                    P2.Position = POS2;
                    P2.Player.Rotation++;
                    P2.Player.UpdateSprite();
                    Test_txt.Position = POS3;
                    Player.Update();
                    P2.Update();
                    Test_txt.Update();
                    engine.RenderFrame(-1);
                }

                for (int i = 0; i < 20; i++)
                {
                    POS.y++;
                    POS2.y++;
                    POS3.y++;
                    Player.Position = POS;
                    P2.Position = POS2;
                    P2.Player.Rotation++;
                    P2.Player.UpdateSprite();
                    Test_txt.Position = POS3;
                    Player.Update();
                    P2.Update();
                    Test_txt.Update();
                    engine.RenderFrame(-1);
                }

                for (int i = 0; i < 20; i++)
                {
                    POS.x--;
                    POS2.x--;
                    POS3.x--;
                    Player.Position = POS;
                    P2.Position = POS2;
                    P2.Player.Rotation++;
                    P2.Player.UpdateSprite();
                    Test_txt.Position = POS3;
                    Player.Update();
                    P2.Update();
                    Test_txt.Update();
                    engine.RenderFrame(-1);
                }

                for (int i = 0; i < 20; i++)
                {
                    POS.y--;
                    POS2.y--;
                    POS3.y--;
                    Player.Position = POS;
                    P2.Position = POS2;
                    P2.Player.Rotation++;
                    P2.Player.UpdateSprite();
                    Test_txt.Position = POS3;
                    Player.Update();
                    P2.Update();
                    Test_txt.Update();
                    engine.RenderFrame(-1);
                }
            }



        }
    }
}
