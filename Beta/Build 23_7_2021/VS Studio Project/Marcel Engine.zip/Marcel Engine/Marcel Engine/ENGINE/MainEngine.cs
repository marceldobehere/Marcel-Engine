﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine
{
    ///<summary>
    ///Engine go brrrrrr
    ///</summary>
    class MainEngine
    {
        ///<summary>
        ///The Screen of the Engine.
        ///</summary>
        public Screen Display { get; set; }
        ///<summary>
        ///Internal Stuff.
        ///</summary>
        private Internals _internal;
        ///<summary>
        ///The active Scene.
        ///</summary>
        public Scene ActiveScene { get; set; }
        ///<summary>
        ///The position of the Camera. It is a tuple.
        ///</summary>s
        public (int x, int y) CameraPosition { get; set; }
        ///<summary>
        ///Gets a ConsoleKey Key input. (And doesnt mess with the screen while doing it)
        ///</summary>
        public ConsoleKey GetKey()
        {
            Console.SetCursorPosition(0, 0);
            ConsoleKey temp = Console.ReadKey().Key;
            Display.UpdatePixelAt((0, 0));
            return temp;
        }
        ///<summary>
        ///Gets a Char Keyinput. (And doesnt mess with the screen while doing it)
        ///</summary>
        public char GetKeyChar()
        {
            Console.SetCursorPosition(0, 0);
            char temp = Console.ReadKey().KeyChar;
            Display.UpdatePixelAt((0, 0));
            return temp;
        }

        ///<summary>
        ///Inititalises the Engine with a given Screensize and if it should start maximized.
        ///</summary>
        public MainEngine((int x, int y, int size) size, bool maximize)
        {
            _initialise(size, maximize, "Consolas");
        }
        public MainEngine((int x, int y, int size) size, bool maximize, string console_font)
        {
            _initialise(size, maximize, console_font);
        }
        ///<summary>
        ///Inititalises the Engine with a given Screensize and font and if it should start maximized.
        ///</summary>
        private void _initialise((int x, int y, int size) size, bool maximize, string console_font)
        {
            Console.CursorVisible = false;
            Display = new Screen(size, maximize, console_font);
            _frames = 0;
            _lastTimeBeforeXFrames = DateTime.Now;
            ActiveScene = new Scene("Main");
            _internal = new Internals();
            //internal_.fastboot = true;
            if (!_internal.FastBoot)
            {
                AddObjectToScene(_internal.SplashscreenObject);
                RenderFrame(0.5);
                RemoveObjectFromScene(_internal.SplashscreenObject);
                RenderFrame(-1);
            }
        }


        ///<summary>
        ///Returns if two Objects collide with each other
        ///</summary>
        public bool CheckObjectCollision(Object a, Object b)
        {
            if (a.Layer == b.Layer)
            {
                List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> obj_b_pixels = Display.GetPixelsFromObject(b, false);
                List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> obj_a_pixels = Display.GetPixelsFromObject(a, false);
                for (int i = 0; i < obj_a_pixels.Count; i++)
                {
                    for (int i2 = 0; i2 < obj_b_pixels.Count; i2++)
                    {
                        if ((obj_a_pixels[i].pos.x == obj_b_pixels[i2].pos.x) && (obj_a_pixels[i].pos.y == obj_b_pixels[i2].pos.y))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            else
            {
                return false;
            }
        }

        ///<summary>
        ///Sets a new active scene.
        ///</summary>
        public void ChangeActiveScene(Scene new_scene)
        {
            ActiveScene = new_scene;
            for (int i = 0; i < ActiveScene.SceneObjects.Count; i++)
            {
                ActiveScene.SceneObjects[i].Update();
            }
            Display.ClearScreenandMemory();
        }

        ///<summary>
        ///Adds an Object to the scene.
        ///</summary>
        public void AddObjectToScene(Object obj)
        {
            ActiveScene.SceneObjects.Add(obj);
        }
        ///<summary>
        ///Removes an Object from the scene.
        ///</summary>s
        public void RemoveObjectFromScene(Object obj)
        {
            Display.DeleteOnscreenPixelsFromObject(obj);
            ActiveScene.SceneObjects.Remove(obj);
        }

        private static int _frames;
        private static DateTime _lastTimeBeforeXFrames;


        ///<summary>
        ///Moves the camera around.
        ///</summary>s
        public void MoveCameraPosition((int x, int y) position)
        {
            foreach (Object @object in ActiveScene.SceneObjects)
            {
                @object.UpdateOnNextFrame = true;
            }
            CameraPosition = ((CameraPosition.x + position.x), (CameraPosition.y + position.y));
        }
        ///<summary>
        ///Moves the camera around.
        ///</summary>s
        public void MoveXCameraPosition(int x)
        {
            foreach (Object obj in ActiveScene.SceneObjects)
            {
                obj.UpdateOnNextFrame = true;
            }
            CameraPosition = ((CameraPosition.x + x), CameraPosition.y);
        }
        ///<summary>
        ///Moves the camera around.
        ///</summary>s
        public void MoveYCameraPosition(int y)
        {
            foreach (Object obj in ActiveScene.SceneObjects)
            {
                obj.UpdateOnNextFrame = true;
            }
            CameraPosition = (CameraPosition.x, (CameraPosition.y + y));
        }


        ///<summary>
        ///Renders a Frame with the fps it should approximately have.
        ///</summary>
        public void RenderFrame(double prefferedFps)
        {
            double time_min;
            DateTime time_where_frame_should_be_done = DateTime.Now;
            if (prefferedFps != -1)
            {
                time_min = 1 / prefferedFps;
                time_where_frame_should_be_done = time_where_frame_should_be_done.AddSeconds(time_min);
            }

            _frames++;
            if (_frames > 30)
            {
                _frames = 0;
                DateTime diff = DateTime.Now;
                double temp = diff.Subtract(_lastTimeBeforeXFrames).TotalSeconds;
                _lastTimeBeforeXFrames = DateTime.Now;
                Display.UpdateFPS(30 / temp);
            }

            Display.RenderObjects(ActiveScene.SceneObjects);
            Display.CameraPosition = CameraPosition;
            Display.Frame();
            if (prefferedFps != -1)
            {
                while (DateTime.Now < time_where_frame_should_be_done)
                {

                }
            }
        }
    }
}
