﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;



namespace Engine
{
    ///<summary>
    ///Screen go brrrrrrrr and oooof
    ///</summary>
    class Screen
    {
        ///<summary>
        ///Don't ask
        ///</summary>
        [DllImport("user32.dll")]
        public static extern bool ShowWindow(System.IntPtr hWnd, int cmdShow);
        ///<summary>
        ///Maxmizes the Window
        ///</summary>
        private static void Maximize()
        {
            Process p = Process.GetCurrentProcess();
            ShowWindow(p.MainWindowHandle, 3);
        }

        ///<summary>
        ///brightness of the colours go brrrrrr
        ///</summary>
        static readonly string[] CharColours = { "░░", "▒▒", "▓▓" };
        ///<summary>
        ///The colour list. Basically just all consolecolours but with an index
        ///</summary>
        static readonly System.ConsoleColor[] ConsoleColours =
            {
                System.ConsoleColor.Black,
                System.ConsoleColor.Blue,
                System.ConsoleColor.Cyan,
                System.ConsoleColor.DarkBlue,
                System.ConsoleColor.DarkCyan,
                System.ConsoleColor.DarkGray,
                System.ConsoleColor.DarkGreen,
                System.ConsoleColor.DarkMagenta,
                System.ConsoleColor.DarkRed,
                System.ConsoleColor.DarkYellow,
                System.ConsoleColor.Gray,
                System.ConsoleColor.Green,
                System.ConsoleColor.Magenta,
                System.ConsoleColor.Red,
                System.ConsoleColor.White,
                System.ConsoleColor.Yellow,
            };

        static int ConvConsoleNum (int input)
        {
            //int x = (int)ConsoleColours[input];// ConsoleColor.Red;
            return (int)ConsoleColours[input];
        }



        ///<summary>
        ///Size of the Window
        ///</summary>
        public static (int x, int y, int size) WindowSize;
        ///<summary>
        ///fps count
        ///</summary>
        public static double FPS { get; set; }
        ///<summary>
        ///The position of the Camera. It is a tuple.
        ///</summary>s
        public (int x, int y) CameraPosition { get; set; }

        ///<summary>
        ///Updates the title with the current fps
        ///</summary>
        public void UpdateFPS(double fps_)
        {
            FPS = fps_;
            Console.Title = $"Marcel Engine - FPS: {Math.Round(FPS, 1)}";
        }


        ///<summary>
        ///Screendata.
        ///</summary>
        List<(char chr, (int bri, int col_b, int col_f))>[,] ScreenData;
        ///<summary>
        ///Screendata Objects.
        ///</summary>
        List<Object>[,] ScreenDataObjects;


        ///<summary>
        ///Just an Object that claims all the backroundpixels.
        ///</summary>
        private readonly Object BackroundObject;

        static FastConsoleRenderer fastScreenRenderer;

        ///<summary>
        ///Initialises the screen with a size
        ///</summary>
        public Screen((int x, int y, int size) size, bool maximize, string font)
        {
            FPS = 1;
            Console.Title = "Marcel Engine";
            Console.Clear();
            Console.WriteLine("Marcel Engine loading...");
            Console.SetWindowSize(1, 1);
            ConsoleHelper.SetCurrentFont(font, (short)size.size);
            if (maximize)
            {
                Maximize();
            }
            if (size.x > Console.LargestWindowWidth)
            {
                Console.WriteLine($"Decreasing X-Size from {size.x} to {Console.LargestWindowWidth}.");
                size.x = Console.LargestWindowWidth;
                //Console.ReadLine();
            }
            if (size.y > Console.LargestWindowHeight)
            {
                Console.WriteLine($"Decreasing Y-Size from {size.y} to {Console.LargestWindowHeight}.");
                size.y = Console.LargestWindowHeight;
                //Console.ReadLine();
            }
            WindowSize = size;

            CameraPosition = (0, 0);

            BackroundObject = new Object();
            //update_pos = new List<((char chr, int bri, int col_b, int col_f) coldata, (int x, int y) pos)>();
            ClearScreenMemory();

            fastScreenRenderer = new FastConsoleRenderer();

            //logger = new Engine_Internal.Debug_Logger();
            //logger.Set_title("Screen Debugger");


            Console.CursorVisible = false;
            //Console.ReadLine();
            ClearScreen();
        }


        ///<summary>
        ///Clears the Screen Memory.
        ///</summary>
        private void ClearScreenMemory()
        {
            ScreenData = new List<(char chr, (int bri, int col_b, int col_f))>[WindowSize.x, WindowSize.y];
            ScreenDataObjects = new List<Object>[WindowSize.x, WindowSize.y];
            for (int y = 0; y < WindowSize.y; y++)
            {
                for (int x = 0; x < WindowSize.x; x++)
                {
                    ScreenData[x, y] = new List<(char chr, (int bri, int col_b, int col_f))>() { (' ', (0, 0, 0)) };
                    ScreenDataObjects[x, y] = new List<Object>() { BackroundObject };
                }
            }
        }


        ///<summary>
        ///Clears the Screen.
        ///</summary>
        public void ClearScreenandMemory()
        {
            ScreenData = new List<(char chr, (int bri, int col_b, int col_f))>[WindowSize.x, WindowSize.y];
            ScreenDataObjects = new List<Object>[WindowSize.x, WindowSize.y];
            for (int y = 0; y < WindowSize.y; y++)
            {
                for (int x = 0; x < WindowSize.x; x++)
                {
                    ScreenData[x, y] = new List<(char chr, (int bri, int col_b, int col_f))>() { (' ', (0, 0, 0)) };
                    ScreenDataObjects[x, y] = new List<Object>() { BackroundObject };
                }
            }
            Frame();
        }





        ///<summary>
        ///Draws a List of Pixels with the same colour but different positions on screen.
        ///</summary>
        private void DrawPixels((char chr, (int bri, int col_b, int col_f) col, (int x, int y)[] pos) data)
        {
            Console.BackgroundColor = ConsoleColours[data.col.col_b];
            Console.ForegroundColor = ConsoleColours[data.col.col_f];
            if (data.chr == 0)
            {
                string draw_c = CharColours[data.col.bri];
                foreach ((int x, int y) in data.pos)
                {
                    Console.SetCursorPosition(x * 2, y);
                    Console.Write(draw_c);
                }
                /*
                foreach ((int x, int y) in data.pos) 
                {
                    Console.SetCursorPosition(x * 2, y);
                    Console.Write(draw_c);
                }
                */
            }
            else
            {
                for (int i = 0; i < data.pos.Length; i++)
                {
                    Console.SetCursorPosition(data.pos[i].x * 2, data.pos[i].y);
                    Console.Write(data.chr + " ");
                }
                /*
                foreach ((int x, int y) in data.pos)
                {
                    Console.SetCursorPosition(x * 2, y);
                    Console.Write(data.chr + " ");
                }
                */
            }
        }

        
        private (char chr, (int bri, int col_b, int col_f)) GetPixelAt((int x, int y) pos)
        {
            if (!((pos.x < 0) || (pos.y < 0) || (pos.x >= WindowSize.x) || (pos.y >= WindowSize.y)))
            {
                (char chr, (int bri, int col_b, int col_f)) x = ScreenData[pos.x, pos.y][ScreenData[pos.x, pos.y].Count - 1];
                return (x.chr, (x.Item2.bri, x.Item2.col_b, x.Item2.col_f));
            }
            return ((char)0,(0,0,0));
        }



        private void SetPixel((char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos) data, Object obj)
        {
            if (!((data.pos.x < 0) || (data.pos.y < 0) || (data.pos.x >= WindowSize.x) || (data.pos.y >= WindowSize.y)))
            {
                if (ScreenDataObjects[data.pos.x, data.pos.y].Contains(obj))
                {
                    int indx2 = ScreenDataObjects[data.pos.x, data.pos.y].IndexOf(obj);
                    ScreenDataObjects[data.pos.x, data.pos.y].RemoveAt(indx2);
                    ScreenData[data.pos.x, data.pos.y].RemoveAt(indx2);
                }

                //Screen_data[data.pos.x, data.pos.y].A
                int max = ScreenDataObjects[data.pos.x, data.pos.y].Count;
                int indx = max - 1;
                if (indx >= 0)
                {
                    while (ScreenDataObjects[data.pos.x, data.pos.y][indx].Layer > obj.Layer && indx > 0)
                    {
                        indx--;
                    }
                }
                indx++;
                ScreenData[data.pos.x, data.pos.y].Insert(indx, (data.chr, data.col));
                ScreenDataObjects[data.pos.x, data.pos.y].Insert(indx, obj);

            }
        }

        ///<summary>
        ///Reset/Clears the screen
        ///</summary>
        private void ClearScreen()
        {
            Console.BackgroundColor = System.ConsoleColor.Black;
            Console.ForegroundColor = System.ConsoleColor.Black;
            Console.Clear();
        }

        ///<summary>
        ///Renders a Frame.
        ///</summary>
        public void Frame()
        {
            CompareAndDraw();
        }


        ///<summary>
        ///Gets all Pixels from a given Object.
        ///</summary>
        public void DeleteOnscreenPixelsFromObject(Object OBJ)
        {
            for (int y = 0; y < WindowSize.y; y++)
            {
                for (int x = 0; x < WindowSize.x; x++)
                {
                    if (ScreenDataObjects[x, y].Contains(OBJ))
                    {
                        int indx = ScreenDataObjects[x, y].IndexOf(OBJ);
                        ScreenData[x, y].RemoveAt(indx);
                        ScreenDataObjects[x, y].RemoveAt(indx);
                    }
                }
            }
        }




        ///<summary>
        ///Gets all Pixels from a given Object.
        ///</summary>
        public List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> GetPixelsFromObject(Object OBJ, bool to_screen)
        {
            List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> pixels_from_obj = new List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)>();

            List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> te;

            if (OBJ.ActiveObjectType == 1)
            {

                if (OBJ.Player.IsSpriteAnimated)
                {
                    te = OBJ.Player.ActiveAnimationSprite.ImageData;
                }
                else
                {
                    te = OBJ.Player.ActiveSprite.ImageData;
                }

                if (to_screen)
                {
                    for (int i = 0; i < te.Count; i++)
                    {
                        SetPixel((te[i].chr, te[i].col, ((OBJ.Position.x + te[i].pos.x - CameraPosition.x), (OBJ.Position.y + te[i].pos.y + CameraPosition.y))), OBJ);
                    }
                }
                else
                {
                    for (int i = 0; i < te.Count; i++)
                    {
                        pixels_from_obj.Add((te[i].chr, te[i].col, ((te[i].pos.x + OBJ.Position.x), (te[i].pos.y + OBJ.Position.y))));
                    }
                }

            }
            if (OBJ.ActiveObjectType == 2)
            {
                if (OBJ.Text.IsBackroundTransparent)
                {
                    te = OBJ.Text.CharPixeldata;
                    if (to_screen)
                    {
                        for (int i = 0; i < te.Count; i++)
                        {
                            (int x, int y) pos = ((te[i].pos.x + OBJ.Position.x - CameraPosition.x), (te[i].pos.y + OBJ.Position.y + CameraPosition.y));
                            (_, (int bri, int col_b, int col_f) col) = GetPixelAt(pos);
                            SetPixel((te[i].chr, (te[i].col.bri, col.col_b, te[i].col.col_f), pos), OBJ);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < te.Count; i++)
                        {
                            (_, (int bri, int col_b, int col_f) col) = GetPixelAt(((te[i].pos.x + OBJ.Position.x - CameraPosition.x), (te[i].pos.y + OBJ.Position.y + CameraPosition.y)));
                            pixels_from_obj.Add((te[i].chr, (te[i].col.bri, col.col_b, te[i].col.col_f), ((te[i].pos.x + OBJ.Position.x), (te[i].pos.y + OBJ.Position.y))));
                        }
                    }
                }
                else
                {
                    te = OBJ.Text.CharPixeldata;
                    if (to_screen)
                    {
                        for (int i = 0; i < te.Count; i++)
                        {
                            SetPixel((te[i].chr, te[i].col, ((te[i].pos.x + OBJ.Position.x - CameraPosition.x), (te[i].pos.y + OBJ.Position.y + CameraPosition.y))), OBJ);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < te.Count; i++)
                        {
                            pixels_from_obj.Add((te[i].chr, te[i].col, ((te[i].pos.x + OBJ.Position.x), (te[i].pos.y + OBJ.Position.y))));
                        }
                    }
                }
            }



            return pixels_from_obj;
        }





        ///<summary>
        ///Renders a List of Objects into the Screen.
        ///</summary>
        public void RenderObjects(List<Object> objects)
        {
            foreach (Object OBJ in objects)
            {
                if (OBJ.ActiveObjectType == 1)
                {
                    if (OBJ.Player.IsSpriteAnimated)
                    {
                        OBJ.Player.UpdateAnimation();
                        OBJ.UpdateOnNextFrame = true;
                    }
                }
                if (OBJ.ActiveObjectType == 2)
                {
                    if (OBJ.Text.IsBackroundTransparent)
                    {
                        OBJ.UpdateOnNextFrame = true;
                    }
                }


                if (OBJ.UpdateOnNextFrame)
                {
                    OBJ.UpdateOnNextFrame = false;
                    DeleteOnscreenPixelsFromObject(OBJ);
                    if (OBJ.Shown)
                    {
                        GetPixelsFromObject(OBJ, true);
                    }
                }

            }
        }

        ///<summary>
        ///Draws the changes of the live pixel list and the old pixel array
        ///</summary>
        private void CompareAndDraw()
        {
            fastScreenRenderer.WriteScreen(ref ScreenData);
            /*
            //List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> pixel_draw = new List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)>();
            Dictionary<(char chr, (int bri, int col_b, int col_f) col), List<(int x, int y)>> temp_draw;
            temp_draw = new Dictionary<(char chr, (int bri, int col_b, int col_f) col), List<(int x, int y)>>();

            for (int i = 0; i < UpdatePositions.Count; i++)
            {
                (char chr,(int bri, int col_b, int col_f) col) pixl = GetPixelAt(UpdatePositions[i].pos);
                if (UpdatePositions[i].coldata != pixl)
                {
                    if (!temp_draw.ContainsKey(pixl))
                    {
                        temp_draw.Add(pixl, new List<(int x, int y)>());
                    }
                    temp_draw[pixl].Add(UpdatePositions[i].pos);
                }
            }


            for (int i = 0; i < temp_draw.Count; i++)
            {
                (char chr, (int bri, int col_b, int col_f) col) = temp_draw.ElementAt(i).Key;
                DrawPixels((chr, col, temp_draw.ElementAt(i).Value.ToArray()));
            }
            */
            Console.BackgroundColor = System.ConsoleColor.Black;
            Console.SetCursorPosition(0, 0);
        }
    }
}
