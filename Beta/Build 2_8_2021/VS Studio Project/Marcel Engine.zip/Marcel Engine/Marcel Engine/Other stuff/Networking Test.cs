﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;

namespace Testing_the_engine_lol
{
    /*
    class _Program
    {
        static void _Main(string[] args)
        {

            Main_Engine engine = new Main_Engine((100, 100, 10), false);
            Screen scr = engine.display;
            Graphics test = engine.graphics;
            ObjectMiscData obj = new ObjectMiscData();
            Input inp = new Input();

            //create new Object
#pragma warning disable IDE0017 // Initialisierung von Objekten vereinfachen
            Engine.Object Player = new Engine.Object();
#pragma warning restore IDE0017 // Initialisierung von Objekten vereinfachen
            // Set Object type to Player
            Player.Active_obj_type = obj.Get_Typenum("Player");

            // Add Sprite Library
            Graphics.Sprite_Lib spr = new Graphics.Sprite_Lib();
            // Add Player Sprite with an Image
            spr.Sprites.Add("Player_1", new Graphics.Sprite("Engine\\Sprites\\Animation test\\P_middle.mesf", true));
            // Set Players active Sprite to "Player_1" Sprite
            Player.Player.ActveSprite = spr.Sprites["Player_1"];
            // Set the layer of Player to 1
            Player.Layer = 2;

            // New Text Object for testing collision
#pragma warning disable IDE0017 // Initialisierung von Objekten vereinfachen
            Engine.Object TXT_2 = new Engine.Object();
#pragma warning restore IDE0017 // Initialisierung von Objekten vereinfachen
            TXT_2.Active_obj_type = obj.Get_Typenum("Text");
            TXT_2.Text.Text = "Collision? -";
            TXT_2.Text.UpdateText();
            TXT_2.Layer = 5;
            TXT_2.Text.BackroundTransparent = true;


            TXT_2.Position = (0, 1);
            Player.Position = (10, 10);

            // Add all Objects to the scene.
            engine.Add_Obj_to_scene(Player);
            engine.Add_Obj_to_scene(TXT_2);

            // Render Frame
            engine.Render_Frame(100);

            //Engine_Internal.Debug_Logger logger = new Engine_Internal.Debug_Logger();
            //logger.Set_title("Test Title");
            //logger.Log("This is a Test!");

            //Player.Player.rotation = 0;

            Networking net = new Networking();

            string IP = "26.210.185.253";

            while (!inp.KeyPressed(Input.Key.S) && !inp.KeyPressed(Input.Key.C))
            {

            }
            if (inp.KeyPressed(Input.Key.S))
            {
                net.server.Start(IP);





                while (!inp.KeyPressed(Input.Key.Q))
                {
                    if (net.server.receive != "")
                    {
                        string dat = net.server.receive;
                        net.server.reply = "OK";

                        string[] data = dat.Split('|');

                        Player.Position = (int.Parse(data[0]), int.Parse(data[1]));

                        Player.Shown = bool.Parse(data[2]);

                        Player.Player.Rotation = double.Parse(data[3]);

                        Player.Player.Scale = double.Parse(data[4]);

                        Player.Player.UpdateSprite();

                        Player.Update();
                    }

                    //string data = $"{Player.position.x}|{Player.position.y}|{Player.shown}|{Math.Round(Player.Player.rotation, 4)}|{Math.Round(Player.Player.scale, 4)}";


                    //Shows Collision of Player and Player2 Objects.
                    TXT_2.Text.Text = $"rot: {Math.Round(Player.Player.Rotation, 2)}° | frame: {Player.Player.AnimationFrame}";
                    TXT_2.Update();

                    engine.Render_Frame(30);
                }
            }



            if (inp.KeyPressed(Input.Key.C))
            {
                net.client.Start(IP);


                //inp.KeyPressed(Input.Key.KEY_GOES_HERE) checks if a given Key is pressed
                while (!inp.KeyPressed(Input.Key.Q))
                {
                    //Move Player according to input
                    if (inp.KeyPressed(Input.Key.RightArrow))
                    {
                        Player.Move_x(1);
                    }
                    if (inp.KeyPressed(Input.Key.LeftArrow))
                    {
                        Player.Move_x(-1);
                    }
                    if (inp.KeyPressed(Input.Key.DownArrow))
                    {
                        Player.Move_y(1);
                    }
                    if (inp.KeyPressed(Input.Key.UpArrow))
                    {
                        Player.Move_y(-1);
                    }

                    if (inp.KeyPressed(Input.Key.Three))
                    {
                        //Player.rotation--;
                        //logger.Log("Rotation Left");
                        Player.Player.Rotation--;
                        Player.Player.UpdateSprite();
                        Player.Update();
                    }
                    if (inp.KeyPressed(Input.Key.Four))
                    {
                        //Player.rotation++;
                        //logger.Log("Rotation Right");
                        Player.Player.Rotation++;
                        Player.Player.UpdateSprite();
                        Player.Update();
                    }

                    if (inp.KeyPressed(Input.Key.Five))
                    {
                        Player.Player.Scale -= 0.5;
                        Player.Player.UpdateSprite();
                        Player.Update();
                    }
                    if (inp.KeyPressed(Input.Key.Six))
                    {
                        Player.Player.Scale += 0.5;
                        Player.Player.UpdateSprite();
                        Player.Update();
                    }

                    if (inp.KeyPressed(Input.Key.Spacebar))
                    {
                        Player.Shown = !Player.Shown;
                        Player.Update();
                        System.Threading.Thread.Sleep(100);
                    }

                    string data = $"{Player.Position.x}|{Player.Position.y}|{Player.Shown}|{Math.Round(Player.Player.Rotation,4)}|{Math.Round(Player.Player.Scale, 4)}";
                    net.Send_data(data);


                    //Shows Collision of Player and Player2 Objects.
                    TXT_2.Text.Text = $"rot: {Math.Round(Player.Player.Rotation, 2)}° | frame: {Player.Player.AnimationFrame}";
                    TXT_2.Update();

                    engine.Render_Frame(30);
                }
            }



            




        }
    }

    */
}
