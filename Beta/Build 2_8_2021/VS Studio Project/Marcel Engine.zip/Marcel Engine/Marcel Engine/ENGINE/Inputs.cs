﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.InteropServices;

namespace Engine
{
    ///<summary>
    ///Key Inputs
    ///<para /> Code 100% not stolen from n8engine ;)
    ///</summary>
    class Input
    {
        ///<summary>
        ///Keys that can be checked if they are pressed
        ///</summary>
        public enum Key
        {
            None,
            One = 0x31, Two = 0x32, Three = 0x33, Four = 0x34, Five = 0x35, Six = 0x36, Seven = 0x37, Eight = 0x38, Nine = 0x39, Zero = 0x30,
            Q = 0x51, W = 0x57, E = 0x45, R = 0x52, T = 0x54, Y = 0x59, U = 0x55, I = 0x49, O = 0x4F, P = 0x50,
            A = 0x41, S = 0x53, D = 0x44, F = 0x46, G = 0x47, H = 0x48, J = 0x4A, K = 0x4B, L = 0x4C,
            Z = 0x5A, X = 0x58, C = 0x43, V = 0x56, B = 0x42, N = 0x4E, M = 0x4D,
            LeftArrow = 0x25, RightArrow = 0x27, UpArrow = 0x26, DownArrow = 0x28, Spacebar = 0x20, Backspace = 0x08, Esc = 0x1B, Enter = 0x0D, Tab = 0x09,
            Shift = 0x10, Ctrl = 0x11, Alt = 0x12
        }

        private const int KEY_PRESSED = 0x8000;

        [DllImport("user32.dll")]
        private static extern short GetKeyState(Key key);

        public bool KeyPressed(Key key)
        {
            if (ApplicationIsActivated())
            {
                return Convert.ToBoolean(GetKeyState(key) & KEY_PRESSED);
            }
            return false;
        }

        /// <summary>Returns true if the current application has focus, false otherwise</summary>
        public static bool ApplicationIsActivated()
        {
            var activatedHandle = GetForegroundWindow();
            if (activatedHandle == IntPtr.Zero)
            {
                return false;       // No window is currently activated
            }
            else
            {
                //Console.WriteLine("Application is focused!");
            }

            var procId = System.Diagnostics.Process.GetCurrentProcess().Id;
            int activeProcId;
            GetWindowThreadProcessId(activatedHandle, out activeProcId);

            return activeProcId == procId;
        }


        [DllImport("user32.dll", CharSet = CharSet.Auto, ExactSpelling = true)]
        private static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern int GetWindowThreadProcessId(IntPtr handle, out int processId);


        public Input()
        {

        }
    }


}
