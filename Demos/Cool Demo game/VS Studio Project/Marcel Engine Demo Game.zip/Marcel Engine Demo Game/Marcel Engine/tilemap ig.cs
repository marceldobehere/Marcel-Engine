﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;
using Enemy = Engine.Object;

namespace Testing_the_engine_lol
{
    class TileData
    {
        public static Dictionary<int, Graphics.Sprite> TileSprites = new Dictionary<int, Graphics.Sprite>()
        {
            {-1, new Graphics.Sprite(@"Engine\Sprites\Tilemaps\base0.mesf", false)},
            {0, new Graphics.Sprite(@"Engine\Sprites\Tilemaps\floor1.mesf", false)},
            {1, new Graphics.Sprite(@"Engine\Sprites\Tilemaps\wall1.mesf", false)},
            {2, new Graphics.Sprite(@"Engine\Sprites\Tilemaps\base2.mesf", false)},
            {3, new Graphics.Sprite(@"Engine\Sprites\Tilemaps\teleporter.mesf", false)}
        };

        public static Dictionary<int, bool> IsTileSolid = new Dictionary<int, bool>()
        {
            {0,false},
            {1,true},
            {2,true},
            {3,false}
        };
    }
    class Tilemap
    {
        public (int x, int y) Position;
        public int[,] map;
        public Engine.Object[,] obj;
        public (int x, int y) Size;
        public int SpriteSize;
        public List<Enemy> Enemies;
        public List<Item> Items;

        public Tilemap((int x, int y) size)
        {
            SpriteSize = 10;
            Size = size;
            map = new int[size.x, size.y];
            obj = new Engine.Object[size.x, size.y];
            ResetObjects();
        }

        public void ResetObjects()
        {
            Enemies = new List<Enemy>();
            Items = new List<Item>();
            for (int y = 0; y < Size.y; y++)
            {
                for (int x = 0; x < Size.x; x++)
                {
                    map[x, y] = 0;
                    obj[x, y] = new Engine.Object();
                    obj[x, y].ActiveObjectType = 1;
                    obj[x, y].Player.ActiveSprite = TileData.TileSprites[map[x, y]];
                    obj[x, y].OffsetPosition = (x * SpriteSize + Position.x, y * SpriteSize + Position.y);
                }
            }
        }

        public void SetnewTileMap(int[,] mapdata)
        {
            for (int y = 0; y < Size.y; y++)
            {
                for (int x = 0; x < Size.x; x++)
                {
                    map[x, y] = mapdata[x, y];
                    obj[x, y].Player.ActiveSprite = TileData.TileSprites[map[x, y]];
                    obj[x, y].OffsetPosition = (x * SpriteSize + Position.x, y * SpriteSize + Position.y);
                    obj[x, y].Update();
                }
            }
        }
        public void SetnewTileMap(int[,] mapdata, bool update)
        {
            for (int y = 0; y < Size.y; y++)
            {
                for (int x = 0; x < Size.x; x++)
                {
                    map[x, y] = mapdata[x, y];
                    obj[x, y].Player.ActiveSprite = TileData.TileSprites[map[x, y]];
                    obj[x, y].OffsetPosition = (x * SpriteSize + Position.x, y * SpriteSize + Position.y);
                    if (update)
                    {
                        obj[x, y].Update();
                    }
                }
            }
        }

        public void Update()
        {
            for (int y = 0; y < Size.y; y++)
            {
                for (int x = 0; x < Size.x; x++)
                {
                    obj[x, y].OffsetPosition = (x * SpriteSize + Position.x, y * SpriteSize + Position.y);
                    obj[x, y].Update();
                }
            }
        }

        public void AddTileMapToScene(Engine.MainEngine engine)
        {
            for (int y = 0; y < Size.y; y++)
            {
                for (int x = 0; x < Size.x; x++)
                {
                    engine.AddObjectToScene(obj[x, y]);
                    obj[x, y].Update();
                }
            }
        }
        public void RemoveTileMapFromScene(Engine.MainEngine engine)
        {
            for (int y = 0; y < Size.y; y++)
            {
                for (int x = 0; x < Size.x; x++)
                {
                    engine.RemoveObjectFromScene(obj[x, y]);
                }
            }
        }
        public void AddObjectsToScene(Engine.MainEngine engine)
        {
            foreach (Enemy x in Enemies)
            {
                engine.AddObjectToScene(x.enemy);
                x.enemy.Update();
            }
            foreach (Item x in Items)
            {
                engine.AddObjectToScene(x.item);
                x.item.Update();
            }
        }
        public void RemoveObjectsFromScene(Engine.MainEngine engine)
        {
            foreach (Enemy x in Enemies)
            {
                engine.RemoveObjectFromScene(x.enemy);
            }
            foreach (Item x in Items)
            {
                engine.RemoveObjectFromScene(x.item);
            }
        }
        public void SetTile((int x, int y) pos, int new_tile)
        {
            try
            {
                map[pos.x, pos.y] = new_tile;
                obj[pos.x, pos.y].Player.ActiveSprite = TileData.TileSprites[map[pos.x, pos.y]];
                obj[pos.x, pos.y].OffsetPosition = (pos.x * SpriteSize + Position.x, pos.y * SpriteSize + Position.y);
                obj[pos.x, pos.y].Update();
            }
            catch
            {

            }
        }
    }
}
