﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;
using Object = Engine.Object;

namespace Testing_the_engine_lol
{
    class TileMapGenerator
    {
        public static Tilemap GenRoom(string roomtype, (int x, int y) Size)
        {
            if (roomtype == "default")
            {
                return GenDefaultRoom(Size);
            }
            if (roomtype == "boss")
            {
                return GenBossRoom(Size);
            }
            if (roomtype == "cool")
            {
                return GenCoolRoom(Size);
            }
            if (roomtype == "start")
            {
                return GenStartRoom(Size);
            }
            if (roomtype == "secret")
            {
                return GenSecretRoom(Size);
            }
            return null;
        }

        static int[,] GenerateBaseroom((int x, int y) Size)
        {
            int[,] map_ = new int[Size.x, Size.y];

            for (int i = 0; i < Size.x; i++)
            {
                map_[i, 0] = 1;
            }
            for (int i = 0; i < Size.x; i++)
            {
                map_[i, Size.y - 1] = 1;
            }
            for (int i = 0; i < Size.y; i++)
            {
                map_[0, i] = 1;
            }
            for (int i = 0; i < Size.y; i++)
            {
                map_[Size.x - 1, i] = 1;
            }
            map_[(Size.x) / 2, Size.y - 1] = 3;
            map_[(Size.x) / 2, 0] = 3;
            if (Size.x % 2 == 0)
            {
                map_[(Size.x - 1) / 2, Size.y - 1] = 3;
                map_[(Size.x - 1) / 2, 0] = 3;
            }

            map_[Size.x - 1, Size.y / 2] = 3;
            map_[0, Size.y / 2] = 3;
            if (Size.y % 2 == 0)
            {

                map_[Size.x - 1, (Size.y - 1) / 2] = 3;
                map_[0, (Size.y - 1) / 2] = 3;
            }


            return map_;
        }



        public static Tilemap GenStartRoom((int x, int y) Size)
        {
            int[,] map_;
            Tilemap map;
            map = new Tilemap(Size);
            map_ = GenerateBaseroom(Size);


            map.SetnewTileMap(map_);
            return map;
        }
        public static Tilemap GenSecretRoom((int x, int y) Size)
        {
            int[,] map_;
            Tilemap map;
            map = new Tilemap(Size);
            map_ = GenerateBaseroom(Size);

            {
                Item temp = new Item();
                temp.Item_type = -1;
                temp.item.Layer = 8;
                temp.item.ActiveObjectType = 1;
                temp.item.Position = (60, 60);
                temp.item.Player.ActiveSprite = new Graphics.Sprite(@"Engine\Sprites\Secret\ston.mesf", false);
                map.Items.Add(temp);
            }

            {
                Item temp = new Item();
                temp.Item_type = -1;
                temp.item.Layer = 8;
                temp.item.ActiveObjectType = 1;
                temp.item.Position = (100, 40);
                temp.item.Player.ActiveSprite = new Graphics.Sprite(@"Engine\Sprites\Secret\n8statue.mesf", false);
                map.Items.Add(temp);
            }
            Random rnd = new Random();
            for (int i = rnd.Next(0, 100); i > 0; i--)
            {
                rnd.Next(0, 100);
            }

            map.Items.AddRange(GenDefaultObjects(map_, ref rnd).items);
            map.Items.AddRange(GenDefaultObjects(map_, ref rnd).items);
            map.Items.AddRange(GenDefaultObjects(map_, ref rnd).items);

            map.SetnewTileMap(map_);
            return map;
        }

        public static Tilemap GenBossRoom((int x, int y) Size)
        {
            int[,] map_;
            Tilemap map;
            map = new Tilemap(Size);
            map_ = GenerateBaseroom(Size);

            Random rnd = new Random();

            for (int i = rnd.Next(0, 20); i >= 0; i--)
            {
                map_[rnd.Next(2, map.Size.x - 2), rnd.Next(2, map.Size.y - 2)] = 1;
            }


            map.Enemies = GenDefaultObjects(map_, ref rnd).enemies;
            map.Enemies.AddRange(GenDefaultObjects(map_, ref rnd).enemies);
            map.Enemies.AddRange(GenDefaultObjects(map_, ref rnd).enemies);

            map.SetnewTileMap(map_);
            return map;
        }
        public static Tilemap GenCoolRoom((int x, int y) Size)
        {
            int[,] map_;
            Tilemap map;
            map = new Tilemap(Size);
            map_ = GenerateBaseroom(Size);

            Random rnd = new Random();

            map.Items = GenDefaultObjects(map_, ref rnd).items;
            map.Items.AddRange(GenDefaultObjects(map_, ref rnd).items);

            map.SetnewTileMap(map_);
            return map;
        }

        public static Tilemap GenDefaultRoom((int x, int y) Size)
        {
            int[,] map_;
            Tilemap map;
            map = new Tilemap(Size);
            map_ = GenerateBaseroom(Size);

            Random rnd = new Random();

            for (int i = rnd.Next(0, 20); i >= 0; i--)
            {
                map_[rnd.Next(2, map.Size.x - 2), rnd.Next(2, map.Size.y - 2)] = 1;
            }

            (List<Enemy> enemies, List<Item> items) temp = GenDefaultObjects(map_, ref rnd);

            map.Enemies = temp.enemies;
            map.Items = temp.items;

            map.SetnewTileMap(map_);
            return map;
        }
        private static (List<Enemy> enemies, List<Item> items) GenDefaultObjects(int[,] map, ref Random rnd)
        {
            List<Enemy> Enemies = new List<Enemy>();
            List<Item> Items = new List<Item>();

            (int x, int y) mapsize = (map.GetLength(0), map.GetLength(1));


            for (int i = rnd.Next(0, 5); i > 0; i--)
            {
                Enemy TestEnemie = BaseEnemy.GetEnemy(rnd.Next(0,2));

                (int x, int y) position = (rnd.Next(2, mapsize.x - 2), rnd.Next(2, mapsize.y - 2)); ;
                for (int z = rnd.Next(0, 10); z > 0; z--)
                {
                    position = (rnd.Next(2, mapsize.x - 2), rnd.Next(2, mapsize.y - 2));
                }
                int counter = 100;
                while (counter > 0 && TileData.IsTileSolid[map[position.x, position.y]])
                {
                    position = (rnd.Next(2, mapsize.x - 2), rnd.Next(2, mapsize.y - 2));
                    counter--;
                }

                TestEnemie.enemy.Position = (position.x * 10, position.y * 10);
                Enemies.Add(TestEnemie);
            }



            for (int i = rnd.Next(0, 3); i > 0; i--)
            {
                Item TestItem = BaseItem.GetItem(rnd.Next(0, 2));

                (int x, int y) position = (rnd.Next(2, mapsize.x - 2), rnd.Next(2, mapsize.y - 2)); ;
                for (int z = rnd.Next(0, 10); z > 0; z--)
                {
                    position = (rnd.Next(2, mapsize.x - 2), rnd.Next(2, mapsize.y - 2));
                }
                int counter = 3;
                while (counter > 0 && TileData.IsTileSolid[map[position.x, position.y]])
                {
                    position = (rnd.Next(2, mapsize.x - 2), rnd.Next(2, mapsize.y - 2));
                    counter--;
                }

                TestItem.item.Position = (position.x * 10, position.y * 10);
                Items.Add(TestItem);
            }


            return (Enemies, Items);
        }
    }
}
