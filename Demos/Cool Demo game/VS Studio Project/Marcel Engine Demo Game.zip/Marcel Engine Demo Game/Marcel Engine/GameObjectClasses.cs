﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;
using Object = Engine.Object;

namespace Testing_the_engine_lol
{
    class Enemy
    {
        public Object enemy;
        public int Enemy_type;
        public bool enemy_active;
        public int enemy_randomnes;
        public int health;
        public string dir;
        public Enemy()
        {
            dir = "down";
            health = 1;
            Enemy_type = 0;
            enemy = new Object();
            enemy_active = false;
            enemy_randomnes = 0;
        }
    }
    class Item
    {
        public Object item;
        public int Item_type;
        public Item()
        {
            item = new Object();
            Item_type = 0;
        }
    }
}
