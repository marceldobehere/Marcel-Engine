﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;
using Object = Engine.Object;

namespace Testing_the_engine_lol
{

    class DemoDungeonGame
    {
        public static MainEngine engine;
        public static (int x, int y) room_position;
        public static List<(int x, int y)> rooms_pos = new List<(int x, int y)>();
        public static List<Tilemap> room_tilemaps = new List<Tilemap>();
        public static Tilemap current_map;
        public static Graphics.Sprite_Lib numbers;
        static void EnterNewRoom((int x, int y) new_pos)
        {

            current_map.RemoveTileMapFromScene(engine);
            current_map.RemoveObjectsFromScene(engine);
            room_position = new_pos;
            if (!rooms_pos.Contains(new_pos))
            {
                rooms_pos.Add(new_pos);
                room_tilemaps.Add(GenRoom());
            }
            current_map = room_tilemaps[rooms_pos.IndexOf(new_pos)];
            current_map.AddTileMapToScene(engine);
            current_map.AddObjectsToScene(engine);
            current_map.Update();
        }

        static Tilemap GenRoom()
        {
            Random rnd = new Random();
            Tilemap test = null;
            int testnum = rnd.Next(1, 101);
            if (testnum >= 80 && testnum <= 90)
            {
                test = TileMapGenerator.GenRoom("cool", (20, 15));
            }
            else
            {
                if (testnum >= 90 && testnum <= 100)
                {
                    test = TileMapGenerator.GenRoom("boss", (20, 15));
                }
                else
                {
                    if (testnum >= 0 && testnum <= 5)
                    {
                        test = TileMapGenerator.GenRoom("secret", (20, 15));
                    }
                    else
                    {
                        test = TileMapGenerator.GenRoom("default", (20, 15));
                    }
                }
            }


            return test;
        }


        static void PlayerMovement(Object PlayerHitbox, Input inp, int speed, Object PlayerSprite, ref string dir, List<PlayerBullet> PlayerBullets, List<EnemyBullet> EnemyBullets)
        {
            (int x, int y) mov = (0, 0);
            if (inp.KeyPressed(Input.Key.RightArrow))
            {
                mov.x += speed;
                PlayerSprite.Player.CurrentAnimationLibrary = PlayerSprite.Player.AnimationLibrary["right"];
                dir = "right";
            }
            if (inp.KeyPressed(Input.Key.LeftArrow))
            {
                mov.x -= speed;
                PlayerSprite.Player.CurrentAnimationLibrary = PlayerSprite.Player.AnimationLibrary["left"];
                dir = "left";
            }
            if (inp.KeyPressed(Input.Key.DownArrow))
            {
                mov.y += speed;
                PlayerSprite.Player.CurrentAnimationLibrary = PlayerSprite.Player.AnimationLibrary["down"];
                dir = "down";
            }
            if (inp.KeyPressed(Input.Key.UpArrow))
            {
                mov.y -= speed;
                PlayerSprite.Player.CurrentAnimationLibrary = PlayerSprite.Player.AnimationLibrary["up"];
                dir = "up";
            }

            if (mov == (0, 0))
            {
                PlayerSprite.Player.AnimationFrame = 0;
            }


            PlayerHitbox.MoveX(mov.x);
            if (GetAllTileIDsAt(PlayerHitbox.Position).Contains(1))
            {
                PlayerHitbox.MoveX(-mov.x);
            }

            PlayerHitbox.MoveY(mov.y);

            if (GetAllTileIDsAt(PlayerHitbox.Position).Contains(1))
            {
                PlayerHitbox.MoveY(-mov.y);
            }

            if (GetAllTileIDsAt(PlayerHitbox.Position).Contains(3))
            {
                (double x, double y) pos = PlayerHitbox.Position;
                pos.x /= 10.0;
                pos.y /= 10.0;
                (int x, int y) size = current_map.Size;// (current_map.map.GetLength(0), current_map.map.GetLength(1));
                (int x, int y) temp_pos = room_position;
                size.x /= 2;
                size.y /= 2;

                if (Math.Abs(pos.x - size.x) > Math.Abs(pos.y - size.y))
                {
                    if (pos.x - size.x > 0)
                    {
                        temp_pos.x++;
                        PlayerHitbox.Position = (10, size.y * 10);
                    }
                    else
                    {
                        temp_pos.x--;
                        PlayerHitbox.Position = ((size.x * 20) - 20, size.y * 10);
                    }
                }
                else
                {
                    if (pos.y - size.y > 0)
                    {
                        PlayerHitbox.Position = ((size.x * 10) - 5, 10);
                        temp_pos.y--;
                    }
                    else
                    {
                        PlayerHitbox.Position = ((size.x * 10) - 5, (size.y * 20) - 10);
                        temp_pos.y++;
                    }
                }

                for (int i = 0; i < PlayerBullets.Count;)
                {
                    PlayerBullet temp = PlayerBullets[i];
                    engine.RemoveObjectFromScene(temp.BulletObj);
                    PlayerBullets.Remove(temp);
                }

                for (int i = 0; i < EnemyBullets.Count;)
                {
                    EnemyBullet temp = EnemyBullets[i];
                    engine.RemoveObjectFromScene(temp.BulletObj);
                    EnemyBullets.Remove(temp);
                }

                EnterNewRoom(temp_pos);
                PlayerHitbox.Update();
            }
            if (PlayerSprite.Position != PlayerHitbox.Position)
            {
                PlayerSprite.Position = PlayerHitbox.Position;
                PlayerSprite.Update();
            }
        }

        static void Main()
        {
            Input inp = new Input();
            engine = new MainEngine((200, 170, 5), true, "Consolas");
            engine.CameraPosition = (0, 20);
            engine.RenderFrame(-1);
            numbers = new Graphics.Sprite_Lib();

            numbers.Sprites.Add("0", new Graphics.Sprite(@"Engine\Sprites\UI\Numbers\num_0.mesf", false));
            numbers.Sprites.Add("1", new Graphics.Sprite(@"Engine\Sprites\UI\Numbers\num_1.mesf", false));
            numbers.Sprites.Add("2", new Graphics.Sprite(@"Engine\Sprites\UI\Numbers\num_2.mesf", false));
            numbers.Sprites.Add("3", new Graphics.Sprite(@"Engine\Sprites\UI\Numbers\num_3.mesf", false));
            numbers.Sprites.Add("4", new Graphics.Sprite(@"Engine\Sprites\UI\Numbers\num_4.mesf", false));
            numbers.Sprites.Add("5", new Graphics.Sprite(@"Engine\Sprites\UI\Numbers\num_5.mesf", false));
            numbers.Sprites.Add("6", new Graphics.Sprite(@"Engine\Sprites\UI\Numbers\num_6.mesf", false));
            numbers.Sprites.Add("7", new Graphics.Sprite(@"Engine\Sprites\UI\Numbers\num_7.mesf", false));
            numbers.Sprites.Add("8", new Graphics.Sprite(@"Engine\Sprites\UI\Numbers\num_8.mesf", false));
            numbers.Sprites.Add("9", new Graphics.Sprite(@"Engine\Sprites\UI\Numbers\num_9.mesf", false));
            numbers.Sprites.Add("-", new Graphics.Sprite(@"Engine\Sprites\UI\Numbers\num_-.mesf", false));
            numbers.Sprites.Add("counter", new Graphics.Sprite(@"Engine\Sprites\UI\Numbers\coincounter.mesf", false));

            Object Title = new Object();
            Title.ActiveObjectType = 1;
            Title.Player.ActiveSprite = new Graphics.Sprite(@"Engine\Sprites\Screen\title.mesf", false);

            bool quit = false;

            Sound menu = new Sound(@"Engine\Sounds\menu.wav");
            menu.Volume = 30;

            while (!quit)
            {
                Console.Clear();
                engine.AddObjectToScene(Title);
                engine.RenderFrame(-1);
                {
                    if (!File.Exists("highscore.txt"))
                    {
                        {
                            StreamWriter write = new StreamWriter("highscore.txt");
                            write.WriteLine("0");
                            write.Close();
                        }
                    }
                    StreamReader read = new StreamReader("highscore.txt");
                    int coin_max = int.Parse(read.ReadLine());
                    read.Close();
                    Console.Title = $"Demo Game - Press Space To Play! - Highscore: {coin_max}";
                }

                while (inp.KeyPressed(Input.Key.Spacebar))
                {

                }
                while (!inp.KeyPressed(Input.Key.Spacebar))
                {

                }
                menu.Play(false);
                while (inp.KeyPressed(Input.Key.Spacebar))
                {

                }


                engine.RemoveObjectFromScene(Title);


                rooms_pos = new List<(int x, int y)>();
                room_tilemaps = new List<Tilemap>();
                engine.CameraPosition = (0, 20);


                room_position = (0, 0);

                rooms_pos.Add((0, 0));
                room_tilemaps.Add(TileMapGenerator.GenRoom("start", (20, 15)));
                current_map = room_tilemaps[rooms_pos.IndexOf(room_position)];
                EnterNewRoom((0, 0));

                Object PlayerHitbox = new Object();
                PlayerHitbox.ActiveObjectType = 1;
                PlayerHitbox.Player.ActiveSprite = new Graphics.Sprite(@"Engine\Sprites\Player\hitbox.mesf", false);
                PlayerHitbox.Layer = 3;
                PlayerHitbox.Shown = false;
                PlayerHitbox.Position = ((current_map.Size.x * 5) - 5, (current_map.Size.y * 10) - 20);
                engine.AddObjectToScene(PlayerHitbox);

                Object PlayerSprite = new Object();
                PlayerSprite.ActiveObjectType = 1;

                {
                    Graphics.Sprite_Lib templib = new Graphics.Sprite_Lib();
                    templib.Sprites.Add("1", new Graphics.Sprite(@"Engine\Sprites\Player\player_up_1.mesf", false));
                    templib.Sprites.Add("2", new Graphics.Sprite(@"Engine\Sprites\Player\player_up_2.mesf", false));
                    PlayerSprite.Player.AnimationLibrary.Add("up", templib);
                }
                {
                    Graphics.Sprite_Lib templib = new Graphics.Sprite_Lib();
                    templib.Sprites.Add("1", new Graphics.Sprite(@"Engine\Sprites\Player\player_down_1.mesf", false));
                    templib.Sprites.Add("2", new Graphics.Sprite(@"Engine\Sprites\Player\player_down_2.mesf", false));
                    PlayerSprite.Player.AnimationLibrary.Add("down", templib);
                }
                {
                    Graphics.Sprite_Lib templib = new Graphics.Sprite_Lib();
                    templib.Sprites.Add("1", new Graphics.Sprite(@"Engine\Sprites\Player\player_left_1.mesf", false));
                    templib.Sprites.Add("2", new Graphics.Sprite(@"Engine\Sprites\Player\player_left_2.mesf", false));
                    PlayerSprite.Player.AnimationLibrary.Add("left", templib);
                }
                {
                    Graphics.Sprite_Lib templib = new Graphics.Sprite_Lib();
                    templib.Sprites.Add("1", new Graphics.Sprite(@"Engine\Sprites\Player\player_right_1.mesf", false));
                    templib.Sprites.Add("2", new Graphics.Sprite(@"Engine\Sprites\Player\player_right_2.mesf", false));
                    PlayerSprite.Player.AnimationLibrary.Add("right", templib);
                }
                PlayerSprite.Player.SetNewActiveAnimation(PlayerSprite.Player.AnimationLibrary["up"]);
                PlayerSprite.Player.IsSpriteAnimated = true;
                PlayerSprite.Player.AnimationSpeed = 5;


                Object PlayerItem = new Object();
                PlayerItem.ActiveObjectType = 1;
                PlayerItem.Layer = 5;
                PlayerItem.Player.SpriteLibrary = new Graphics.Sprite_Lib();


                PlayerItem.Player.SpriteLibrary.Sprites.Add("empty_right", new Graphics.Sprite());

                PlayerItem.Player.SpriteLibrary.Sprites.Add("gun_right", new Graphics.Sprite(@"Engine\Sprites\PlayerItems\gun_right.mesf", false));
                PlayerItem.Player.SpriteLibrary.Sprites.Add("gun_left", new Graphics.Sprite(@"Engine\Sprites\PlayerItems\gun_left.mesf", false));

                PlayerItem.Player.SpriteLibrary.Sprites.Add("mgun_right", new Graphics.Sprite(@"Engine\Sprites\PlayerItems\mgun_right.mesf", false));
                PlayerItem.Player.SpriteLibrary.Sprites.Add("mgun_left", new Graphics.Sprite(@"Engine\Sprites\PlayerItems\mgun_left.mesf", false));


                PlayerItem.OffsetPosition = (0, -10);
                PlayerItem.Position = PlayerHitbox.Position;
                engine.AddObjectToScene(PlayerItem);


                PlayerSprite.Layer = 4;
                PlayerSprite.OffsetPosition = (0, -10);
                PlayerSprite.Position = PlayerHitbox.Position;
                engine.AddObjectToScene(PlayerSprite);

                Graphics.Sprite_Lib hearts = new Graphics.Sprite_Lib();
                hearts.Sprites.Add("full", new Graphics.Sprite(@"Engine\Sprites\UI\heart_1.mesf", false));
                hearts.Sprites.Add("empty", new Graphics.Sprite(@"Engine\Sprites\UI\heart_0.mesf", false));



                Object Health_1 = new Object();
                Health_1.ActiveObjectType = 1;
                Health_1.Player.ActiveSprite = hearts.Sprites["full"];
                Health_1.Layer = 10;
                Health_1.Position = (0, -20);
                engine.AddObjectToScene(Health_1);

                Object Health_2 = Health_1.Clone();
                Health_2.Position = (10, -20);
                engine.AddObjectToScene(Health_2);

                Object Health_3 = Health_1.Clone();
                Health_3.Position = (20, -20);
                engine.AddObjectToScene(Health_3);

                /*
                {
                    Enemy TestEnemie = BaseEnemy.GetEnemy(0);
                    TestEnemie.enemy.Position = (30, 20);
                    current_map.Enemies.Add(TestEnemie);
                }

                {
                    Enemy TestEnemie = BaseEnemy.GetEnemy(0);
                    TestEnemie.enemy.Position = (50, 20);
                    current_map.Enemies.Add(TestEnemie);
                }
                */
                current_map.AddObjectsToScene(engine);

                engine.RenderFrame(-1);
                engine.MoveXCameraPosition(0);

                int health = 3;
                int speed = 5;
                int invincibilty = 0;
                int item_use = 0;
                int item = 1;

                int coins = 0;

                List<Object> coinobjects = new List<Object>();
                {
                    Object coincounter = new Object();
                    coincounter.ActiveObjectType = 1;
                    coincounter.Player.ActiveSprite = numbers.Sprites["counter"];
                    coincounter.Layer = 10;
                    coincounter.Position = (40, -20);
                    engine.AddObjectToScene(coincounter);
                    coinobjects.Add(coincounter);
                }



                string direction = "up";

                bool pause = false;
                bool pause_2 = false;

                Object Pause = new Object();
                Pause.ActiveObjectType = 1;
                Pause.Layer = 10;
                Pause.Player.ActiveSprite = new Graphics.Sprite(@"Engine\Sprites\Screen\pause.mesf", false);
                Pause.Position = (50, 50);

                List<PlayerBullet> PlayerBullets = new List<PlayerBullet>();


                List<EnemyBullet> EnemyBullets = new List<EnemyBullet>();

                Sound shoot = new Sound(@"Engine\Sounds\shoot.wav");
                shoot.MaximumQueueLength = 2;
                shoot.Volume = 40;

                Sound hurt = new Sound(@"Engine\Sounds\hurt.wav");
               hurt.Volume = 40;

                Sound gun = new Sound(@"Engine\Sounds\gun.wav");
                gun.Volume = 50;

                Sound itemsound = new Sound(@"Engine\Sounds\item.wav");
                itemsound.Volume = 50;

                Sound coin = new Sound(@"Engine\Sounds\coin.wav");
                coin.Volume = 50;

                Sound ded = new Sound(@"Engine\Sounds\ded.wav");
                ded.Volume = 40;

                //shoot.Play(false);

                Random rnd = new Random();
                int frame = 0;
                while (health > 0)
                {
                    if (!pause)
                    {
                        UpdateHealth(Health_1, Health_2, Health_3, health, hearts);
                        PlayerMovement(PlayerHitbox, inp, speed, PlayerSprite, ref direction, PlayerBullets, EnemyBullets);
                        PlayerItemManagement(PlayerItem, PlayerHitbox, item, direction);
                        CoinHandling(coinobjects, coins, engine);
                        BulletMovement(rnd, PlayerBullets, EnemyBullets, ded);


                        if (item_use == 0)
                        {
                            if (inp.KeyPressed(Input.Key.Spacebar))
                            {
                                if (item == 1)
                                {
                                    item_use = 5;
                                    shoot.Play(false);
                                    if (direction == "right" || direction == "up")
                                    {
                                        {
                                            PlayerBullet temp = new PlayerBullet(PlayerHitbox.Position, direction);
                                            PlayerBullets.Add(temp);
                                            temp.BulletObj.OffsetPosition = (10, -1);
                                            engine.AddObjectToScene(temp.BulletObj);
                                        }
                                    }
                                    if (direction == "down" || direction == "left")
                                    {
                                        {
                                            PlayerBullet temp = new PlayerBullet(PlayerHitbox.Position, direction);
                                            PlayerBullets.Add(temp);
                                            temp.BulletObj.OffsetPosition = (-1, -1);
                                            engine.AddObjectToScene(temp.BulletObj);
                                        }
                                    }
                                }
                                if (item == 2)
                                {
                                    item_use = 3;
                                    shoot.Play(false);
                                    if (direction == "right" || direction == "up")
                                    {
                                        {
                                            PlayerBullet temp = new PlayerBullet(PlayerHitbox.Position, direction);
                                            temp.BulletObj.Player.ActiveSprite = new Graphics.Sprite(@"Engine\Sprites\PlayerItems\mbullet.mesf", true);
                                            PlayerBullets.Add(temp);
                                            temp.BulletObj.OffsetPosition = (10, -1);
                                            engine.AddObjectToScene(temp.BulletObj);
                                        }
                                    }
                                    if (direction == "down" || direction == "left")
                                    {
                                        {
                                            PlayerBullet temp = new PlayerBullet(PlayerHitbox.Position, direction);
                                            PlayerBullets.Add(temp);
                                            temp.BulletObj.OffsetPosition = (-1, -1);
                                            engine.AddObjectToScene(temp.BulletObj);
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            item_use--;
                        }




                        if (frame % 40 == 0)
                        {
                            foreach (Enemy x in current_map.Enemies)
                            {
                                x.enemy_active = (rnd.Next(0, 2) == 0);
                            }
                        }



                        foreach (Enemy x in current_map.Enemies)
                        {
                            if (x.enemy_active)
                            {
                                if (x.Enemy_type == 0 && (frame % 3 == 0))
                                {
                                    EnemyMovement(x, PlayerHitbox, ref x.enemy_randomnes);

                                }
                                if (x.Enemy_type == 1 && (frame % 4 == 0))
                                {
                                    EnemyMovement(x, PlayerHitbox, ref x.enemy_randomnes);

                                    if (rnd.Next(0, 7) == 3)
                                    {
                                        shoot.Play(false);
                                        EnemyBullet temp = new EnemyBullet(x.enemy.Position, direction);
                                        temp.BulletObj.Update();
                                        engine.AddObjectToScene(temp.BulletObj);
                                        EnemyBullets.Add(temp);
                                    }

                                }
                            }
                            else
                            {
                                if (frame % 20 == 0)
                                {
                                    x.enemy_active = (rnd.Next(0, 2) == 0);
                                }
                            }
                        }




                        if (frame % 2 == 0)
                        {
                            for (int i = 0; i < current_map.Items.Count; i++)
                            {
                                Item x = current_map.Items[i];
                                if (CheckCollision(PlayerHitbox, x.item))
                                {
                                    if (x.Item_type == 0)
                                    {
                                        itemsound.Play(false);
                                        if (health < 3)
                                        {
                                            health++;
                                        }
                                        engine.RemoveObjectFromScene(x.item);
                                        current_map.Items.Remove(x);
                                        i--;
                                    }
                                    if (x.Item_type == 1)
                                    {
                                        coin.Play(false);
                                        coins++;
                                        engine.RemoveObjectFromScene(x.item);
                                        current_map.Items.Remove(x);
                                        i--;
                                    }
                                    if (x.Item_type == 2)
                                    {
                                        gun.Play(false);
                                        item = 2;
                                        engine.RemoveObjectFromScene(x.item);
                                        current_map.Items.Remove(x);
                                        i--;
                                    }
                                }
                            }



                            if (invincibilty == 0)
                            {
                                bool touch = false;
                                foreach (Enemy x in current_map.Enemies)
                                {
                                    if (CheckCollision(PlayerHitbox, x.enemy))
                                    {
                                        touch = true;
                                    }
                                }
                                foreach (EnemyBullet x in EnemyBullets)
                                {
                                    if (CheckCollision(PlayerHitbox, x.BulletObj))
                                    {
                                        touch = true;
                                    }
                                }

                                if (touch)
                                {
                                    hurt.Play(false);
                                    health--;
                                    invincibilty = 20;
                                }
                            }
                            else
                            {
                                invincibilty--;
                            }
                        }

                        //Console.Title = $"{room_position.x}|{room_position.y} - {health} - {invincibilty}";
                        if (inp.KeyPressed(Input.Key.Esc))
                        {
                            pause = true;
                            while (inp.KeyPressed(Input.Key.Esc))
                            {

                            }
                        }
                        if (pause_2)
                        {
                            engine.RemoveObjectFromScene(Pause);
                        }


                        pause_2 = false;
                        engine.RenderFrame(20);
                        frame = (frame + 1) % 10000000;
                    }
                    else
                    {
                        if (!pause_2)
                        {
                            engine.AddObjectToScene(Pause);
                            Pause.Update();
                            engine.RenderFrame(-1);
                            pause_2 = true;
                        }

                        if (inp.KeyPressed(Input.Key.Q))
                        {
                            quit = true;
                            break;
                        }
                        if (inp.KeyPressed(Input.Key.R))
                        {
                            break;
                        }
                        if (inp.KeyPressed(Input.Key.Esc))
                        {
                            pause = false;
                            while (inp.KeyPressed(Input.Key.Esc))
                            {

                            }
                        }
                        System.Threading.Thread.Sleep(100);
                    }
                }
                if (!quit)
                {
                    Scene gameover = new Scene();
                    engine.ChangeActiveScene(gameover);
                    engine.RenderFrame(-1);
                    Object Gameover = new Object();
                    Gameover.ActiveObjectType = 1;
                    Gameover.Player.ActiveSprite = new Graphics.Sprite(@"Engine\Sprites\Screen\gameover.mesf", false);
                    engine.AddObjectToScene(Gameover);
                    engine.RenderFrame(-1);

                    if (!File.Exists("highscore.txt"))
                    {
                        {
                            StreamWriter write = new StreamWriter("highscore.txt");
                            write.WriteLine("0");
                            write.Close();
                        }
                    }
                    StreamReader read = new StreamReader("highscore.txt");
                    int coin_max = int.Parse(read.ReadLine());
                    read.Close();

                    if (coins > coin_max)
                    {
                        coin_max = coins;
                        Console.Title = "Game Over :( - Press Space to retry - new Highscore!";
                    }
                    else
                    {
                        Console.Title = "Game Over :( - Press Space to retry";
                    }

                    {
                        StreamWriter write = new StreamWriter("highscore.txt");
                        write.WriteLine(coin_max);
                        write.Close();
                    }




                    while (inp.KeyPressed(Input.Key.Spacebar))
                    {

                    }
                    while (!inp.KeyPressed(Input.Key.Spacebar))
                    {

                    }
                    menu.Play(false);
                    while (inp.KeyPressed(Input.Key.Spacebar))
                    {

                    }
                    engine.RemoveObjectFromScene(Gameover);
                }

            }
        }

        static void BulletMovement(Random rnd, List<PlayerBullet> PlayerBullets, List<EnemyBullet> EnemyBullets, Sound ded)
        {
            for (int i = 0; i < PlayerBullets.Count; i++)
            {

                PlayerBullet temp = PlayerBullets[i];
                temp.steps++;
                if (temp.steps < 15)
                {
                    if (temp.direction == "up")
                    {
                        temp.BulletObj.MoveY(-5);
                    }
                    if (temp.direction == "down")
                    {
                        temp.BulletObj.MoveY(5);
                    }
                    if (temp.direction == "left")
                    {
                        temp.BulletObj.MoveX(-5);
                    }
                    if (temp.direction == "right")
                    {
                        temp.BulletObj.MoveX(5);
                    }


                    bool touch = false;
                    for (int i2 = 0; i2 < current_map.Enemies.Count; i2++)
                    {
                        Enemy x = current_map.Enemies[i2];
                        if (CheckCollision(temp.BulletObj, x.enemy))
                        {
                            touch = true;
                            x.health--;
                            if (x.health <= 0)
                            {
                                ded.Play(false);
                                if (rnd.Next(0, 100) >= 50)
                                {
                                    Item test = BaseItem.GetItem(rnd.Next(0, 2));
                                    test.item.Position = x.enemy.Position;
                                    current_map.Items.Add(test);
                                    engine.AddObjectToScene(test.item);
                                }
                                else
                                {
                                    if (rnd.Next(0, 100) >= 90)
                                    {
                                        Item test = BaseItem.GetItem(2);
                                        test.item.Position = x.enemy.Position;
                                        current_map.Items.Add(test);
                                        engine.AddObjectToScene(test.item);
                                    }
                                }


                                engine.RemoveObjectFromScene(x.enemy);
                                current_map.Enemies.Remove(x);
                                i2--;
                            }
                        }
                    }

                    if (GetAllTileIDsAt(temp.BulletObj.Position).Contains(1))
                    {
                        touch = true;
                    }


                    if (touch)
                    {
                        engine.RemoveObjectFromScene(temp.BulletObj);
                        PlayerBullets.Remove(temp);
                        i--;
                    }
                }
                else
                {
                    engine.RemoveObjectFromScene(temp.BulletObj);
                    PlayerBullets.Remove(temp);
                    i--;
                }
            }





            for (int i = 0; i < EnemyBullets.Count; i++)
            {

                EnemyBullet temp = EnemyBullets[i];
                temp.steps++;
                if (temp.steps < 15)
                {
                    if (temp.direction == "up")
                    {
                        temp.BulletObj.MoveY(-10);
                    }
                    if (temp.direction == "down")
                    {
                        temp.BulletObj.MoveY(10);
                    }
                    if (temp.direction == "left")
                    {
                        temp.BulletObj.MoveX(-10);
                    }
                    if (temp.direction == "right")
                    {
                        temp.BulletObj.MoveX(10);
                    }


                    bool touch = false;
                    for (int i2 = 0; i2 < current_map.Items.Count; i2++)
                    {
                        Item x = current_map.Items[i2];
                        if (CheckCollision(temp.BulletObj, x.item))
                        {
                            touch = true;

                            engine.RemoveObjectFromScene(x.item);
                            current_map.Items.Remove(x);
                            i2--;

                        }
                    }

                    if (GetAllTileIDsAt(temp.BulletObj.Position).Contains(1))
                    {
                        touch = true;
                    }



                    if (touch)
                    {
                        engine.RemoveObjectFromScene(temp.BulletObj);
                        EnemyBullets.Remove(temp);
                        i--;
                    }
                }
                else
                {
                    engine.RemoveObjectFromScene(temp.BulletObj);
                    EnemyBullets.Remove(temp);
                    i--;
                }
            }
        }


        static void CoinHandling(List<Object> coinobjects, int coins, MainEngine engine)
        {
            for (int i = coinobjects.Count; i <= $"{coins}".Length; i++)
            {
                Object temp = new Object();
                temp.ActiveObjectType = 1;
                temp.Player.ActiveSprite = numbers.Sprites["0"];
                temp.Layer = 10;
                temp.Position = (40, -20);
                engine.AddObjectToScene(temp);
                coinobjects.Add(temp);
            }
            // 3 1
            for (int i = coinobjects.Count; i > $"{coins}".Length + 1; i--)
            {
                Object temp = coinobjects.Last();
                engine.RemoveObjectFromScene(temp);
                coinobjects.Remove(temp);
            }

            for (int i = 1; i < coinobjects.Count; i++)
            {
                Object temp = coinobjects[i];
                temp.Position = ((40 + i * 10), -20);
                temp.Player.ActiveSprite = numbers.Sprites[$"{$"{coins}"[i - 1]}"];
                temp.Update();
            }
        }


        static void PlayerItemManagement(Object PlayerItem, Object PlayerHitbox, int item, string direction)
        {
            PlayerItem.Position = PlayerHitbox.Position;
            PlayerItem.Update();
            if (item == 0)
            {
                PlayerItem.Player.ActiveSprite = PlayerItem.Player.SpriteLibrary.Sprites["empty"];
            }
            if (item == 1)
            {
                if (direction == "up" || direction == "right")
                {
                    PlayerItem.Player.ActiveSprite = PlayerItem.Player.SpriteLibrary.Sprites["gun_right"];
                }
                else
                {
                    PlayerItem.Player.ActiveSprite = PlayerItem.Player.SpriteLibrary.Sprites["gun_left"];
                }
            }
            if (item == 2)
            {
                if (direction == "up" || direction == "right")
                {
                    PlayerItem.Player.ActiveSprite = PlayerItem.Player.SpriteLibrary.Sprites["mgun_right"];
                }
                else
                {
                    PlayerItem.Player.ActiveSprite = PlayerItem.Player.SpriteLibrary.Sprites["mgun_left"];
                }
            }
        }


        static void UpdateHealth(Object h1, Object h2, Object h3, int health, Graphics.Sprite_Lib imgs)
        {
            h1.Player.ActiveSprite = imgs.Sprites["empty"];
            h2.Player.ActiveSprite = imgs.Sprites["empty"];
            h3.Player.ActiveSprite = imgs.Sprites["empty"];
            if (health >= 1)
            {
                h1.Player.ActiveSprite = imgs.Sprites["full"];
            }
            if (health >= 2)
            {
                h2.Player.ActiveSprite = imgs.Sprites["full"];
            }
            if (health >= 3)
            {
                h3.Player.ActiveSprite = imgs.Sprites["full"];
            }
            h1.Update();
            h2.Update();
            h3.Update();
        }

        static bool CheckCollision(Object A, Object B)
        {
            (int a, int b) temp_layers = (0, 0);
            temp_layers.a = A.Layer;
            temp_layers.b = B.Layer;

            A.Layer = 1000;
            B.Layer = 1000;
            bool cool = engine.CheckObjectCollision(A, B);

            A.Layer = temp_layers.a;
            B.Layer = temp_layers.b;

            return cool;
        }


        static void EnemyMovement(Enemy enemy_, Object Player, ref int randomness)
        {
            Object enemy = enemy_.enemy;
            int speed = 5;
            Random rnd = new Random();
            (int x, int y) mov = (0, 0);//(rnd.Next(-1,2), rnd.Next(-1, 2));

            if (Math.Abs(Player.Position.x - enemy.Position.x) > 0)
            {
                if (Player.Position.x > enemy.Position.x)
                {
                    mov.x = 1;
                    enemy_.dir = "right";
                }
                else
                {
                    mov.x = -1;
                    enemy_.dir = "left";
                }
            }
            if (Math.Abs(Player.Position.y - enemy.Position.y) > 0)
            {
                if (Player.Position.y > enemy.Position.y)
                {
                    mov.y = 1;
                    enemy_.dir = "down";
                }
                else
                {
                    mov.y = -1;
                    enemy_.dir = "up";
                }
            }
            enemy.Player.ActiveSprite = enemy.Player.SpriteLibrary.Sprites[enemy_.dir];


            if (rnd.Next(0, 90) <= randomness)
            {
                if (rnd.Next(0, 2) == 0)
                {
                    mov.x = (rnd.Next(1, 3) * 2) - 3;
                }
                else
                {
                    mov.y = (rnd.Next(1, 3) * 2) - 3;
                }
            }


            mov.x *= speed;
            mov.y *= speed;

            enemy.MoveX(mov.x);
            if (GetAllTileIDsAt(enemy.Position).Contains(1))
            {
                if (randomness < 80)
                {
                    randomness++;
                }
                enemy.MoveX(-mov.x);
            }
            else
            {
                if (randomness > 0)
                {
                    randomness--;
                }
            }

            enemy.MoveY(mov.y);
            if (GetAllTileIDsAt(enemy.Position).Contains(1))
            {
                if (randomness < 80)
                {
                    randomness++;
                }
                enemy.MoveY(-mov.y);
            }
            else
            {
                if (randomness > 0)
                {
                    randomness--;
                }
            }

        }

        public static List<int> GetAllTileIDsAt((double x, double y) pos)
        {
            List<int> ids = new List<int>();
            pos.x /= 10.0;
            pos.y /= 10.0;

            try
            {
                ids.Add(current_map.map[(int)Math.Floor(pos.x), (int)Math.Floor(pos.y)]);
                ids.Add(current_map.map[(int)Math.Floor(pos.x), (int)Math.Ceiling(pos.y)]);
                ids.Add(current_map.map[(int)Math.Ceiling(pos.x), (int)Math.Floor(pos.y)]);
                ids.Add(current_map.map[(int)Math.Ceiling(pos.x), (int)Math.Ceiling(pos.y)]);
            }
            catch
            {
            }

            return ids;
        }
    }
}
