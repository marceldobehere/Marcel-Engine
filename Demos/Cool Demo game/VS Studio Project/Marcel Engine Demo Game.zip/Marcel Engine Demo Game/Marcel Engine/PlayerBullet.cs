﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;
using Object = Engine.Object;

namespace Testing_the_engine_lol
{
    class PlayerBullet
    {
        public Object BulletObj;
        public string direction;
        public int steps;

        public PlayerBullet((int x, int y) pos, string direction)
        {
            steps = 0;
            this.direction = direction;
            BulletObj = new Object();
            BulletObj.ActiveObjectType = 1;
            BulletObj.Position = pos;
            BulletObj.Layer = 6;
            BulletObj.Player.ActiveSprite = new Graphics.Sprite(@"Engine\Sprites\PlayerItems\bullet.mesf", true);
        }
    }
    class EnemyBullet
    {
        public Object BulletObj;
        public string direction;
        public int steps;

        public EnemyBullet((int x, int y) pos, string direction)
        {
            steps = 0;
            this.direction = direction;
            BulletObj = new Object();
            BulletObj.ActiveObjectType = 1;
            BulletObj.Position = pos;
            BulletObj.Layer = 6;
            BulletObj.Player.ActiveSprite = new Graphics.Sprite(@"Engine\Sprites\Enemy\fireball.mesf", true);
        }
    }

}
