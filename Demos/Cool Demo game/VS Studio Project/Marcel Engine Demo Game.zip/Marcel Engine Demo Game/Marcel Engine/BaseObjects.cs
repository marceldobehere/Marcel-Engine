﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;
using Object = Engine.Object;

namespace Testing_the_engine_lol
{
    class BaseEnemy
    {
        public static Enemy GetEnemy(int type)
        {
            Enemy EnemyBase = new Enemy();
            if (type == 0)
            {
                EnemyBase.Enemy_type = 0;
                EnemyBase.enemy.ActiveObjectType = 1;
                EnemyBase.enemy.Player.SpriteLibrary.Sprites.Add("up", new Graphics.Sprite(@"Engine\Sprites\Enemy\stone_up.mesf", false));
                EnemyBase.enemy.Player.SpriteLibrary.Sprites.Add("down", new Graphics.Sprite(@"Engine\Sprites\Enemy\stone_down.mesf", false));
                EnemyBase.enemy.Player.SpriteLibrary.Sprites.Add("left", new Graphics.Sprite(@"Engine\Sprites\Enemy\stone_left.mesf", false));
                EnemyBase.enemy.Player.SpriteLibrary.Sprites.Add("right", new Graphics.Sprite(@"Engine\Sprites\Enemy\stone_right.mesf", false));
                EnemyBase.enemy.Player.ActiveSprite = new Graphics.Sprite(@"Engine\Sprites\Enemy\stone.mesf", false);
                EnemyBase.enemy.Layer = 2;
                EnemyBase.health = 3;
            }
            if (type == 1)
            {
                EnemyBase.Enemy_type = 1;
                EnemyBase.enemy.ActiveObjectType = 1;
                EnemyBase.enemy.Player.SpriteLibrary.Sprites.Add("up", new Graphics.Sprite(@"Engine\Sprites\Enemy\firestone_up.mesf", false));
                EnemyBase.enemy.Player.SpriteLibrary.Sprites.Add("down", new Graphics.Sprite(@"Engine\Sprites\Enemy\firestone_down.mesf", false));
                EnemyBase.enemy.Player.SpriteLibrary.Sprites.Add("left", new Graphics.Sprite(@"Engine\Sprites\Enemy\firestone_left.mesf", false));
                EnemyBase.enemy.Player.SpriteLibrary.Sprites.Add("right", new Graphics.Sprite(@"Engine\Sprites\Enemy\firestone_right.mesf", false));
                EnemyBase.enemy.Player.ActiveSprite = new Graphics.Sprite(@"Engine\Sprites\Enemy\firestone.mesf", false);
                EnemyBase.enemy.Layer = 2;
                EnemyBase.health = 5;
            }

            return EnemyBase;
        }
    }


    class BaseItem
    {
        public static Item GetItem(int type)
        {
            Item ItemBase = new Item();
            if (type == 0)
            {
                ItemBase.Item_type = 0;
                ItemBase.item.ActiveObjectType = 1;
                ItemBase.item.Player.ActiveSprite = new Graphics.Sprite(@"Engine\Sprites\Item\potion.mesf", false);
                ItemBase.item.Layer = 2;
                ItemBase.item.OffsetPosition = (0, -2);
            }
            if (type == 1)
            {
                ItemBase.Item_type = 1;
                ItemBase.item.ActiveObjectType = 1;
                ItemBase.item.Player.ActiveSprite = new Graphics.Sprite(@"Engine\Sprites\Item\coin.mesf", false);
                ItemBase.item.Layer = 2;
                ItemBase.item.OffsetPosition = (0, -2);
            }
            if (type == 2)
            {
                ItemBase.Item_type = 2;
                ItemBase.item.ActiveObjectType = 1;
                ItemBase.item.Player.ActiveSprite = new Graphics.Sprite(@"Engine\Sprites\PlayerItems\mgun.mesf",false);
                ItemBase.item.Layer = 2;
                ItemBase.item.OffsetPosition = (0, -2);
            }

            return ItemBase;
        }
    }
}
