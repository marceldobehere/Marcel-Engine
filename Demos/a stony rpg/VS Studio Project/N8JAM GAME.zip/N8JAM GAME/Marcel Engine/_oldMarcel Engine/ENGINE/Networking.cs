﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Net;
using System.Net.Sockets;

namespace Engine
{

    /// <summary>
    /// Networking class
    /// </summary>
    public class Networking
    {
        /// <summary>
        /// A Server object.
        /// </summary>
        public class Server
        {
            public Server()
            {
                Reply = "";
                Received = "";
                IP = "";
            }
            /// <summary>
            /// What the Server will reply.
            /// </summary>
            public string Reply;
            /// <summary>
            /// What the Server received.
            /// </summary>
            public string Received;
            /// <summary>
            /// The Servers IP.
            /// </summary>
            public string IP;
            /// <summary>
            /// Start the Server with an IP.
            /// </summary>
            public void Start(string _IP)
            {
                IP = _IP;
                Thread Server = new Thread(() =>
                {
                    SocketServer server = new SocketServer();
                    server.Main(IP, ref Reply, ref Received);

                });
                Server.Start();
            }
        }
        /// <summary>
        /// A Client object.
        /// </summary>
        public class Client
        {
            public Client()
            {
                ToSend = "";
                Received = "";
                IP = "";
            }
            /// <summary>
            /// What the Client will send.
            /// </summary>
            public string ToSend;
            /// <summary>
            /// What the Client received from the Server.
            /// </summary>
            public string Received;
            /// <summary>
            /// What the Clients IP is.
            /// </summary>
            public string IP;
            /// <summary>
            /// Start the Client with an IP.
            /// </summary>
            public void Start(string _IP)
            {
                IP = _IP;
                Thread Client = new Thread(() =>
                {
                    SocketClient client = new SocketClient();
                    client.Main(IP, ref ToSend, ref Received);
                });
                Client.Start();
            }
        }
        public Client Client_;
        public Server Server_;

        public Networking()
        {
            Client_ = new Client();
            Server_ = new Server();
        }

        public void SendData(string data)
        {
            Client_.Received = "";
            Client_.ToSend = data;
        }












        public class SocketClient
        {
            public int Main(string IP, ref string send, ref string receive)
            {
                //Console.WriteLine("Starting...");
                StartClient(IP, ref send, ref receive);
                return 0;
            }


            public static void StartClient(string IP, ref string send, ref string receive)
            {
                byte[] bytes = new byte[1024];

                while (true)
                {
                    if (send != "")
                    {
                        try
                        {
                            // Connect to a Remote server  
                            // Get Host IP Address that is used to establish a connection  
                            // In this case, we get one IP address of localhost that is IP : 127.0.0.1  
                            // If a host has multiple addresses, you will get a list of addresses  
                            IPHostEntry host = Dns.GetHostEntry(IP);
                            IPAddress ipAddress = host.AddressList[0];
                            IPEndPoint remoteEP = new IPEndPoint(ipAddress, 11000);

                            // Create a TCP/IP  socket.    
                            Socket sender = new Socket(ipAddress.AddressFamily,
                                SocketType.Stream, ProtocolType.Tcp);

                            // Connect the socket to the remote endpoint. Catch any errors.    
                            try
                            {
                                // Connect to Remote EndPoint  
                                sender.Connect(remoteEP);

                                //Console.WriteLine("Socket connected to {0}",
                                //sender.RemoteEndPoint.ToString());

                                send += "<EOF>";

                                // Encode the data string into a byte array.    
                                byte[] msg = Encoding.ASCII.GetBytes(send);
                                //Console.WriteLine($"Sending data: {send}");
                                send = "";
                                // Send the data through the socket.    
                                int bytesSent = sender.Send(msg);

                                // Receive the response from the remote device.    
                                int bytesRec = sender.Receive(bytes);
                                string treceive = Encoding.ASCII.GetString(bytes, 0, bytesRec);
                                receive = treceive.Substring(0, treceive.Length - 5);
                                //Console.WriteLine("Echoed test = {0}", receive);

                                // Release the socket.    
                                sender.Shutdown(SocketShutdown.Both);
                                sender.Close();

                            }
                            catch
                            {
                                //Console.WriteLine("ArgumentNullException : {0}", ane.ToString());
                            }

                        }
                        catch
                        {
                            //Console.WriteLine(e.ToString());
                        }
                    }
                }
            }
        }



        public class SocketServer
        {
            public int Main(string IP, ref string send, ref string receive)
            {
                //Console.WriteLine("Starting...");
                StartServer(IP, ref send, ref receive);
                return 0;
            }


            public static void StartServer(string IP, ref string send, ref string receive)
            {
                // Get Host IP Address that is used to establish a connection  
                // In this case, we get one IP address of localhost that is IP : 127.0.0.1  
                // If a host has multiple addresses, you will get a list of addresses  
                IPHostEntry host = Dns.GetHostEntry(IP);
                IPAddress ipAddress = host.AddressList[0];
                IPEndPoint localEndPoint = new IPEndPoint(ipAddress, 11000);

                while (true)
                {
                    try
                    {
                        // Create a Socket that will use Tcp protocol      
                        Socket listener = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
                        // A Socket must be associated with an endpoint using the Bind method  
                        listener.Bind(localEndPoint);
                        // Specify how many requests a Socket can listen before it gives Server busy response.  
                        // We will listen 10 requests at a time  
                        listener.Listen(10);

                        //Console.WriteLine("Waiting for a connection...");
                        Socket handler = listener.Accept();

                        // Incoming data from the client.    
                        string data = null;
                        byte[] bytes = null;

                        while (true)
                        {
                            bytes = new byte[1024];
                            int bytesRec = handler.Receive(bytes);
                            data += Encoding.ASCII.GetString(bytes, 0, bytesRec);
                            if (data.IndexOf("<EOF>") > -1)
                            {
                                break;
                            }
                        }

                        send = "";
                        receive = data.Substring(0, data.Length - 5);
                        //Console.WriteLine("Text received : {0}", data);

                        while (send == "")
                        {
                        }
                        receive = "";

                        byte[] msg = Encoding.ASCII.GetBytes(send + "<EOF>");
                        handler.Send(msg);
                        handler.Shutdown(SocketShutdown.Both);
                        handler.Close();
                    }
                    catch
                    {
                        //Console.WriteLine(e.ToString());
                    }

                }

            }


        }

    }

}
