﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;
using Extra;
using Object = Engine.Object;
using Testing_the_engine_lol;
using System.IO;
using Newtonsoft.Json;

namespace Extra
{
    class PreparationsBoss
    {
        public static void PrepareBoss()
        {
            MainGame.BOSS = new Scene();
            MainGame.engine.ChangeActiveScene(MainGame.BOSS);
            MainGame.engine.AddObjectToScene(MainGame.Player);
            MainGame.engine.AddObjectToScene(MainGame.Hitbox);
            MainGame.speed = 1;
            MainGame.engine.CameraPosition = (0, 0);
            MainGame.ActualCameraPosition = (0, 0);
            MainGame.Player.Position = (0, 0);
            MainGame.PlayerPosition = (0, 0);
            MainGame.Player.Update();
            MainGame.engine.AddObjectToScene(MainGame.UI);
            MainGame.UI.Player.ActiveSprite = new Graphics.Sprite(@"Engine\Sprites\UI\UI_NTEXT.mesf", false);
            MainGame.UI.Update();

            MainGame.GameObjects = new List<MainGame.GameObject>();
            {
                Object temp = new Object();
                temp.ActiveObjectType = 1;
                temp.Player.ActiveSprite = new Graphics.Sprite(@"Engine\Sprites\Boss\BOSS.mesf", false);
                temp.Layer = 20;
                temp.Position = (10, 10);
                MainGame.engine.AddObjectToScene(temp);
                MainGame.BossObject = new MainGame.GameObject() { OBJ = temp, EditorName = "Boss", name = "boss", type = 20, wall = false };
                MainGame.GameObjects.Add(MainGame.BossObject);
            }

            {
                Object temp = new Object();
                temp.ActiveObjectType = 1;
                temp.Player.ActiveSprite = new Graphics.Sprite(@"Engine\Sprites\Boss\bomb.mesf", false);
                temp.Layer = 10;
                temp.Position = (10, 10);
                MainGame.BombOBJ = temp;
            }
        }
    }
}
