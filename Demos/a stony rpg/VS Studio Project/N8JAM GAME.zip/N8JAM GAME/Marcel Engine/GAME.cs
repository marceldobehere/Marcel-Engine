﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;
using Extra;
using Object = Engine.Object;
using System.IO;
using System.Text.Json;
using Newtonsoft.Json;


namespace Testing_the_engine_lol
{

    class MainGame
    {
        public static MainEngine engine;
        public static Input inp;

        public static Scene Title;
        public static Scene Game;
        public static Scene BOSS;
        public static Scene END;
        public static Scene Menu;

        public static TerminalClass Terminal;

        public static (int x, int y) PlayerPosition;
        public static (int x, int y) ActualCameraPosition;

        public static List<GameObject> GameObjects;
        public static Dictionary<string, GameObject> EditorObjects;
        public static List<GameObject> ObjectsSpawnedFromEditor;

        public static Object Player;
        public static Object debugPlayer;
        public static Object Hitbox;
        public static Object UI;
        public static Object InventoryCursor;

        public static Object[] TextLines;

        public static (int x, int y) middle_offset;

        public static bool editor_mode;

        public static Dictionary<Item, int> Inventory;

        public static string editor_object_to_spawn;

        public static bool showtext;
        public static string texttoshow;

        public static bool DoorUnlocked;
        public static bool TerminalUnlocked;

        public static int speed;

        public static string[] Passwords;

        public static OneSound OverWorldM;
        public static OneSound TerminalM;
        public static OneSound BossM;
        public static OneSound TitleM;

        public static OneSound SelectS;
        public static OneSound SelectInvS;
        public static OneSound CollectS;
        public static OneSound QuestS;
        public static OneSound QuestDoneS;
        public static OneSound InventoryS;
        public static OneSound TerminalS;
        public static OneSound BombS;
        public static OneSound BossHurtS;
        public static OneSound PlayerHurtS;
        public static OneSound InvalidSelectS;

        public static bool STARTBOSS;


        public static int SFXVolume, BGMVolume;

        public static void ChangeBGM(int x)
        {
            BGMVolume = x;
            TitleM.Volume = BGMVolume;
            TerminalM.Volume = BGMVolume;
            OverWorldM.Volume = BGMVolume;
            BossM.Volume = BGMVolume;
        }
        public static void ChangeSFX(int x)
        {
            SFXVolume = x;
            SelectS.Volume = SFXVolume;
            SelectInvS.Volume = SFXVolume;
            CollectS.Volume = SFXVolume;
            QuestS.Volume = SFXVolume;
            QuestDoneS.Volume = SFXVolume;
            InventoryS.Volume = SFXVolume;
            TerminalS.Volume = SFXVolume;
            BombS.Volume = SFXVolume;
            BossHurtS.Volume = SFXVolume;
            PlayerHurtS.Volume = SFXVolume;
            InvalidSelectS.Volume = SFXVolume;
        }


        static void Main()
        {
            engine = new MainEngine((90, 60, 10), true, "Consolas");
            inp = new Input();

            SelectS = new OneSound(@"Engine\Sounds\select.wav");
            SelectInvS = new OneSound(@"Engine\Sounds\invselect.wav");
            CollectS = new OneSound(@"Engine\Sounds\collect.wav");
            QuestS = new OneSound(@"Engine\Sounds\quest.wav");
            QuestDoneS = new OneSound(@"Engine\Sounds\questdone.wav");
            InventoryS = new OneSound(@"Engine\Sounds\inventory.wav");
            BombS = new OneSound(@"Engine\Sounds\bomb.wav");
            TerminalS = new OneSound(@"Engine\Sounds\terminal.wav");

            InvalidSelectS = new OneSound(@"Engine\Sounds\noselect.wav");

            BossHurtS = new OneSound(@"Engine\Sounds\bosshurt.wav");
            PlayerHurtS = new OneSound(@"Engine\Sounds\hurt.wav");

            BossM = new OneSound(@"Engine\Music\BOSS SONG.mp3");
            OverWorldM = new OneSound(@"Engine\Music\Gameh Musiceh.mp3");
            TerminalM = new OneSound(@"Engine\Music\Terminal Song.mp3");
            TitleM = new OneSound(@"Engine\Music\title song.mp3");



            ChangeSFX(20);
            ChangeBGM(40);

            //TerminalS.Volume = 50;
            //QuestS.Volume = 50;
            //QuestDoneS.Volume = 50;
            //InventoryS.Volume = 40;
            //SelectS.Volume = 40;
            //SelectInvS.Volume = 40;
            //CollectS.Volume = 50;
            //BombS.Volume = 50;

            //BossHurtS.Volume = 60;
            //PlayerHurtS.Volume = 60;
            //TitleM.Volume = 50;

            while (true)
            {
                speed = 1;

                //engine.SetNewBackroundColour(13);

                NPC.ActiveQuests = new List<string>();
                NPC.FinishedQuests = new List<string>();

                editor_mode = false;
                editor_object_to_spawn = "";
                PreperationsGame.Prepare();
                PreparationsMenu.PrepareMenu();
                DoorUnlocked = false;
                TerminalUnlocked = false;

                PreparationsEditor.PrepareSpawnableObjects();
                Terminal = new TerminalClass(engine, Game);
                SavingAndLoading.LoadMap("MAP.map");
                TextLines = new Object[4];

                STARTBOSS = false;


                showtext = false;
                texttoshow = "";


                //foreach (Item x in Items.ItemDictionary.Values)
                //{
                //    Inv.AddItemToInv(x);
                //}

                //Inv.AddItemToInv(Items.ItemDictionary["AdminLogin"]);
                //editor_mode = true;
                //Terminal.ChangeUser("admin");
                //TerminalUnlocked = true;
                //DoorUnlocked = true;


                //STARTBOSS = true;



                OverWorldM.Play(false);


                OverWorldM.Stop();

                TitleM.Play(true);

                engine.ChangeActiveScene(Title);
                engine.RenderFrame(-1);
                Console.Title = "A stony rpg v1.07";

                while (!inp.KeyPressed(Input.Key.Spacebar))
                {

                }
                while (inp.KeyPressed(Input.Key.Spacebar))
                {

                }
                TitleM.Stop();
                OverWorldM.Play(true);
                engine.ChangeActiveScene(Game);
                {
                    PlayerPosition = (-10, -5);
                    ActualCameraPosition = (0, 0);

                    while (!STARTBOSS)
                    {
                        AddorRemoveObjects();
                        Movement(Hitbox, Player);
                        if (inp.KeyPressed(Input.Key.E) || inp.KeyPressed(Input.Key.Spacebar))
                        {
                            Interaction(Hitbox, GameObjects, engine);
                        }
                        if (inp.KeyPressed(Input.Key.I))
                        {
                            InventoryS.Play();
                            System.Threading.Thread.Sleep(70);
                            Inv.OpenInventory();
                            InventoryS.Play();
                            System.Threading.Thread.Sleep(70);
                        }

                        if (editor_mode)
                        {
                            EditorThings.EditorStuff();
                        }

                        MoveDebugHitbox();

                        if (inp.KeyPressed(Input.Key.Esc))
                        {
                            TerminalS.Play();
                            System.Threading.Thread.Sleep(70);
                            OverWorldM.Stop();
                            TerminalM.Play(true);
                            MENU.GoIntoMenu();
                            TerminalM.Stop();
                            OverWorldM.Play(true);
                        }



                        if (showtext)
                        {
                            Text.DisplayText(texttoshow);
                            texttoshow = "";
                            showtext = false;
                        }

                        engine.RenderFrame(20);
                        //Console.Title = GameObjects.Count + " - " + engine.ActiveScene.SceneObjects.Count + " -> " + debugPlayer.Position.x + "|" + debugPlayer.Position.y + " - " + debugPlayer.OffsetPosition.x + "|" + debugPlayer.OffsetPosition.y;
                    }
                }
                OverWorldM.Stop();
                engine.SetNewBackroundColour(0);
                editor_mode = false;

                while (STARTBOSS)
                {
                    System.Threading.Thread.Sleep(400);
                    BossM.Play(true);
                    PreparationsBoss.PrepareBoss();
                    bossstage = 0;
                    frame = 0;
                    bosscooldown = 0;
                    bossmovetolocation = (0, 0);
                    BossHealth = 5;
                    PlayerHealth = 3;
                    bossmove = 0;
                    BossInvincibility = 0;
                    PlayerInvincibility = 0;

                    SavingAndLoading.LoadMap("BOSSMAP.map");

                    while (PlayerHealth > 0 && BossHealth > 0)
                    {
                        if (frame % 40 == 0)
                        {
                            bossstage = rnd.Next(0, 3);
                        }
                        if (frame % 60 == 0)
                        {
                            {
                                Object temp = BombOBJ.Clone();
                                temp.Position = (rnd.Next(-30, 110), rnd.Next(-40, 90));
                                engine.AddObjectToScene(temp);
                                temp.Update();
                                GameObjects.Add( new GameObject() { OBJ =temp, name = "bomb", EditorName = "Bomb", type = 21, wall = false});
                            }

                        }
                        if (bossstage != 0)
                        {
                            if (bosscooldown != 0)
                            {
                                BossThing();
                            }
                            else
                            {
                                bosscooldown--;
                            }
                        }
                        if (PlayerInvincibility > 0)
                        {
                            PlayerInvincibility--;
                        }
                        if (BossInvincibility > 0)
                        {
                            BossInvincibility--;
                        }

                        CheckBombCollision();
                        Movement(Hitbox, Player, true);
                        engine.RenderFrame(20);
                        //Console.Title = BossHealth + " - " + PlayerHealth + " - " + PlayerInvincibility + " -- " + frame;
                        frame++;
                    }
                    BossM.Stop();
                    if (!(BossHealth > 0))
                    {
                        STARTBOSS = false;
                    }
                    else
                    {
                        engine.ChangeActiveScene(END);
                        UI.Player.ActiveSprite = new Graphics.Sprite(@"Engine\Sprites\UI\lose.mesf", false);
                        engine.RenderFrame(1);
                        while (inp.KeyPressed(Input.Key.Spacebar))
                        {

                        }
                        while (!inp.KeyPressed(Input.Key.Spacebar))
                        {

                        }
                    }
                }



                engine.ChangeActiveScene(END);
                UI.Player.ActiveSprite = new Graphics.Sprite(@"Engine\Sprites\UI\win.mesf", false);
                engine.RenderFrame(1);
                while (inp.KeyPressed(Input.Key.Spacebar))
                {

                }
                while (!inp.KeyPressed(Input.Key.Spacebar))
                {

                }
                SavingAndLoading.LoadMap("MAP.map");

                engine.SetNewBackroundColour(0);
                Console.Clear();
            }
        }

        static void CheckBombCollision()
        {
            {
                bool collision = false;
                for (int i = 0; i < GameObjects.Count; i++)
                {
                    GameObject x = GameObjects[i];
                    if (x.type == 21)
                    {
                        if (Collision(Player, x.OBJ))
                        {
                            collision = true;
                            engine.RemoveObjectFromScene(x.OBJ);
                            GameObjects.Remove(x);
                            BombS.Play();
                            break;
                        }
                    }
                    if (x.type == 20)
                    {
                        if (Collision(Player, x.OBJ))
                        {
                            collision = true;
                            break;
                        }
                    }
                }
                if (collision)
                {
                    if (PlayerInvincibility == 0)
                    {
                        PlayerHurtS.Play();
                        PlayerInvincibility = 40;
                        PlayerHealth--;
                    }

                }
            }

            {
                bool collision = false;
                for (int i = 0; i < GameObjects.Count; i++)
                {
                    GameObject x = GameObjects[i];
                    if (x.type == 21)
                    {
                        if (Collision(BossObject.OBJ, x.OBJ))
                        {
                            collision = true;
                            engine.RemoveObjectFromScene(x.OBJ);
                            GameObjects.Remove(x);
                            BombS.Play();
                            break;
                        }
                    }
                }
                if (collision)
                {
                    if (BossInvincibility == 0)
                    {
                        BossHurtS.Play();
                        BossInvincibility = 40;
                        BossHealth--;
                    }
                }
            }
        }

        public static int PlayerInvincibility;
        public static int BossInvincibility;


        public static int PlayerHealth;
        public static int BossHealth;
        public static GameObject BossObject;
        public static Object BombOBJ;
        public static int bossstage = 0;
        public static int frame = 0;
        public static int bossmove;
        public static int bosscooldown = 0;
        public static (int x, int y) bossmovetolocation = (0, 0);
        public static Random rnd = new Random();
        static void BossThing()
        {
            if (bossstage == 1)
            {
                if (bossmovetolocation == BossObject.OBJ.Position)
                {
                    bosscooldown = rnd.Next(10, 25);
                    bossmovetolocation = (rnd.Next(-20, 100), rnd.Next(-30, 80));
                }
                else
                {
                    int x = rnd.Next(0, 5);
                    for (int i = 0; i < x; i++)
                    {
                        if (BossObject.OBJ.Position.x > bossmovetolocation.x)
                        {
                            BossObject.OBJ.MoveX(-1);
                        }
                        if (BossObject.OBJ.Position.x < bossmovetolocation.x)
                        {
                            BossObject.OBJ.MoveX(1);
                        }
                        if (BossObject.OBJ.Position.y > bossmovetolocation.y)
                        {
                            BossObject.OBJ.MoveY(-1);
                        }
                        if (BossObject.OBJ.Position.y < bossmovetolocation.y)
                        {
                            BossObject.OBJ.MoveY(1);
                        }
                    }
                }
            }
            if (bossstage == 2)
            {
                (int x, int y) PlayerPos = ((MainGame.ActualCameraPosition.x + MainGame.middle_offset.x + MainGame.PlayerPosition.x), (MainGame.ActualCameraPosition.y + MainGame.middle_offset.y + MainGame.PlayerPosition.y));
                if (PlayerPos == BossObject.OBJ.Position || bossmove > 6)
                {
                    bosscooldown = rnd.Next(10, 30);
                    bossmove = 0;
                }
                else
                {
                    int x = rnd.Next(1, 3);
                    for (int i = 0; i < x; i++)
                    {
                        if (BossObject.OBJ.Position.x > PlayerPos.x)
                        {
                            BossObject.OBJ.MoveX(-1);
                        }
                        if (BossObject.OBJ.Position.x < PlayerPos.x)
                        {
                            BossObject.OBJ.MoveX(1);
                        }
                        if (BossObject.OBJ.Position.y > PlayerPos.y)
                        {
                            BossObject.OBJ.MoveY(-1);
                        }
                        if (BossObject.OBJ.Position.y < PlayerPos.y)
                        {
                            BossObject.OBJ.MoveY(1);
                        }
                        bossmove++;
                    }
                }
            }
        }


        static void MoveDebugHitbox()
        {
            (int x, int y) current_pos = ((ActualCameraPosition.x + middle_offset.x + PlayerPosition.x), (ActualCameraPosition.y + middle_offset.y + +PlayerPosition.y));

            (int x, int y) diff = (5, 5);
            if (current_pos.x < 0)
            {
                diff.x = -5;
            }
            if (current_pos.y < 0)
            {
                diff.y = -5;
            }
            debugPlayer.Position = ((((current_pos.x + diff.x) / 10) * 10), (((current_pos.y + diff.y) / 10) * 10));

            debugPlayer.Shown = editor_mode;

            debugPlayer.Update();
            debugPlayer.OffsetPosition = (-ActualCameraPosition.x, -ActualCameraPosition.y);
        }



        static void AddorRemoveObjects()
        {
            foreach (GameObject xy in GameObjects)
            {
                Object x = xy.OBJ;

                if ((((x.OffsetPosition.x + x.Position.x) > 110) || ((x.OffsetPosition.x + x.Position.x) < -20)) || (((x.OffsetPosition.y + x.Position.y) > 80) || ((x.OffsetPosition.y + x.Position.y) < -20)))
                {
                    if (engine.ActiveScene.SceneObjects.Contains(x))
                    {
                        engine.RemoveObjectFromScene(x);
                    }
                }
                else
                {
                    if (!engine.ActiveScene.SceneObjects.Contains(x))
                    {
                        engine.AddObjectToScene(x);
                    }
                }
            }
        }







        static void Interaction(Object Hitbox, List<GameObject> GameObjects, MainEngine engine)
        {
            for (int i = 0; i < GameObjects.Count; i++)
            {
                GameObject x = GameObjects[i];
                if (Collision(Hitbox, x.OBJ))
                {
                    switch (x.type)
                    {
                        case 1:
                            if (TerminalUnlocked)
                            {
                                TerminalS.Play();
                                System.Threading.Thread.Sleep(70);
                                OverWorldM.Stop();
                                TerminalM.Play(true);
                                Terminal.TerminalInteraction();
                                TerminalM.Stop();
                                OverWorldM.Play(true);
                            }
                            else
                            {
                                Text.DisplayText("*You don't remember what this is and can't use it.*\n*It seems so familiar though...*");
                            }
                            break;
                        case 3:
                            NPC.NPC1Interaction();
                            break;
                        case 8:
                            NPC.NPC2Interaction(x);
                            break;
                        case 10:
                            NPC.NPC3Interaction();
                            break;
                        case 13:
                            NPC.NPC4Interaction();
                            break;
                        case 15:
                            NPC.NPC5Interaction();
                            break;
                        case 17:
                            NPC.NPC6Interaction();
                            break;
                        case 7:
                            engine.RemoveObjectFromScene(x.OBJ);
                            GameObjects.Remove(x);

                            MainGame.CollectS.Play();
                            Inv.AddItemToInv(Items.ItemDictionary["Ring"]);
                            Text.DisplayText("*Found a Ring*");
                            i--;
                            break;
                        case 14:
                            engine.RemoveObjectFromScene(x.OBJ);
                            GameObjects.Remove(x);

                            MainGame.CollectS.Play();
                            Inv.AddItemToInv(Items.ItemDictionary["Vibe"]);
                            Text.DisplayText("*Found vibing advice*");
                            i--;
                            break;
                        case 11:
                            engine.RemoveObjectFromScene(x.OBJ);
                            GameObjects.Remove(x);

                            MainGame.CollectS.Play();
                            Inv.AddItemToInv(Items.ItemDictionary["FenceKey"]);
                            Text.DisplayText("*Found a FenceKey*");
                            i--;
                            break;
                        case 12:
                            engine.RemoveObjectFromScene(x.OBJ);
                            GameObjects.Remove(x);

                            MainGame.CollectS.Play();
                            Inv.AddItemToInv(Items.ItemDictionary["Memory2"]);
                            Text.DisplayText("*Found a new Memory*");
                            i--;
                            break;
                        case 16:
                            engine.RemoveObjectFromScene(x.OBJ);
                            GameObjects.Remove(x);

                            MainGame.CollectS.Play();
                            Inv.AddItemToInv(Items.ItemDictionary["Memory5"]);
                            Text.DisplayText("*Found a new Memory*");
                            i--;
                            break;
                        case 18:
                            engine.RemoveObjectFromScene(x.OBJ);
                            GameObjects.Remove(x);

                            MainGame.CollectS.Play();
                            Inv.AddItemToInv(Items.ItemDictionary["Memory4"]);
                            Text.DisplayText("*Found a new Memory*");
                            i--;
                            break;
                        case 9:
                            engine.RemoveObjectFromScene(x.OBJ);
                            GameObjects.Remove(x);

                            MainGame.CollectS.Play();
                            Inv.AddItemToInv(Items.ItemDictionary["Memory1"]);
                            Text.DisplayText("*Found a new Memory*");
                            i--;
                            break;



                        default:
                            break;
                    }
                }

            }
        }



        static void Movement(Object Hitbox, Object Player, bool boss = false)
        {
            (int x, int y) mov = (0, 0);
            int mov_speed = speed;
            if (inp.KeyPressed(Input.Key.Tab) || inp.KeyPressed(Input.Key.Q))
            {
                mov_speed = speed * 2;
            }
            if (inp.KeyPressed(Input.Key.RightArrow) || inp.KeyPressed(Input.Key.D))
            {
                mov.x = 1;
            }
            if (inp.KeyPressed(Input.Key.LeftArrow) || inp.KeyPressed(Input.Key.A))
            {
                mov.x = -1;
            }
            if (inp.KeyPressed(Input.Key.DownArrow) || inp.KeyPressed(Input.Key.S))
            {
                mov.y = 1;
            }
            if (inp.KeyPressed(Input.Key.UpArrow) || inp.KeyPressed(Input.Key.W))
            {
                mov.y = -1;
            }


            for (int i = 0; i < Math.Abs(mov_speed * mov.x); i++)
            {
                PlayerPosition.x += mov.x;
                MoveObjects(Player, Hitbox);
                bool collision = false;
                foreach (GameObject x in GameObjects)
                {
                    if (x.wall)
                    {
                        if (Collision(Hitbox, x.OBJ))
                        {
                            collision = true;
                            break;
                        }
                    }
                    if (x.EditorName == "Door")
                    {
                        if (DoorUnlocked)
                        {
                            if (Collision(Hitbox, x.OBJ))
                            {
                                STARTBOSS = true;
                                break;
                            }
                        }
                        else
                        {
                            if (Collision(Hitbox, x.OBJ))
                            {
                                collision = true;
                                break;
                            }
                        }
                    }
                    if (x.EditorName == "LFence1" && !Inventory.ContainsKey(Items.ItemDictionary["FenceKey"]))
                    {
                        if (Collision(Hitbox, x.OBJ))
                        {
                            collision = true;
                            break;
                        }
                    }
                }
                if (collision && !(mov_speed <= speed && editor_mode))
                {
                    PlayerPosition.x -= mov.x;
                }
            }

            for (int i = 0; i < Math.Abs(mov_speed * mov.y); i++)
            {
                PlayerPosition.y += mov.y;
                MoveObjects(Player, Hitbox);
                bool collision = false;
                foreach (GameObject x in GameObjects)
                {
                    if (x.wall)
                    {
                        if (Collision(Hitbox, x.OBJ))
                        {
                            collision = true;
                            break;
                        }
                    }
                    if (x.EditorName == "Door")
                    {
                        if (DoorUnlocked)
                        {
                            if (Collision(Hitbox, x.OBJ))
                            {
                                STARTBOSS = true;
                                break;
                            }
                        }
                        else
                        {
                            if (Collision(Hitbox, x.OBJ))
                            {
                                collision = true;
                                break;
                            }
                        }
                    }
                    if (x.EditorName == "LFence1" && !Inventory.ContainsKey(Items.ItemDictionary["FenceKey"]))
                    {
                        if (Collision(Hitbox, x.OBJ))
                        {
                            collision = true;
                            break;
                        }
                    }
                }
                if (collision && !(mov_speed <= speed && editor_mode))
                {
                    PlayerPosition.y -= mov.y;
                }
            }

            int value = 5;

            if (PlayerPosition.x > value)
            {
                ActualCameraPosition.x += PlayerPosition.x - value;
                PlayerPosition.x = value;
            }
            if (PlayerPosition.x < -value)
            {
                ActualCameraPosition.x += (PlayerPosition.x + value);
                PlayerPosition.x = -value;
            }
            if (PlayerPosition.y > value)
            {
                ActualCameraPosition.y += PlayerPosition.y - value;
                PlayerPosition.y = value;
            }
            if (PlayerPosition.y < -value)
            {
                ActualCameraPosition.y += (PlayerPosition.y + value);
                PlayerPosition.y = -value;
            }

            if (boss)
            {
                int max_dis = 70;
                if (ActualCameraPosition.x > max_dis)
                {
                    ActualCameraPosition.x = max_dis;
                }
                if (ActualCameraPosition.x < -max_dis)
                {
                    ActualCameraPosition.x = -max_dis;
                }
                if (ActualCameraPosition.y > max_dis)
                {
                    ActualCameraPosition.y = max_dis;
                }
                if (ActualCameraPosition.y < -max_dis)
                {
                    ActualCameraPosition.y = -max_dis;
                }
            }




            MoveObjects(Player, Hitbox);

        }


        static void MoveObjects(Object Player, Object Hitbox)
        {
            for (int i = 0; i < GameObjects.Count; i++)
            {
                GameObjects[i].OBJ.OffsetPosition = (-ActualCameraPosition.x, -ActualCameraPosition.y);
                GameObjects[i].OBJ.Update();
            }

            Player.Position = PlayerPosition;
            Hitbox.Position = PlayerPosition;

            Player.Update();
            Hitbox.Update();
        }

        public struct GameObject
        {
            public Object OBJ;
            public string name;
            public string EditorName;
            public int type;
            public bool wall;
        }
        public struct Item
        {
            public string name;
            public int type;
        }


        static bool Collision(Object A, Object B)
        {

            if (engine.ActiveScene.SceneObjects.Contains(B))
            {
                (int A, int B) old_layers = (A.Layer, B.Layer);

                A.Layer = 1000000;
                B.Layer = 1000000;

                bool temp = engine.CheckObjectCollision(A, B);

                (A.Layer, B.Layer) = old_layers;

                return temp;
            }

            return false;
        }
    }
}
