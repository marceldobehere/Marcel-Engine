﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;
using Object = Engine.Object;
using Testing_the_engine_lol;
using System.IO;
using Extra;
using Newtonsoft.Json;

namespace Extra
{
    class Inv
    {
        public static void OpenInventory()
        {
            (int x, int y) invoffset = (27, 17);

            bool exit = false;
            MainGame.UI.Player.ActiveSprite = new Graphics.Sprite(@"Engine\Sprites\UI\UI_INV.mesf", false);
            MainGame.UI.Update();
            MainGame.engine.AddObjectToScene(MainGame.InventoryCursor);
            MainGame.InventoryCursor.Update();
            MainGame.InventoryCursor.Position = (0, 0);
            MainGame.InventoryCursor.OffsetPosition = invoffset;
            MainGame.engine.RenderFrame(-1);
            while (MainGame.inp.KeyPressed(Input.Key.I))
            {
            }

            List<Object> TEXT = new List<Object>();
            for (int i = 0; i < MainGame.Inventory.Count; i++)
            {
                Object temp = new Object();
                temp.ActiveObjectType = 2;
                KeyValuePair<MainGame.Item, int> tempitem = MainGame.Inventory.ElementAt(i);
                if (tempitem.Value == 1)
                {
                    temp.Text.Text = tempitem.Key.name;
                }
                else
                {
                    temp.Text.Text = $"{tempitem.Value}x {tempitem.Key.name}";
                }
                temp.Layer = 1005;
                temp.Text.UpdateText();
                temp.OffsetPosition = (invoffset.x + 2, invoffset.y + i);
                TEXT.Add(temp);
                MainGame.engine.AddObjectToScene(temp);
            }

            int cursorposition = 0;
            while (!exit)
            {
                if (MainGame.inp.KeyPressed(Input.Key.DownArrow))
                {
                    if (cursorposition < 19)
                    {
                        cursorposition++;
                        MainGame.InventoryCursor.MoveY(1);
                        MainGame.SelectInvS.Play();
                    }
                }
                if (MainGame.inp.KeyPressed(Input.Key.UpArrow))
                {
                    if (cursorposition > 0)
                    {
                        cursorposition--;
                        MainGame.InventoryCursor.MoveY(-1);
                        MainGame.SelectInvS.Play();
                    }
                }

                if (MainGame.inp.KeyPressed(Input.Key.Spacebar))
                {
                    //MainGame.SelectInvS.Play();
                    bool empty = true;
                    if (MainGame.Inventory.Count > cursorposition)
                    {
                        MainGame.Item temp = MainGame.Inventory.ElementAt(cursorposition).Key;
                        if (temp.Equals(Items.ItemDictionary["exit"]))
                        {
                            exit = true;
                            empty = false;
                        }
                        if (temp.Equals(Items.ItemDictionary["Vibe"]))
                        {
                            MainGame.InventoryS.Play();
                            Text.DisplayTextInv("*This advice is to viby to ever be understood by humans...*");
                            empty = false;
                        }
                        if (temp.Equals(Items.ItemDictionary["Memory1"]))
                        {
                            MainGame.InventoryS.Play();
                            Text.DisplayTextInv("*You remembered your friend Fred.\nAnd how he was working on a little game for a game jam.*");
                            empty = false;
                        }
                        if (temp.Equals(Items.ItemDictionary["Memory2"]))
                        {
                            MainGame.InventoryS.Play();
                            Text.DisplayTextInv("*You remembered a little terminal he added.*");
                            MainGame.TerminalUnlocked = true;
                            empty = false;
                        }
                        if (temp.Equals(Items.ItemDictionary["Memory3"]))
                        {
                            MainGame.InventoryS.Play();
                            Text.DisplayTextInv("*You remembered him talking about how you should try it once its done.\nYou felt very excited.*");
                            empty = false;
                        }
                        if (temp.Equals(Items.ItemDictionary["Memory4"]))
                        {
                            MainGame.InventoryS.Play();
                            Text.DisplayTextInv("*You remembered Fred talking about how the only way to exit the game for now was beating the boss.*");
                            empty = false;
                        }
                        if (temp.Equals(Items.ItemDictionary["Memory5"]))
                        {
                            MainGame.InventoryS.Play();
                            Text.DisplayTextInv("*You remembered that you need to kill the boss with mines and that the boss is in the house.*");
                            empty = false;
                        }
                        if (temp.Equals(Items.ItemDictionary["UserLogin"]))
                        {
                            MainGame.InventoryS.Play();
                            Text.DisplayTextInv($"The note says: Username: user | Password: {MainGame.Passwords[0]}");
                            empty = false;
                        }
                        if (temp.Equals(Items.ItemDictionary["DevLogin"]))
                        {
                            MainGame.InventoryS.Play();
                            Text.DisplayTextInv($"The note says: Username: dev | Password: {MainGame.Passwords[1]}");
                            empty = false;
                        }
                        if (temp.Equals(Items.ItemDictionary["AdminLogin"]))
                        {
                            MainGame.InventoryS.Play();
                            Text.DisplayTextInv($"The note says: Username: admin | Password: {MainGame.Passwords[2]}");
                            empty = false;
                        }

                        if (temp.Equals(Items.ItemDictionary["nothing"]))
                        {
                            MainGame.InventoryS.Play();
                            Text.DisplayTextInv("This is absolutely nothing.");
                            empty = false;
                        }
                        if (temp.Equals(Items.ItemDictionary[""]))
                        {
                            MainGame.InventoryS.Play();
                            Text.DisplayTextInv("");
                            empty = false;
                        }
                        if (temp.Equals(Items.ItemDictionary["Ring"]))
                        {
                            MainGame.InventoryS.Play();
                            Text.DisplayTextInv("It's a beautiful ring.");
                            empty = false;
                        }
                        if (temp.Equals(Items.ItemDictionary["Sandwich"]))
                        {
                            MainGame.InventoryS.Play();
                            Text.DisplayTextInv("(Who added food to the game?)");
                            empty = false;
                        }
                        if (temp.Equals(Items.ItemDictionary["test"]))
                        {
                            MainGame.InventoryS.Play();
                            Text.DisplayTextInv("(It's not a bug, it's a feature!)");
                            empty = false;
                        }
                        if (temp.Equals(Items.ItemDictionary["FenceKey"]))
                        {
                            MainGame.InventoryS.Play();
                            Text.DisplayTextInv("Its a golden Key. (Probably for going through locked)");
                            empty = false;
                        }
                    }
                    if (empty)
                    {
                        MainGame.InvalidSelectS.Play();
                    }
                }

                if (MainGame.inp.KeyPressed(Input.Key.I))
                {
                    exit = true;
                }


                MainGame.engine.RenderFrame(10);
            }
            foreach (Object x in TEXT)
            {
                MainGame.engine.RemoveObjectFromScene(x);
            }

            MainGame.engine.RemoveObjectFromScene(MainGame.InventoryCursor);
            MainGame.UI.Player.ActiveSprite = new Graphics.Sprite(@"Engine\Sprites\UI\UI_NTEXT.mesf", false);
            MainGame.UI.Update();
            MainGame.engine.RenderFrame(-1);
        }


        public static void AddItemToInv(MainGame.Item x)
        {
            if (!MainGame.Inventory.ContainsKey(x))
            {
                MainGame.Inventory.Add(x, 0);
            }
            MainGame.Inventory[x]++;
        }
        public static void AddItemToInv(MainGame.Item x, int amount)
        {
            if (!MainGame.Inventory.ContainsKey(x))
            {
                MainGame.Inventory.Add(x, 0);
            }
            MainGame.Inventory[x] += amount;
        }
        public static void RemoveItemFromInv(MainGame.Item x)
        {
            if (MainGame.Inventory.ContainsKey(x))
            {
                if (MainGame.Inventory[x] > 1)
                {
                    MainGame.Inventory[x]--;
                }
                else
                {
                    MainGame.Inventory.Remove(x);
                }
            }
        }

        public static void DeleteItemFromInv(MainGame.Item x)
        {
            if (MainGame.Inventory.ContainsKey(x))
            {
                MainGame.Inventory.Remove(x);
            }
        }
    }
}
