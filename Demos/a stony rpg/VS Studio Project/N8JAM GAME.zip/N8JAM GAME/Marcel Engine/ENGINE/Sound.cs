﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Media;
using System.Threading;
using System.Windows;

namespace Engine
{
    ///<summary>
    ///Sound Player
    ///</summary>
    class Sound
    {
        ///<summary>
        ///The Filename of the Object.
        ///</summary>
        public string Filename { get; set; }
        ///<summary>
        ///Sets the largest Queue this SoundPlayer has.
        ///</summary>
        public int MaximumQueueLength { get; set; }
        ///<summary>
        ///Sets the Volume. (between 0 and 100%)
        ///</summary>
        public double Volume { get; set; }

        private Thread PlayThread;

        private TimeSpan Zero = new TimeSpan();

        private bool playing { get; set; }

        private bool looping;

        private bool stop;

        private int queue;

        public Sound(string filename)
        {
            Filename = filename;
            playing = false;
            looping = false;
            stop = false;
            MaximumQueueLength = 10;
            queue = 0;
            Volume = 100;
        }
        public void New_File(string filename)
        {
            Stop();
            Filename = filename;
        }


        private void __Play()
        {
            MediaPlayer test = new MediaPlayer();
            test.Open(new Uri(Filename, UriKind.RelativeOrAbsolute));
            while (test.NaturalDuration == Duration.Automatic)
            {
            }
            test.Volume = Volume / 100;
            if (looping)
            {
                while (true)
                {
                    test.Volume = Volume / 100;
                    test.Play();
                    Thread.Sleep((int)Math.Round(test.NaturalDuration.TimeSpan.TotalMilliseconds));
                    test.Position = Zero;
                }
            }
            else
            {
                test.Play();
                Thread.Sleep((int)Math.Round(test.NaturalDuration.TimeSpan.TotalMilliseconds));
                playing = false;
                queue--;
            }
        }
        private void _Play()
        {
            queue++;
            if (playing && looping)
            {
                queue--;
                return;
            }
            else
            {
                if (playing && !looping)
                {
                    while (playing && !stop)
                    {
                        Thread.Sleep(5);
                    }
                }
            }
            if (!playing && !stop)
            {
                playing = true;
                PlayThread = new Thread(() => __Play());
                PlayThread.IsBackground = true;
                try
                {
                    PlayThread.Start();
                }
                catch
                {
                    Stop();
                    playing = false;
                    queue--;
                }
            }
        }

        public void Play(bool loop)
        {
            looping = loop;
            if (queue < MaximumQueueLength)
            {
                new Thread(() => _Play()).Start();
            }
        }



        public void Stop()
        {
            stop = true;
            Thread.Sleep(5);
            try
            {
                PlayThread.Abort();
            }
            catch
            {

            }
            playing = false;
            looping = false;
            queue = 0;
            try
            {
                PlayThread.Abort();
            }
            catch
            {

            }
            Thread.Sleep(5);
            stop = false;
        }


    }
    class OneSound
    {
        ///<summary>
        ///The Filename of the Object.
        ///</summary>
        public string Filename { get; set; }
        ///<summary>
        ///Sets the Volume. (between 0 and 100%)
        ///</summary>
        public double Volume { get; set; }

        private double lastvol;

        public MediaPlayer Player;

        public Thread LoopThread;

        public bool stop;

        public OneSound(string filename)
        {
            Player = new MediaPlayer();
            Volume = 100;
            lastvol = Volume / 100;
            New_File(filename);
            LoopThread = new Thread(() => PlayLoop());
            stop = false;
        }
        public void New_File(string filename)
        {
            stop = false;
            Filename = filename;
            Player.Stop();
            Player.Open(new Uri(Filename, UriKind.RelativeOrAbsolute));
            while (Player.NaturalDuration == Duration.Automatic)
            {
            }
        }


        public void Play(bool loop = false)
        {
            stop = false;
            Player.Volume = Volume / 100;
            lastvol = Volume / 100;
            if (loop)
            {
                LoopThread = new Thread(() => PlayLoop());
                LoopThread.Start();
            }
            else
            {
                Player.Stop();
                Player.Play();
            }
        }

        private void PlayLoop()
        {
            lastvol = 0;
            MediaPlayer LoopPlayer = new MediaPlayer();
            LoopPlayer.Open(new Uri(Filename, UriKind.RelativeOrAbsolute));
            LoopPlayer.Volume = Volume;
            while (LoopPlayer.NaturalDuration == Duration.Automatic)
            {
            }
            while (!stop)
            {
                DateTime stoptime = DateTime.Now.AddMilliseconds((int)Math.Round(LoopPlayer.NaturalDuration.TimeSpan.TotalMilliseconds));
                LoopPlayer.Play();
                while (DateTime.Now < stoptime && stop == false)
                {
                    if (lastvol != Volume / 100)
                    {
                        lastvol = Volume / 100;
                        LoopPlayer.Volume = Volume / 100;
                    }
                }
                LoopPlayer.Position = new TimeSpan(0);
            }
            LoopPlayer.Stop();
        }


        public void Stop()
        {
            Player.Stop();
            stop = true;
            DateTime stoptime = DateTime.Now.AddMilliseconds(60);
            while (stop == true && DateTime.Now < stoptime)
            {

            }
            stop = false;
            LoopThread.Abort();
        }

    }
}
