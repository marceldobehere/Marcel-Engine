﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;
using Extra;
using Object = Engine.Object;
using Testing_the_engine_lol;
using System.IO;
using Newtonsoft.Json;

namespace Extra
{
    class PreperationsGame
    {

        public static void Prepare()
        {
            PrepareTitle();
            PrepareEnd();
            PrepareGame();
            PrepareInventory();
        }


        public static void PrepareEnd()
        {
            MainGame.END = new Scene();
            MainGame.engine.ChangeActiveScene(MainGame.END);
            MainGame.UI = new Object();
            MainGame.engine.AddObjectToScene(MainGame.UI);
        }

        public static void PrepareGame()
        {
            MainGame.Game = new Scene();
            MainGame.engine.ChangeActiveScene(MainGame.Game);


            //MainGame.UI = new Object();
            MainGame.UI.ActiveObjectType = 1;
            MainGame.UI.Player.ActiveSprite = new Graphics.Sprite(@"Engine\Sprites\UI\UI_NTEXT.mesf", false);
            MainGame.UI.Layer = 1000;
            MainGame.engine.AddObjectToScene(MainGame.UI);

            MainGame.middle_offset = ((90 / 2) - 5, (60 / 2) - 5);

            MainGame.Player = new Object();
            MainGame.Player.ActiveObjectType = 1;
            MainGame.Player.Player.ActiveSprite = new Graphics.Sprite(@"Engine\Sprites\Player\player2.mesf", false);
            MainGame.Player.OffsetPosition = MainGame.middle_offset;
            MainGame.Player.Layer = 998;

            MainGame.engine.AddObjectToScene(MainGame.Player);

            MainGame.debugPlayer = new Object();
            MainGame.debugPlayer.ActiveObjectType = 1;
            MainGame.debugPlayer.Player.ActiveSprite = new Graphics.Sprite(@"Engine\Sprites\Player\debugHITBOX.mesf", false);
            MainGame.debugPlayer.Layer = 999;
            MainGame.engine.AddObjectToScene(MainGame.debugPlayer);



            MainGame.Hitbox = new Object();
            MainGame.Hitbox.ActiveObjectType = 1;
            MainGame.Hitbox.Player.ActiveSprite = new Graphics.Sprite(@"Engine\Sprites\Player\hitbox.mesf", false);
            MainGame.Hitbox.OffsetPosition = MainGame.middle_offset;
            MainGame.Hitbox.Layer = -1;
            MainGame.Hitbox.Shown = false;
            MainGame.engine.AddObjectToScene(MainGame.Player);

            MainGame.GameObjects = new List<MainGame.GameObject>();
        }

        public static void PrepareTitle()
        {
            MainGame.Title = new Scene();
            MainGame.engine.ChangeActiveScene(MainGame.Title);

            {
                Object title = new Object();
                title.ActiveObjectType = 1;
                title.Player.ActiveSprite = new Graphics.Sprite(@"Engine\Sprites\UI\TITLE.mesf", false);

                MainGame.engine.AddObjectToScene(title);
            }
        }

        public static void PrepareInventory()
        {
            MainGame.Inventory = new Dictionary<MainGame.Item, int>();
            MainGame.Inventory.Add(Items.ItemDictionary["exit"], 1);
            MainGame.InventoryCursor = new Object();
            MainGame.InventoryCursor.ActiveObjectType = 2;
            MainGame.InventoryCursor.Text.Text = ">";
            MainGame.InventoryCursor.Layer = 1002;
        }
    }
}
