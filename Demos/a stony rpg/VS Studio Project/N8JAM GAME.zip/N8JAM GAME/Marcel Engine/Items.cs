﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;
using Object = Engine.Object;
using Testing_the_engine_lol;
using System.IO;
using Extra;
using Newtonsoft.Json;

namespace Extra
{
    class Items
    {
        static public Dictionary<string, MainGame.Item> ItemDictionary = new Dictionary<string, MainGame.Item>()
        {
            {"", new MainGame.Item() { name = "", type = 0}},
            {"nothing", new MainGame.Item() { name = "nothing", type = 0}},
            {"Ring", new MainGame.Item() { name = "Ring", type = 2}},
            {"UserLogin", new MainGame.Item() { name = "User Login Details", type = 2}},
            {"DevLogin", new MainGame.Item() { name = "Developer Login Details", type = 2}},
            {"AdminLogin", new MainGame.Item() { name = "Admin Login Details", type = 2}},
            {"Vibe", new MainGame.Item() { name = "Vibing Advice", type = 2}},
            {"Sandwich", new MainGame.Item() { name = "Tasty Sandwich", type = 2}},
            {"Memory1", new MainGame.Item() { name = "Memory (1 / 5)", type = 3}},
            {"Memory2", new MainGame.Item() { name = "Memory (2 / 5)", type = 3}},
            {"Memory3", new MainGame.Item() { name = "Memory (3 / 5)", type = 3}},
            {"Memory4", new MainGame.Item() { name = "Memory (4 / 5)", type = 3}},
            {"Memory5", new MainGame.Item() { name = "Memory (5 / 5)", type = 3}},
            {"test", new MainGame.Item() { name = "test", type = 0} },
            {"exit", new MainGame.Item() {name = "exit", type = -1} },
            {"FenceKey", new MainGame.Item(){ name = "FenceKey", type = 2} }
        };
    }
}
