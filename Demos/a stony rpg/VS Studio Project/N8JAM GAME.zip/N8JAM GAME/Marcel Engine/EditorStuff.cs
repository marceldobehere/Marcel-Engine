﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;
using Extra;
using Object = Engine.Object;
using Testing_the_engine_lol;
using System.IO;
using Newtonsoft.Json;

namespace Extra
{
    class EditorThings
    {
        public static void EditorStuff()
        {
            if (MainGame.inp.KeyPressed(Input.Key.Ctrl) && MainGame.inp.KeyPressed(Input.Key.S))
            {
                while (false)
                {

                }
                Console.SetCursorPosition(0, 0);
                while (Console.KeyAvailable)
                {
                    Console.ReadKey(true);
                }

                string temp = "";
                ConsoleKeyInfo tempchr = new ConsoleKeyInfo();
                while (tempchr.Key != ConsoleKey.Enter)
                {
                    tempchr = Console.ReadKey(true);
                    if (tempchr.Key != ConsoleKey.Enter)
                    {
                        temp += tempchr.KeyChar;
                    }
                }
                if (temp == "Y")
                {
                    SavingAndLoading.SaveMap("MAP.map");
                }
            }
            if (MainGame.inp.KeyPressed(Input.Key.Ctrl) && MainGame.inp.KeyPressed(Input.Key.L))
            {
                Console.SetCursorPosition(0, 0);
                while (Console.KeyAvailable)
                {
                    Console.ReadKey(true);
                }

                string temp = "";
                ConsoleKeyInfo tempchr = new ConsoleKeyInfo();
                while (tempchr.Key != ConsoleKey.Enter)
                {
                    tempchr = Console.ReadKey(true);
                    if (tempchr.Key != ConsoleKey.Enter)
                    {
                        temp += tempchr.KeyChar;
                    }
                }
                if (temp == "Y")
                {
                    SavingAndLoading.LoadMap("MAP.map");
                }
            }
            if (MainGame.inp.KeyPressed(Input.Key.Backspace))
            {
                MainGame.GameObject temp = MainGame.EditorObjects[MainGame.editor_object_to_spawn];
                if (temp.name != "empty")
                {
                    temp.OBJ = temp.OBJ.Clone();
                    temp.OBJ.Position = ((MainGame.ActualCameraPosition.x + MainGame.middle_offset.x + MainGame.PlayerPosition.x), (MainGame.ActualCameraPosition.y + MainGame.middle_offset.y + MainGame.PlayerPosition.y));

                    (int x, int y) diff = (5, 5);
                    if (temp.OBJ.Position.x < 0)
                    {
                        diff.x = -5;
                    }
                    if (temp.OBJ.Position.y < 0)
                    {
                        diff.y = -5;
                    }
                    temp.OBJ.Position = ((((temp.OBJ.Position.x + diff.x) / 10) * 10), (((temp.OBJ.Position.y + diff.y) / 10) * 10));

                    temp.OBJ.Update();
                    MainGame.engine.AddObjectToScene(temp.OBJ);
                    MainGame.ObjectsSpawnedFromEditor.Add(temp);
                    MainGame.GameObjects.Add(temp);
                    Console.Title = "Placed.";
                }
                else
                {
                    (int x, int y) current_pos = ((MainGame.ActualCameraPosition.x + MainGame.middle_offset.x + MainGame.PlayerPosition.x), (MainGame.ActualCameraPosition.y + MainGame.middle_offset.y + MainGame.PlayerPosition.y));
                    {
                        (int x, int y) diff = (5, 5);
                        if (current_pos.x < 0)
                        {
                            diff.x = -5;
                        }
                        if (current_pos.y < 0)
                        {
                            diff.y = -5;
                        }
                        current_pos = ((((current_pos.x + diff.x) / 10) * 10), (((current_pos.y + diff.y) / 10) * 10));
                    }

                    for (int i = 0; i < MainGame.ObjectsSpawnedFromEditor.Count; i++)
                    {
                        (int x, int y) temp_pos = (MainGame.ObjectsSpawnedFromEditor.ElementAt(i).OBJ.Position);
                        {
                            (int x, int y) diff = (5, 5);
                            if (temp_pos.x < 0)
                            {
                                diff.x = -5;
                            }
                            if (temp_pos.y < 0)
                            {
                                diff.y = -5;
                            }
                            temp_pos = ((((temp_pos.x + diff.x) / 10) * 10), (((temp_pos.y + diff.y) / 10) * 10));
                        }



                        if (current_pos == temp_pos)
                        {
                            MainGame.engine.RemoveObjectFromScene(MainGame.ObjectsSpawnedFromEditor.ElementAt(i).OBJ);
                            MainGame.GameObjects.Remove(MainGame.ObjectsSpawnedFromEditor.ElementAt(i));
                            MainGame.ObjectsSpawnedFromEditor.RemoveAt(i);
                            i--;
                        }
                    }
                    Console.Title = "Removed.";
                }

                while (MainGame.inp.KeyPressed(Input.Key.Backspace))
                {

                }
            }
            if (MainGame.inp.KeyPressed(Input.Key.Ctrl) && MainGame.inp.KeyPressed(Input.Key.Q))
            {
                Console.SetCursorPosition(0, 0);
                while (Console.KeyAvailable)
                {
                    Console.ReadKey(true);
                }

                string temp = "";
                ConsoleKeyInfo tempchr = new ConsoleKeyInfo();
                while (tempchr.Key != ConsoleKey.Enter)
                {
                    tempchr = Console.ReadKey(true);
                    if (tempchr.Key != ConsoleKey.Enter)
                    {
                        temp += tempchr.KeyChar;
                    }
                }


                //Console.Clear();
                //Console.WriteLine(temp);
                //Console.ReadLine();
                if (MainGame.EditorObjects.ContainsKey(temp))
                {
                    MainGame.editor_object_to_spawn = temp;
                    Console.Title = MainGame.editor_object_to_spawn + " selected.";
                    System.Threading.Thread.Sleep(500);
                }

            }
        }
    }
}