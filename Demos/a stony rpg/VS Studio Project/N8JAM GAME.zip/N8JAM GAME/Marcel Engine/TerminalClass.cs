﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;
using Extra;
using Object = Engine.Object;
using Testing_the_engine_lol;
using System.Diagnostics;

namespace Extra
{
    class TerminalClass
    {
        public MainEngine engine;
        public MainGame maingame;

        public Scene Game;
        public Scene Terminal;

        public string title;
        public string user;
        public int userlevel;


        public TerminalClass(MainEngine engine_, Scene Game_)
        {
            //maingame = maingame_;
            engine = engine_;
            Game = Game_;
            Terminal = new Scene();
            title = "Freds Game v0.24.1 - Debug Terminal";
            ChangeUser("guest");
            Random rnd = new Random();
            MainGame.Passwords = new string[] { GenPass(4, ref rnd), GenPass(5, ref rnd), GenPass(7, ref rnd) };
        }

        static string GenPass(int lenght, ref Random rnd)
        {
            string pass = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNPQRSTUVWXYZ1234567890";
            
            for (int i = 0; i < lenght + rnd.Next(0, pass.Length); i++)
            {
                rnd.Next(0,pass.Length);
                rnd.Next(0, pass.Length);
            }

            string s = "";
            for (int i = 0; i < lenght; i++)
            {
                s =  s + pass[rnd.Next(0, pass.Length)];
            }
            return s;
        }


        public void ChangeUser(string username)
        {
            switch (username)
            {
                case "guest":
                    user = "guest";
                    userlevel = 0;
                    break;

                case "user":
                    user = "user";
                    userlevel = 1;
                    break;

                case "dev":
                    user = "dev";
                    userlevel = 2;
                    break;


                case "admin":
                    user = "admin";
                    userlevel = 3;
                    break;

                default:
                    break;
            }
        }


        public static string[] adminitems = new string[] {"", "AdminLogin", "Memory1", "Memory2", "Memory3", "Memory4", "Memory5"};

        public void TerminalInteraction()
        {
            //engine.ChangeActiveScene(Terminal);
            Console.Clear();
            Console.Title = "Debug Terminal";
            ClearScreen();
            while (Console.KeyAvailable)
            {
                Console.ReadKey(true);
            }

            bool exit = false;
            while (!exit)
            {
                Console.Write($"{user}> ");
                string input = Console.ReadLine() + "      ";

                switch (input.Split(' ')[0])
                {
                    case "exit":
                        exit = true;
                        break;

                    case "help":
                        DisplayHelp();
                        break;

                    case "login":
                        switch (input.Split(' ')[1])
                        {
                            case "guest":
                                ChangeUser("guest");
                                Console.WriteLine("logged into guest Account.");
                                break;

                            case "user":
                                if (input.Split(' ')[2] == MainGame.Passwords[0])
                                {
                                    ChangeUser("user");
                                    Console.WriteLine("logged into user Account.");
                                }
                                else
                                {
                                    Console.WriteLine("Invalid Password!");
                                }
                                break;

                            case "dev":
                                if (input.Split(' ')[2] == MainGame.Passwords[1])
                                {
                                    ChangeUser("dev");
                                    Console.WriteLine("logged into dev Account.");
                                }
                                else
                                {
                                    Console.WriteLine("Invalid Password!");
                                }
                                break;
                            case "admin":
                                if (input.Split(' ')[2] == MainGame.Passwords[2])
                                {
                                    ChangeUser("admin");
                                    Console.WriteLine("logged into admin Account.");
                                }
                                else
                                {
                                    Console.WriteLine("Invalid Password!");
                                }
                                break;

                            default:
                                Console.WriteLine("Invalid User!");
                                break;
                        }
                        break;

                    case "cls":
                        ClearScreen();
                        break;

                    case "crash":
                        Console.WriteLine("Nope.");
                        break;

                    case "give":
                        if (userlevel > 1)
                        {
                            MainGame.Item togive = new MainGame.Item();
                            int amount = 1;
                            if (Items.ItemDictionary.ContainsKey(input.Split(' ')[1]))
                            {
                                if (int.TryParse(input.Split(' ')[2], out int temp2))
                                {
                                    amount = temp2;
                                }
                                togive = Items.ItemDictionary[input.Split(' ')[1]];

                                if (amount > 0)
                                {
                                    if (!adminitems.Contains(input.Split(' ')[1]) || userlevel > 2)
                                    {
                                        Console.WriteLine($"added {amount}x \"{togive.name}\" to inventory");
                                        Inv.AddItemToInv(togive, amount);
                                    }
                                    else
                                    {
                                        Console.WriteLine("Item is admin only.");
                                    }
                                }
                            }
                            else
                            {
                                if (input.Split(' ')[1] == "--")
                                {
                                    if (userlevel > 2)
                                    {
                                        if (int.TryParse(input.Split(' ')[3], out int temp2))
                                        {
                                            amount = temp2;
                                        }
                                        togive = new MainGame.Item() { name = input.Split(' ')[2], type = -2 };

                                        if (amount > 0)
                                        {
                                            if (!adminitems.Contains(input.Split(' ')[1]) || userlevel > 2)
                                            {
                                                Console.WriteLine($"added {amount}x \"{togive.name}\" to inventory");
                                                Inv.AddItemToInv(togive, amount);
                                            }
                                            else
                                            {
                                                Console.WriteLine("Item is admin only.");
                                            }
                                        }
                                    }
                                    else
                                    {
                                        Console.WriteLine("Invalid Permissions.");
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("Invalid Item.");
                                }
                            }

                        }
                        else
                        {
                            Console.WriteLine("Invalid Permissions.");
                        }
                        break;

                    case "list_items":
                        if (userlevel > 1)
                        {
                            Console.WriteLine("All Items:");
                            Console.WriteLine("\"\",\"nothing\",\"Ring\", \"UserLogin\", \"DevLogin\", \"AdminLogin\", \"Memory1\", \"Memory2\", \"Memory3\", \"Memory4\", \"Memory5\", \"Vibe\", \"Sandwich\", \"test\", \"exit\", \"FenceKey\"");
                        }
                        else
                        {
                            Console.WriteLine("Invalid Permissions.");
                        }
                        break;


                    case "time_machine":
                        if (userlevel > 0)
                        {
                            Console.WriteLine("Launching Time Machine Program...");
                            Process p = new Process();
                            p.StartInfo.WorkingDirectory = "Engine\\Sprites\\Time machine";
                            p.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Normal;
                            p.StartInfo.FileName = "Time machine.exe";
                            p.Start();

                        }
                        break;

                    case "speed":
                        if (userlevel > 0)
                        {
                            if (int.TryParse(input.Split(' ')[1], out int speed))
                            {
                                if (speed >= 0 && speed <= 20)
                                {
                                    MainGame.speed = speed;
                                    ClearScreen();
                                    Console.WriteLine($"Set Speed to {speed}.");
                                }
                                else
                                {
                                    Console.WriteLine($"Invalid speed!");
                                }
                            }
                            else
                            {
                                Console.WriteLine($"Invalid speed!");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Invalid Permissions.");
                        }
                        break;

                    case "background":
                        if (userlevel > 0)
                        {
                            if (int.TryParse(input.Split(' ')[1], out int col))
                            {
                                if (col >= 0 && col <= 15)
                                {
                                    MainGame.engine.SetNewBackroundColour(col);
                                    ClearScreen();
                                    Console.WriteLine($"Set Background Colour to {col}.");
                                }
                                else
                                {
                                    Console.WriteLine($"Invalid colour!");
                                }
                            }
                            else
                            {
                                Console.WriteLine($"Invalid colour!");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Invalid Permissions.");
                        }
                        break;


                    case "edit_mode":
                        if (userlevel > 2)
                        {
                            MainGame.editor_mode = !MainGame.editor_mode;
                            Console.WriteLine($"Set edit mode to {MainGame.editor_mode}");
                        }
                        else
                        {
                            Console.WriteLine("Invalid Permissions.");
                        }
                        break;
                    case "unlock_door":
                        if (userlevel > 2)
                        {
                            MainGame.DoorUnlocked = true;
                            Console.WriteLine("Unlocked the door.");
                        }
                        else
                        {
                            Console.WriteLine("Invalid Permissions.");
                        }
                        break;


                    default:
                        if (input.Split(' ')[0] != "")
                        {
                            Console.WriteLine($"Invalid Command \"{input.Split(' ')[0]}\"! (use \"help\" for help)");
                        }
                        break;
                }
            }
            engine.ChangeActiveScene(Game);
            Console.Title = "Marcel Engine";
            engine.RenderFrame(20);
        }
        public void ClearScreen()
        {
            Console.Clear();
            Console.WriteLine(title);
            Console.WriteLine("-------------------------------------------");
            Console.WriteLine();
        }

        public void DisplayHelp()
        {
            ClearScreen();
            Console.WriteLine("Help Page:");
            Console.WriteLine("----------");

            if (userlevel >= 0)
            {
                Console.WriteLine("\nGuest Commands:");
                Console.WriteLine("exit - exits the terminal.");
                Console.WriteLine("help - displays help.");
                Console.WriteLine("login (username) (pass) - logs into an account");
                Console.WriteLine("cls - clears the screen");
                Console.WriteLine("crash - crashes the game");
            }

            if (userlevel > 0)
            {
                Console.WriteLine("\nUser Commands:");
                Console.WriteLine("speed (amount) - changes the movement speed");
                Console.WriteLine("time_machine - launches a time machine");
                Console.WriteLine("background (a number between 0 and 15) - changes the background colour");
            }

            if (userlevel > 1)
            {
                Console.WriteLine("\nDeveloper Commands:");
                Console.WriteLine("give (itemname) (optional amount) - gives you an item");
                Console.WriteLine("list_items - prints all items.");
            }

            if (userlevel > 2)
            {
                Console.WriteLine("\nAdmin Commands:");
                Console.WriteLine("edit_mode - toggles the edit mode");
                Console.WriteLine("unlock_door - unlocks the house door");
            }
            //Console.WriteLine("\"\",\"nothing\",\"Ring\", \"UserLogin\", \"DevLogin\", \"AdminLogin\", \"Vibe\", \"Sandwich\",\"Memory1\", \"Memory2\", \"Memory3\", \"Memory4\", \"Memory5\", \"test\", \"exit\", \"FenceKey\"");

            Console.WriteLine("\nPress Enter to exit...");
            Console.ReadLine();
            ClearScreen();
        }
    }
}
