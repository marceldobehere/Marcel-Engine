﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;
using Object = Engine.Object;
using Testing_the_engine_lol;
using System.IO;
using Extra;
using Newtonsoft.Json;

namespace Extra
{
    class SavingAndLoading
    {
        public static void SaveMap(string name)
        {
            List<string> data = new List<string>();

            foreach (MainGame.GameObject x in MainGame.ObjectsSpawnedFromEditor)
            {
                List<string> parameters = new List<string>();
                parameters.Add(x.EditorName);
                parameters.Add("" + x.OBJ.Position.x);
                parameters.Add("" + x.OBJ.Position.y);

                StringBuilder temp = new StringBuilder();
                foreach (string y in parameters)
                {
                    temp.Append(y + "|");
                }
                data.Add(temp.ToString());
            }

            Console.Title = "Saved.";
            System.Threading.Thread.Sleep(500);


            //Console.Clear();
            StreamWriter writer = new StreamWriter(name);
            foreach (string x in data)
            {
                //Console.WriteLine(x);
                writer.WriteLine(x);
            }
            writer.Close();
            //Console.ReadLine();
        }

        public static void LoadMap(string name)
        {
            while (MainGame.ObjectsSpawnedFromEditor.Count > 0)
            {
                MainGame.GameObject x = MainGame.ObjectsSpawnedFromEditor[0];
                MainGame.engine.RemoveObjectFromScene(x.OBJ);
                MainGame.GameObjects.Remove(x);
                MainGame.ObjectsSpawnedFromEditor.Remove(x);
            }

            List<string> data = new List<string>();
            StreamReader reader = new StreamReader(name);
            while (!reader.EndOfStream)
            {
                string[] parameters = reader.ReadLine().Split('|');
                MainGame.GameObject temp = MainGame.EditorObjects[parameters[0]];

                temp.OBJ = temp.OBJ.Clone();
                temp.OBJ.Position = (int.Parse(parameters[1]), int.Parse(parameters[2]));
                temp.OBJ.Update();

                MainGame.engine.AddObjectToScene(temp.OBJ);
                MainGame.ObjectsSpawnedFromEditor.Add(temp);
                MainGame.GameObjects.Add(temp);
            }

            reader.Close();

            Console.Title = "Loaded Map.";
            System.Threading.Thread.Sleep(500);
        }
    }
}
