﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;
using Extra;
using Object = Engine.Object;
using Testing_the_engine_lol;
using System.IO;
using Newtonsoft.Json;

namespace Extra
{
    class PreparationsEditor
    {
        static void AddObjectToEditor(string Editorname, string Gamename, string spritedirectory, int type, bool wall, int layer)
        {
            {
                Object temp = new Object();
                temp.ActiveObjectType = 1;
                temp.Player.ActiveSprite = new Graphics.Sprite(spritedirectory, false);
                temp.Layer = layer;

                MainGame.EditorObjects.Add(Editorname, new MainGame.GameObject() { OBJ = temp, EditorName = Editorname, name = Gamename, type = type, wall = wall });
            }
        }
        public static void PrepareSpawnableObjects()
        {
            MainGame.ObjectsSpawnedFromEditor = new List<MainGame.GameObject>();
            MainGame.EditorObjects = new Dictionary<string, MainGame.GameObject>();
            {
                Object temp = new Object();

                MainGame.EditorObjects.Add("", new MainGame.GameObject() { OBJ = temp, EditorName = "", name = "empty", type = 2, wall = true });
            }
            //AddObjectToEditor("", "", "", 0, false, 0);

            AddObjectToEditor("Brick", "brick", @"Engine\Sprites\Objects\brick.mesf", 2, true, 10);
            AddObjectToEditor("Tree", "tree", @"Engine\Sprites\Objects\tree.mesf", 2, true, 10);
            AddObjectToEditor("BlackTree", "treeblack", @"Engine\Sprites\Objects\treeblack.mesf", 2, true, 10);
            AddObjectToEditor("Fence", "fence", @"Engine\Sprites\Objects\fence.mesf", 2, true, 10);
            AddObjectToEditor("LFence1", "lockedfence1", @"Engine\Sprites\Objects\locked_fence1.mesf", 6, false, 10);
            AddObjectToEditor("LFence2", "lockedfence2", @"Engine\Sprites\Objects\locked_fence2.mesf", 2, true, 10);
            AddObjectToEditor("VFence", "vertical_fence", @"Engine\Sprites\Objects\fence_vertical.mesf", 2, true, 10);

            AddObjectToEditor("Terminal", "terminal", @"Engine\Sprites\Objects\terminal.mesf", 1, false, 10);

            AddObjectToEditor("House", "house", @"Engine\Sprites\Objects\house.mesf", 4, true, 10);
            AddObjectToEditor("Door", "door", @"Engine\Sprites\Objects\door.mesf", 5, false, 10);

            AddObjectToEditor("Path", "path", @"Engine\Sprites\Objects\path.mesf", 2, false, 8);
            AddObjectToEditor("Flowers", "flowers", @"Engine\Sprites\Objects\flowers.mesf", 2, false, 8);
            AddObjectToEditor("Grass", "grass", @"Engine\Sprites\Objects\grass.mesf", 2, false, 8);

            AddObjectToEditor("Bush", "grass", @"Engine\Sprites\Objects\bush.mesf", 2, true, 10);

            AddObjectToEditor("Ring", "ring", @"Engine\Sprites\Objects\ring.mesf", 7, false, 10);
            AddObjectToEditor("Fencekey", "fencekey", @"Engine\Sprites\Objects\fencekey.mesf", 11, false, 10);
            AddObjectToEditor("Memory1", "memory1", @"Engine\Sprites\Objects\note.mesf", 9, false, 10);
            AddObjectToEditor("Memory2", "memory2", @"Engine\Sprites\Objects\note.mesf", 12, false, 10);
            AddObjectToEditor("Memory5", "memory2", @"Engine\Sprites\Objects\note.mesf", 16, false, 10);
            AddObjectToEditor("Memory4", "memory4", @"Engine\Sprites\Objects\note.mesf", 18, false, 10);

            AddObjectToEditor("Vibe", "vibing advice", @"Engine\Sprites\Objects\note.mesf", 14, false, 10);

            AddObjectToEditor("NPC_1", "NPC_1", @"Engine\Sprites\NPC\stoneman.mesf", 3, false, 10);
            AddObjectToEditor("NPC_2", "NPC_2", @"Engine\Sprites\NPC\sadstoneman.mesf", 8, false, 10);
            AddObjectToEditor("NPC_3", "NPC_3", @"Engine\Sprites\NPC\stoneman2.mesf", 10, false, 10);
            AddObjectToEditor("NPC_4", "NPC_4", @"Engine\Sprites\NPC\smolguy.mesf", 13, false, 10);
            AddObjectToEditor("NPC_5", "NPC_5", @"Engine\Sprites\NPC\bigston.mesf", 15, false, 10);
            AddObjectToEditor("NPC_6", "NPC_6", @"Engine\Sprites\NPC\lastguy.mesf", 17, false, 10);
        }
    }
}
