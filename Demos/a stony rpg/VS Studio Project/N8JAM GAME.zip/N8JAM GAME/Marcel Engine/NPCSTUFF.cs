﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;
using Extra;
using Object = Engine.Object;
using Testing_the_engine_lol;
using System.IO;
using Newtonsoft.Json;

namespace Extra
{
    class NPC
    {
        public static List<string> ActiveQuests;
        public static List<string> FinishedQuests;

        public static void NPC1Interaction()
        {
            if (!ActiveQuests.Contains("starter Quest") && !FinishedQuests.Contains("starter Quest"))
            {
                Text.DisplayText("Can you Please collect my ring?", true);
                Text.DisplayText("Wait!\nI can just force you to get my ring by giving you a Quest!", true);
                ActiveQuests.Add("starter Quest");
                MainGame.QuestS.Play();
                Text.DisplayText("*got a new Quest*", true);
                Text.DisplayText("Just Talk to me when you found it!\nCyaaaaa");

            }
            else
            {
                if (FinishedQuests.Contains("starter Quest"))
                {
                    Text.DisplayText("oof what do you want?");
                }
                else
                {
                    if (MainGame.Inventory.ContainsKey(Items.ItemDictionary["Ring"]))
                    {
                        Text.DisplayText("Thanks for doing the quest bro!", true);
                        Text.DisplayText("Here is absolutely nothing!", true);
                        Inv.AddItemToInv(Items.ItemDictionary["nothing"]);
                        MainGame.CollectS.Play();
                        Text.DisplayText("*got nothing*", true);
                        Text.DisplayText("Cyaaa");
                        Inv.RemoveItemFromInv(Items.ItemDictionary["Ring"]);
                        MainGame.QuestDoneS.Play();
                        ActiveQuests.Remove("starter Quest");
                        FinishedQuests.Add("starter Quest");
                    }
                    else
                    {
                        Text.DisplayText("Go do your Quest bro!");
                    }
                }
            }
        }
        public static void NPC2Interaction(MainGame.GameObject x)
        {
            if (MainGame.TerminalUnlocked && !ActiveQuests.Contains("nothing quest") && !FinishedQuests.Contains("nothing quest"))
            {
                Text.DisplayText("Im so lonely...", true);
                Text.DisplayText("I don't even have nothing :(", true);
                Text.DisplayText("Could you give me nothing?\nIt would make me a bit happier.", true);
                ActiveQuests.Add("nothing quest");
                MainGame.QuestS.Play();
                Text.DisplayText("*got a new Quest*", true);
                Text.DisplayText("byeeee :(");

            }
            else
            {
                if (FinishedQuests.Contains("nothing quest"))
                {
                    Text.DisplayText("thanks for the nothing :)");
                }
                else
                {
                    if (MainGame.TerminalUnlocked && MainGame.Inventory.ContainsKey(Items.ItemDictionary["nothing"]))
                    {
                        Text.DisplayText("OMG!!!\nThank you so much!!!!!!!!", true);
                        Text.DisplayText("Im Happy now :)", true);
                        MainGame.CollectS.Play();
                        Text.DisplayText("*Got User Login Details*", true);
                        Inv.AddItemToInv(Items.ItemDictionary["UserLogin"]);
                        Text.DisplayText("Cyaaa");

                        x.OBJ.Player.ActiveSprite = new Graphics.Sprite(@"Engine\Sprites\NPC\happystoneman.mesf", false);
                        x.OBJ.Update();
                        MainGame.QuestDoneS.Play();
                        Inv.RemoveItemFromInv(Items.ItemDictionary["nothing"]);
                        ActiveQuests.Remove("nothing quest");
                        FinishedQuests.Add("nothing quest");
                    }
                    else
                    {
                        Text.DisplayText("Im so lonely...");
                    }
                }
            }
        }
        public static void NPC3Interaction()
        {
            if (!ActiveQuests.Contains("info quest") && !FinishedQuests.Contains("info quest"))
            {
                Text.DisplayText("I have some information for you...", true);
                Text.DisplayText("Since you are probably confused on where you are on how to get out.", true);
                Text.DisplayText("I like the colour light green.", true);
                Text.DisplayText("I would maybe tell you the information if the backround would be light green.", true);
                ActiveQuests.Add("info quest");
                MainGame.QuestS.Play();
                Text.DisplayText("*got a new Quest*");

            }
            else
            {
                if (FinishedQuests.Contains("info quest"))
                {
                    if (MainGame.engine.Display.BackroundColour == 11)
                    {
                        Text.DisplayText("Hope the information helped!");
                    }
                    else
                    {
                        Text.DisplayText("where light green >:(");
                    }
                }
                else
                {
                    if (MainGame.engine.Display.BackroundColour == 11)
                    {
                        Text.DisplayText("Its much better now!", true);
                        Text.DisplayText("Also heres ya information:", true);
                        Inv.AddItemToInv(Items.ItemDictionary["Memory3"]);
                        MainGame.CollectS.Play();
                        Text.DisplayText("*got a new Memory*", true);
                        Text.DisplayText("Cyaaa");

                        MainGame.QuestDoneS.Play();
                        ActiveQuests.Remove("info quest");
                        FinishedQuests.Add("info quest");
                    }
                    else
                    {
                        Text.DisplayText("Did you know that I like the colour light green?");
                    }
                }
            }
        }
        public static void NPC5Interaction()
        {
            if (MainGame.Inventory.ContainsKey(Items.ItemDictionary["UserLogin"]) && !ActiveQuests.Contains("sandwich quest") && !FinishedQuests.Contains("sandwich quest"))
            {
                Text.DisplayText("I'm really hungry", true);
                Text.DisplayText("Can you like... give me a sandwich?\nAND I DONT CARE IF IT DOESN'T EXIST!!!!", true);
                Text.DisplayText("If yes I'll give you something really cool!", true);
                ActiveQuests.Add("sandwich quest");
                MainGame.QuestS.Play();
                Text.DisplayText("*got a new Quest*");

            }
            else
            {
                if (FinishedQuests.Contains("sandwich quest"))
                {
                    Text.DisplayText("thanks for the sandwich!");
                }
                else
                {
                    if (MainGame.Inventory.ContainsKey(Items.ItemDictionary["UserLogin"]) && MainGame.Inventory.ContainsKey(Items.ItemDictionary["Sandwich"]) && ActiveQuests.Contains("sandwich quest"))
                    {
                        Text.DisplayText("Ohh... This looks tasty!", true);
                        Text.DisplayText("Thanks for the sandwich and here you go.", true);
                        MainGame.CollectS.Play();
                        Text.DisplayText("*Got a new Memory*", true);
                        Inv.AddItemToInv(Items.ItemDictionary["Memory5"]);
                        Text.DisplayText("Cyaaa");

                        MainGame.QuestDoneS.Play();
                        Inv.RemoveItemFromInv(Items.ItemDictionary["Sandwich"]);
                        ActiveQuests.Remove("sandwich quest");
                        FinishedQuests.Add("sandwich quest");
                    }
                    else
                    {
                        Text.DisplayText("Im sooo hungry....");
                    }
                }
            }
        }
        public static void NPC6Interaction()
        {
            if (FinishedQuests.Count == 5 && MainGame.Inventory.ContainsKey(Items.ItemDictionary["Memory5"]))
            {
                if (!MainGame.Inventory.ContainsKey(Items.ItemDictionary["AdminLogin"]))
                {
                    Text.DisplayText("So...\nYou finally figured it all out.\nNow you want to unlock the house, don't you", true);
                    Text.DisplayText("Fine...\nSince you did all of the Quest, I will have to give you something in return...", true);
                    MainGame.CollectS.Play();
                    Text.DisplayText("*got Admin Login Details*", true);
                    Inv.AddItemToInv(Items.ItemDictionary["AdminLogin"]);
                    Text.DisplayText("take care");
                }
                else
                {
                    Text.DisplayText("*Now you can finally leave...*");
                }
            }
            else
            {
                Text.DisplayText("*???*");
            }
        }
        public static void NPC4Interaction()
        {
            //MainGame.Inventory.ContainsKey(Items.ItemDictionary["UserLogin"]) && 
            if (MainGame.Inventory.ContainsKey(Items.ItemDictionary["UserLogin"]) && !ActiveQuests.Contains("dev quest") && !FinishedQuests.Contains("dev quest"))
            {
                Text.DisplayText("I heard you want to escape this game...", true);
                Text.DisplayText("If you have some nice vibing advice for me, I'll give you something that will help you escape.", true);
                ActiveQuests.Add("dev quest");
                MainGame.QuestS.Play();
                Text.DisplayText("*got a new Quest*");

            }
            else
            {
                if (FinishedQuests.Contains("dev quest"))
                {
                    Text.DisplayText("*The stone is currently vibing.*");

                }
                else
                {
                    if (ActiveQuests.Contains("dev quest"))
                    {
                        if (MainGame.Inventory.ContainsKey(Items.ItemDictionary["UserLogin"]) && MainGame.Inventory.ContainsKey(Items.ItemDictionary["Vibe"]))
                        {
                            Text.DisplayText("Thanks for the advice! Now I can finally vibe correctly! :)", true);
                            Text.DisplayText("Also here you go:", true);
                            Inv.AddItemToInv(Items.ItemDictionary["DevLogin"]);
                            MainGame.CollectS.Play();
                            Text.DisplayText("*got Developer Login Details*", true);
                            Text.DisplayText("Good luck escaping!");
                            Inv.RemoveItemFromInv(Items.ItemDictionary["Vibe"]);
                            MainGame.QuestDoneS.Play();
                            ActiveQuests.Remove("dev quest");
                            FinishedQuests.Add("dev quest");
                        }
                        else
                        {
                            Text.DisplayText("*The stone is waiting for your vibing advice...*");
                        }
                    }
                    else
                    {
                        Text.DisplayText("*This stone is currently trying to vibe.\nhe does not want to be disturbed right now.*");
                    }
                }
            }
        }
    }
}
