﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;
using Extra;
using Object = Engine.Object;
using Testing_the_engine_lol;
using System.IO;
using Newtonsoft.Json;

namespace Extra
{
    class Text
    {
        public static void DisplayText(string text, bool continuetext = false)
        {
            MainGame.UI.Player.ActiveSprite = new Graphics.Sprite(@"Engine\Sprites\UI\UI_TEXT.mesf", false);
            MainGame.UI.Update();
            MainGame.engine.RenderFrame(20);
            List<string> textlist = new List<string>();
            foreach (string x in text.Split('\n'))
            {
                string temp = "";
                for (int i = 0; i < x.Length; i++)
                {
                    temp = temp + x[i];
                    if (temp.Length > 84)
                    {
                        textlist.Add(temp + "-");
                        temp = "";
                    }
                }
                textlist.Add(temp);
                temp = "";
            }
            while (textlist.Count < 4)
            {
                textlist.Add("");
            }

            for (int i = 0; i < 4; i++)
            {
                MainGame.TextLines[i] = new Object();
                MainGame.TextLines[i].ActiveObjectType = 2;
                MainGame.TextLines[i].Layer = 2000;
                MainGame.engine.AddObjectToScene(MainGame.TextLines[i]);
                MainGame.TextLines[i].OffsetPosition = (2, (51) + i * 2);
            }

            int textline = 0;
            while (textline < textlist.Count - 3)
            {
                for (int i = 0; i < 4; i++)
                {
                    MainGame.TextLines[i].Text.Text = textlist[textline + i];
                    MainGame.TextLines[i].Update();
                    MainGame.engine.RenderFrame(15);
                }
                textline++;
                MainGame.engine.RenderFrame(5);
                while (MainGame.inp.KeyPressed(Input.Key.Spacebar))
                {

                }
                while (!MainGame.inp.KeyPressed(Input.Key.Spacebar))
                {

                }
                MainGame.SelectS.Play();
            }
            while (MainGame.inp.KeyPressed(Input.Key.Spacebar))
            {

            }

            for (int i = 0; i < 4; i++)
            {
                MainGame.engine.RemoveObjectFromScene(MainGame.TextLines[i]);
            }
            if (!continuetext)
            {
                MainGame.UI.Player.ActiveSprite = new Graphics.Sprite(@"Engine\Sprites\UI\UI_NTEXT.mesf", false);
                MainGame.UI.Update();
                MainGame.engine.RenderFrame(-1);
            }
        }
        public static void DisplayTextInv(string text, bool continuetext = false)
        {
            MainGame.UI.Player.ActiveSprite = new Graphics.Sprite(@"Engine\Sprites\UI\UI_INV_TEXT.mesf", false);
            MainGame.UI.Update();
            MainGame.engine.RenderFrame(20);
            List<string> textlist = new List<string>();
            foreach (string x in text.Split('\n'))
            {
                string temp = "";
                for (int i = 0; i < x.Length; i++)
                {
                    temp = temp + x[i];
                    if (temp.Length > 84)
                    {
                        textlist.Add(temp + "-");
                        temp = "";
                    }
                }
                textlist.Add(temp);
                temp = "";
            }
            while (textlist.Count < 4)
            {
                textlist.Add("");
            }

            for (int i = 0; i < 4; i++)
            {
                MainGame.TextLines[i] = new Object();
                MainGame.TextLines[i].ActiveObjectType = 2;
                MainGame.TextLines[i].Layer = 2000;
                MainGame.engine.AddObjectToScene(MainGame.TextLines[i]);
                MainGame.TextLines[i].OffsetPosition = (2, (51) + i * 2);
            }

            int textline = 0;
            while (textline < textlist.Count - 3)
            {
                for (int i = 0; i < 4; i++)
                {
                    MainGame.TextLines[i].Text.Text = textlist[textline + i];
                    MainGame.TextLines[i].Update();
                    MainGame.engine.RenderFrame(15);
                }
                textline++;
                MainGame.engine.RenderFrame(5);
                while (MainGame.inp.KeyPressed(Input.Key.Spacebar))
                {

                }
                while (!MainGame.inp.KeyPressed(Input.Key.Spacebar))
                {

                }
                MainGame.SelectS.Play();
            }
            while (MainGame.inp.KeyPressed(Input.Key.Spacebar))
            {

            }

            for (int i = 0; i < 4; i++)
            {
                MainGame.engine.RemoveObjectFromScene(MainGame.TextLines[i]);
            }
            if (!continuetext)
            {
                MainGame.UI.Player.ActiveSprite = new Graphics.Sprite(@"Engine\Sprites\UI\UI_INV.mesf", false);
                MainGame.UI.Update();
                MainGame.engine.RenderFrame(-1);
            }
        }
    }
}
