﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;
using Extra;
using Object = Engine.Object;
using Testing_the_engine_lol;
using System.IO;
using Newtonsoft.Json;

namespace Extra
{
    class PreparationsMenu
    {
        public static void PrepareMenu()
        {
            MainGame.Menu = new Scene();
            MainGame.engine.ChangeActiveScene(MainGame.Menu);



            MainGame.engine.ChangeActiveScene(MainGame.Game);
        }
    }




    class MENU
    {
        public static bool exit;
        public static void GoIntoMenu()
        {
            MainGame.engine.ChangeActiveScene(MainGame.Menu);
            int temp_backroundcol = MainGame.engine.Display.BackroundColour;
            MainGame.engine.SetNewBackroundColour(0);
            MainGame.engine.RenderFrame(-1);


            Console.WriteLine("Options Menu");
            Console.WriteLine("------------");
            Console.WriteLine();

            exit = false;
            while (!exit)
            {
                Console.Write("Options> ");
                string[] command = (Console.ReadLine() + "       ").Split(' ');
                switch (command[0])
                {
                    case "":
                        Console.WriteLine();
                        break;

                    case "help":
                        Help();
                        break;

                    case "exit":
                        exit = true;
                        break;

                    case "Volume":

                        switch (command[1])
                        {
                            case "set":
                                if (int.TryParse(command[3], out int temp_vol))
                                {
                                    if (command[2] == "sfx")
                                    {
                                        if (temp_vol >= 0 && temp_vol <= 100)
                                        {
                                            MainGame.ChangeSFX(temp_vol);
                                            Console.WriteLine($"Changed SFX Volume to {temp_vol}%");
                                        }
                                        else
                                        {
                                            Console.WriteLine("Invalid Volume. (Should be in the range of 0 - 100)");
                                        }
                                    }
                                    else if (command[2] == "bgm")
                                    {
                                        if (temp_vol >= 0 && temp_vol <= 100)
                                        {
                                            MainGame.ChangeBGM(temp_vol);
                                            Console.WriteLine($"Changed BGM Volume to {temp_vol}%");
                                        }
                                        else
                                        {
                                            Console.WriteLine("Invalid Volume. (Should be in the range of 0 - 100)");
                                        }
                                    }
                                    else
                                    {
                                        Console.WriteLine("Invalid Option.");
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("Invalid Volume.");
                                }
                                break;



                            case "get":
                                if (command[2] == "sfx")
                                {
                                    Console.WriteLine($"SFX Volume = {MainGame.SFXVolume}%");
                                }
                                else if (command[2] == "bgm")
                                {
                                    Console.WriteLine($"BGM Volume = {MainGame.BGMVolume}%");
                                }
                                else
                                {
                                    Console.WriteLine("Invalid Option.");
                                }
                                break;


                            default:
                                Console.WriteLine("Invalid Option.");
                                break;
                        }

                        break;

                    default:
                        Console.WriteLine($"Invalid command \"{command[0]}\". Use \"help\" for help.");
                        break;
                }
            }

            MainGame.engine.SetNewBackroundColour(temp_backroundcol);
            MainGame.engine.ChangeActiveScene(MainGame.Game);
            MainGame.engine.RenderFrame(-1);
        }


        public static void Help()
        {
            Console.Clear();
            Console.WriteLine("Options Menu - Help");
            Console.WriteLine("------------");
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("help - displays help");
            Console.WriteLine("exit - exits the Options Menu");
            Console.WriteLine();
            Console.WriteLine("Volume set (sfx|bgm) (Volume in 0 - 100) - Sets the Volume of either the Soundeffects or the Background music.");
            Console.WriteLine("Volume get ((sfx|bgm) - Gets the Volume of either the Soundeffects or the Background music.");






            Console.WriteLine("Press Enter to exit.");
            Console.ReadLine();



            Console.Clear();
            Console.WriteLine("Options Menu");
            Console.WriteLine("------------");
            Console.WriteLine();
        }

    }
}
