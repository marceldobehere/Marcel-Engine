﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;

namespace Testing_the_engine_lol
{
    class Program
    {
        static void Main(string[] args)
        {

            Main_Engine engine = new Main_Engine((100, 50, 8));
            Screen scr = engine.display;
            Graphics test = engine.graphics;
            _OBJ_Misc obj = new _OBJ_Misc();
            Input inp = new Input();


            _Object Title = new _Object();
            Title.Active_obj_type = obj.Get_Typenum("Player");
            Title.Player.active_sprite = new Graphics.Sprite("Engine\\Sprites\\Title2.mesf");

            engine.Add_Obj_to_scene(Title);
            engine.Render_Frame(-1);
            engine.Get_Key();
            engine.Rem_Obj_from_scene(Title);
            engine.Render_Frame(-1);


            _Object Border = new _Object();
            Border.Active_obj_type = obj.Get_Typenum("Player");
            Border.Player.active_sprite = new Graphics.Sprite("Engine\\Sprites\\Border.mesf");
            engine.Add_Obj_to_scene(Border);


            _Object Paddle_1 = new _Object();
            Paddle_1.Active_obj_type = obj.Get_Typenum("Player");
            Graphics.Sprite Paddle_sprite = new Graphics.Sprite("Engine\\Sprites\\Paddle.mesf");
            Paddle_1.Player.active_sprite = Paddle_sprite;
            Paddle_1.layer = 2;

            _Object Paddle_2 = new _Object();
            Paddle_2.Active_obj_type = 1;
            Paddle_2.Player.active_sprite = Paddle_sprite;
            Paddle_2.layer = 2;


            _Object Ball = new _Object();
            Ball.Active_obj_type = obj.Get_Typenum("Player");
            Ball.Player.active_sprite = new Graphics.Sprite("Engine\\Sprites\\Ball.mesf");
            Ball.layer = 2;


            Graphics.Sprite_Lib nums = new Graphics.Sprite_Lib();
            nums.Sprites.Add("0", new Graphics.Sprite("Engine\\Sprites\\Nums\\0.mesf"));
            nums.Sprites.Add("1", new Graphics.Sprite("Engine\\Sprites\\Nums\\1.mesf"));
            nums.Sprites.Add("2", new Graphics.Sprite("Engine\\Sprites\\Nums\\2.mesf"));
            nums.Sprites.Add("3", new Graphics.Sprite("Engine\\Sprites\\Nums\\3.mesf"));
            nums.Sprites.Add("4", new Graphics.Sprite("Engine\\Sprites\\Nums\\4.mesf"));
            nums.Sprites.Add("5", new Graphics.Sprite("Engine\\Sprites\\Nums\\5.mesf"));
            nums.Sprites.Add("6", new Graphics.Sprite("Engine\\Sprites\\Nums\\6.mesf"));
            nums.Sprites.Add("7", new Graphics.Sprite("Engine\\Sprites\\Nums\\7.mesf"));
            nums.Sprites.Add("8", new Graphics.Sprite("Engine\\Sprites\\Nums\\8.mesf"));
            nums.Sprites.Add("9", new Graphics.Sprite("Engine\\Sprites\\Nums\\9.mesf"));
            nums.Sprites.Add("10", new Graphics.Sprite("Engine\\Sprites\\Nums\\0.mesf"));


            _Object Counter_1 = new _Object();
            Counter_1.Active_obj_type = obj.Get_Typenum("Player");
            Counter_1.Player.active_sprite = nums.Sprites[$"{0}"];
            engine.Add_Obj_to_scene(Counter_1);

            _Object Counter_2 = new _Object();
            Counter_2.Active_obj_type = obj.Get_Typenum("Player");
            Counter_2.Player.active_sprite = nums.Sprites[$"{0}"];
            engine.Add_Obj_to_scene(Counter_2);

            Counter_1.position = (42, 2);
            Counter_2.position = (50, 2);

            Paddle_1.position = (2, 22);
            Paddle_2.position = (97, 22);
            (int x, int y) middle = (50, 20);
            Ball.position = middle;

            engine.Add_Obj_to_scene(Paddle_1);
            engine.Add_Obj_to_scene(Paddle_2);
            engine.Add_Obj_to_scene(Ball);

            engine.Render_Frame(2);


            (int x, int y) ball_speed = (1,-1);

            (int P1, int P2) Score = (0, 0);

            bool end = false;
            while (!end)
            {
                Paddle_1.Move_y(inp.KeyPressed(Input.Key.S) && (Paddle_1.position.y < 38) ? 1 : 0);
                Paddle_1.Move_y(inp.KeyPressed(Input.Key.W) && (Paddle_1.position.y > 2) ? -1 : 0);

                Paddle_2.Move_y(inp.KeyPressed(Input.Key.DownArrow) && (Paddle_2.position.y < 38) ? 1 : 0);
                Paddle_2.Move_y(inp.KeyPressed(Input.Key.UpArrow)   && (Paddle_2.position.y > 2) ? -1 : 0);

                Ball.Move(ball_speed);
                if (Ball.position.y < 2 || Ball.position.y > 47)
                {
                    ball_speed.y *= -1;
                }
                if (Ball.position.x > 90 || Ball.position.x < 10)
                {
                    if (engine.Obj_collision(Ball, Paddle_1) || engine.Obj_collision(Ball, Paddle_2))
                    {
                        ball_speed.x *= -1;
                    }
                    else
                    {
                        if (Ball.position.x > 97)
                        {
                            Score.P1++;
                            Counter_1.Player.active_sprite = nums.Sprites[$"{Score.P1}"];
                            Ball.position = middle;
                            ball_speed.x *= -1;
                            ball_speed.y *= -1;
                            engine.Render_Frame(2);
                        }
                        else
                        {
                            if(Ball.position.x < 2)
                            {
                                Score.P2++;
                                Counter_2.Player.active_sprite = nums.Sprites[$"{Score.P2}"];
                                Ball.position = middle;
                                ball_speed.x *= -1;
                                engine.Render_Frame(2);
                            }
                        }
                    }
                }
                if (Score.P1 > 9 || Score.P2 > 9)
                {
                    end = true;
                }

                engine.Render_Frame(30);
            }


            engine.Rem_Obj_from_scene(Paddle_1);
            engine.Rem_Obj_from_scene(Paddle_2);
            engine.Rem_Obj_from_scene(Ball);
            engine.Rem_Obj_from_scene(Counter_1);
            engine.Rem_Obj_from_scene(Counter_2);
            if (Score.P1 > 9)
            {
                Border.Player.active_sprite = new Graphics.Sprite("Engine\\Sprites\\Player_1_Won.mesf");    
            }
            else
            {
                Border.Player.active_sprite = new Graphics.Sprite("Engine\\Sprites\\Player_2_Won.mesf");
            }

            engine.Render_Frame(1);

            while (!inp.KeyPressed(Input.Key.Q))
            {
                
            }


        }
    }
}
