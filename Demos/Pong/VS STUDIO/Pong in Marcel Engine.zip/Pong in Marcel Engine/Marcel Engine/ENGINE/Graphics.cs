﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Engine
{
    ///<summary>
    ///Graphics go brrrrr
    ///</summary>
    class Graphics
    {
        

        public Graphics()
        {
            
        }
        ///<summary>
        ///Its basically a Sprite Library, where you can have multiple Sprites.
        ///</summary>
        public class Sprite_Lib
        {
            ///<summary>
            ///A Dictionary of Sprites. You can add a Sprite and its name.
            ///</summary>
            public Dictionary<string, Sprite> Sprites;
            public Sprite_Lib()
            {
                Sprites = new Dictionary<string, Sprite>();
            }
        }

        ///<summary>
        ///A Sprite. Its this engines version of images.
        ///</summary>
        public class Sprite
        {
            ///<summary>
            ///Decides if the Sprite even has an image.
            ///</summary>
            public bool has_image { get;}
            ///<summary>
            ///The raw image data.
            ///</summary>
            public List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> image_data;
            ///<summary>
            ///The bordersize of the image. (Its kinda not needed but idk)
            ///</summary>
            static (int x, int y) bordersize;

            ///<summary>
            ///A normal Sprite setter.
            ///</summary>
            public Sprite()
            {
                bordersize = (0,0);
                has_image = false;
                image_data = new List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)>();
            }
            ///<summary>
            ///Generates a Sprite with a preset Image. (You just enter the Filename)
            ///</summary>
            public Sprite(string Filename)
            {
                bordersize = (0, 0);
                has_image = false;
                image_data = new List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)>();
                SetImage_fromfile(Filename);
            }
            ///<summary>
            ///Imports the Sprite image from a file. (The files are .mesf files and can be created with my Sprite Editor)
            ///</summary>
            public void SetImage_fromfile (string filename)
            {
                /*
                Fileformat is:
                (x_size)|(y_size)
                (brightness)|(col_b)|(col_f)|(relative_pos_x)|(relative_pos_y)
                (brightness)|(col_b)|(col_f)|(relative_pos_x)|(relative_pos_y)
                (brightness)|(col_b)|(col_f)|(relative_pos_x)|(relative_pos_y)
                (brightness)|(col_b)|(col_f)|(relative_pos_x)|(relative_pos_y)
                ...
                */
                image_data = new List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)>();

                StreamReader reader = new StreamReader(filename);
                string[] temp = reader.ReadLine().Split('|');
                bordersize.x = int.Parse(temp[0]);
                bordersize.y = int.Parse(temp[1]);

                while (!reader.EndOfStream)
                {
                    temp = reader.ReadLine().Split('|');
                    int[] t = new int[temp.Length];
                    for (int i = 0; i < temp.Length; i++)
                    {
                        t[i] = int.Parse(temp[i]);
                    }

                    image_data.Add(((char)0,(t[0], t[1], t[2]),(t[3], t[4])));
                }

                reader.Close();

            }
        }
    }
}
