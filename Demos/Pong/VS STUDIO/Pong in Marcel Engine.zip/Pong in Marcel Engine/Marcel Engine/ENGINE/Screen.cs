﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Runtime.InteropServices;



namespace Engine
{
    ///<summary>
    ///Screen go brrrrrrrr and oooof
    ///</summary>
    class Screen
    {
        ///<summary>
        ///Don't ask
        ///</summary>
        [DllImport("user32.dll")]
        public static extern bool ShowWindow(System.IntPtr hWnd, int cmdShow);
        ///<summary>
        ///Maxmizes the Window
        ///</summary>
        private static void Maximize()
        {
            Process p = Process.GetCurrentProcess();
            ShowWindow(p.MainWindowHandle, 3);
        }

        ///<summary>
        ///brightness of the colours go brrrrrr
        ///</summary>
        static string[] col_char = { "░░", "▒▒", "▓▓" };
        ///<summary>
        ///The colour list. Basically just all consolecolours but with an index
        ///</summary>
        static System.ConsoleColor[] cols =
            {
                System.ConsoleColor.Black,
                System.ConsoleColor.Blue,
                System.ConsoleColor.Cyan,
                System.ConsoleColor.DarkBlue,
                System.ConsoleColor.DarkCyan,
                System.ConsoleColor.DarkGray,
                System.ConsoleColor.DarkGreen,
                System.ConsoleColor.DarkMagenta,
                System.ConsoleColor.DarkRed,
                System.ConsoleColor.DarkYellow,
                System.ConsoleColor.Gray,
                System.ConsoleColor.Green,
                System.ConsoleColor.Magenta,
                System.ConsoleColor.Red,
                System.ConsoleColor.White,
                System.ConsoleColor.Yellow,
            };


        ///<summary>
        ///Size of the Window
        ///</summary>
        public static (int x, int y, int size) winsize;
        ///<summary>
        ///fps count
        ///</summary>
        public static double fps { get; set; }
        ///<summary>
        ///All Pixels on screen for the next frame
        ///</summary>
        static List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> pixel_live;
        ///<summary>
        ///All Pixels on screen for the last frame shown
        ///</summary>
        static (char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)[] pixel_old;

        ///<summary>
        ///Updates the title with the current fps
        ///</summary>
        public void Update_FPS(double fps_)
        {
            fps = fps_;
            Console.Title = $"Marcel Engine - FPS: {Math.Round(fps, 1)}";
        }

        ///<summary>
        ///Initialises the screen with a size
        ///</summary>
        public Screen((int x, int y, int size) size)
        {
            fps = 1;
            Console.Title = "Marcel Engine";
            Console.Clear();
            Console.WriteLine("Marcel Engine loading...");

            if (size.x > Console.LargestWindowWidth)
            {
                Console.WriteLine($"Decreasing X-Size from {size.x} to {Console.LargestWindowWidth}.");
                size.x = Console.LargestWindowWidth;
            }
            if (size.y > Console.LargestWindowHeight)
            {
                Console.WriteLine($"Decreasing Y-Size from {size.y} to {Console.LargestWindowHeight}.");
                size.y = Console.LargestWindowHeight;
            }
            winsize = size;
            Console.SetWindowSize(1, 1);
            ConsoleHelper.SetCurrentFont("Consolas", (short)winsize.size);
            Console.SetBufferSize(winsize.x * 2, winsize.y);
            //Console.SetWindowSize(Console.LargestWindowWidth, Console.LargestWindowHeight);

            pixel_old = new(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)[0];
            pixel_live = new List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)>();

            Maximize();

            Console.CursorVisible = false;
            //Console.ReadLine();
            Cls();
        }

        ///<summary>
        ///Draws a List of Pixels with the same colour but different positions on screen.
        ///</summary>
        public void Draw_Pixel((char chr, (int bri, int col_b, int col_f) col, (int x, int y)[] pos) data)
        {
            Console.BackgroundColor = cols[data.col.col_b];
            Console.ForegroundColor = cols[data.col.col_f];
            if (data.chr == 0)
            {
                string draw_c = col_char[data.col.bri];
                foreach ((int x, int y) pos in data.pos)
                {

                    Console.SetCursorPosition(pos.x * 2, pos.y);
                    Console.Write(draw_c);

                }
            }
            else
            {
                foreach ((int x, int y) pos in data.pos)
                {

                    Console.SetCursorPosition(pos.x * 2, pos.y);
                    Console.Write(data.chr + " ");

                }
            }
        }

        ///<summary>
        ///Draws a singular Pixel on screen.
        ///</summary>
        public void Draw_Pixel_singular((char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos) data)
        {
            Console.BackgroundColor = cols[data.col.col_b];
            Console.ForegroundColor = cols[data.col.col_f];


            Console.SetCursorPosition(data.pos.x * 2, data.pos.y);
            if (data.chr == 0)
            {
                Console.Write(col_char[data.col.bri]);
            }
            else
            {
                Console.Write(data.chr + " ");
            }


        }


        ///<summary>
        ///Adds a Pixel to the live Pixel list.
        ///</summary>
        public void Add_Pixel((char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos) data)
        {
            if (!((data.pos.x < 0) || (data.pos.y < 0) || (data.pos.x >= winsize.x) || (data.pos.y >= winsize.y)))
            {
                int indx = -1;

                for (int i = 0; i < pixel_live.Count; i++)
                {
                    if ((pixel_live[i].pos.x == data.pos.x) && (pixel_live[i].pos.y == data.pos.y))
                    {
                        indx = i;
                        break;
                    }
                }

                if (indx == -1)
                {
                    pixel_live.Add(data);
                }
                else
                {
                    pixel_live[indx] = data;
                }
            }
        }


        ///<summary>
        ///Adds all Pixels to the live Pixel list.
        ///</summary>
        public void Add_Pixels(List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> datas)
        {
            for (int i2 = 0; i2 < datas.Count; i2++)
            
            {
                (int x, int y) pos = datas[i2].pos;
                if (!((pos.x < 0) || (pos.y < 0) || (pos.x >= winsize.x) || (pos.y >= winsize.y)))
                {
                    int indx = -1;

                    for (int i = 0; i < pixel_live.Count; i++)
                    {
                        if ((pixel_live[i].pos.x == pos.x) && (pixel_live[i].pos.y == pos.y))
                        {
                            indx = i;
                            break;
                        }
                    }

                    if (indx == -1)
                    {
                        pixel_live.Add(datas[i2]);
                    }
                    else
                    {
                        pixel_live[indx] = datas[i2];
                    }
                }
            }
            /*
            foreach ((char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos) data in datas)
            {
                if (!((data.pos.x < 0) || (data.pos.y < 0) || (data.pos.x >= winsize.x) || (data.pos.y >= winsize.y)))
                {
                    int indx = -1;

                    for (int i = 0; i < pixel_live.Count; i++)
                    {
                        if ((pixel_live[i].pos.x == data.pos.x) && (pixel_live[i].pos.y == data.pos.y))
                        {
                            indx = i;
                            break;
                        }
                    }

                    if (indx == -1)
                    {
                        pixel_live.Add(data);
                    }
                    else
                    {
                        pixel_live[indx] = data;
                    }
                }
            }
             
             */
        }



        ///<summary>
        ///Removes a Pixel from the live pixel list.
        ///</summary>
        public void Remove_Pixel((int x, int y) pos)
        {
            for (int i = 0; i < pixel_live.Count; i++)
            {
                if ((pixel_live[i].pos.x == pos.x) && (pixel_live[i].pos.y == pos.y))
                {
                    pixel_live.RemoveAt(i);
                    i--;
                    break;
                }
            }
        }
        public (char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos) Get_Pixel_at ((int x, int y) pos)
        {
            for (int i = 0; i < pixel_live.Count; i++)
            {
                if ((pixel_live[i].pos.x == pos.x) && (pixel_live[i].pos.y == pos.y))
                {
                    return pixel_live[i];
                }
            }

            return ((char)0,(0,0,0),pos);
        }


        ///<summary>
        ///Reset/Clears the screen
        ///</summary>
        public void Cls()
        {
            Console.BackgroundColor = System.ConsoleColor.Black;
            Console.ForegroundColor = System.ConsoleColor.Black;
            Console.Clear();
        }

        ///<summary>
        ///Renders a Frame.
        ///</summary>
        public void Frame()
        {
            Compare_and_Draw();

            pixel_old = pixel_live.ToArray();
        }

        ///<summary>
        ///Renders all Objects into the live pixel list.
        ///</summary>
        public void Render_Objects(Dictionary<int, List<_Object>> objects, int max_layer)
        {
            pixel_live = new List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)>();

            for (int i = 0; i <= max_layer; i++)
            {
                if (objects.ContainsKey(i))
                {
                    Render_Object(objects[i]);
                }
            }
        }

        ///<summary>
        ///Gets all Pixels from a given Object.
        ///</summary>
        public List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> Get_Pixels_from_Object(_Object OBJ, bool to_screen)
        {
            List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> pixels_from_obj = new List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)>();

            List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> te;

            if (OBJ.Active_obj_type == 1)
            {
                if (OBJ.Player.sprite_animated)
                {
                    te = OBJ.Player.animation_lib.Sprites.ElementAt(OBJ.Player.animation_frame).Value.image_data;
                    if (to_screen)
                    {
                        for (int i = 0; i < te.Count; i++)
                        {
                            Add_Pixel((te[i].chr, te[i].col, ((te[i].pos.x + OBJ.position.x), (te[i].pos.y + OBJ.position.y))));
                        }
                    }
                    else
                    {
                        for (int i = 0; i < te.Count; i++)
                        {
                            pixels_from_obj.Add((te[i].chr, te[i].col, ((te[i].pos.x + OBJ.position.x), (te[i].pos.y + OBJ.position.y))));
                        }
                    }
                }
                else
                {
                    te = OBJ.Player.active_sprite.image_data;
                    if (to_screen)
                    {
                        for (int i = 0; i < te.Count; i++)
                        {
                            Add_Pixel((te[i].chr, te[i].col, ((te[i].pos.x + OBJ.position.x), (te[i].pos.y + OBJ.position.y))));
                        }
                    }
                    else
                    {
                        for (int i = 0; i < te.Count; i++)
                        {
                            pixels_from_obj.Add((te[i].chr, te[i].col, ((te[i].pos.x + OBJ.position.x), (te[i].pos.y + OBJ.position.y))));
                        }
                    }
                }
            }
            if (OBJ.Active_obj_type == 2)
            {
                if (OBJ.Text.transparent_backround)
                {
                    te = OBJ.Text.charpixels;
                    if (to_screen)
                    {
                        for (int i = 0; i < te.Count; i++)
                        {
                            (char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos) pixel2 = Get_Pixel_at(((te[i].pos.x + OBJ.position.x), (te[i].pos.y + OBJ.position.y)));
                            Add_Pixel((te[i].chr, (te[i].col.bri, pixel2.col.col_b, te[i].col.col_f), ((te[i].pos.x + OBJ.position.x), (te[i].pos.y + OBJ.position.y))));
                        }
                    }
                    else
                    {
                        for (int i = 0; i < te.Count; i++)
                        {
                            (char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos) pixel2 = Get_Pixel_at(((te[i].pos.x + OBJ.position.x), (te[i].pos.y + OBJ.position.y)));
                            pixels_from_obj.Add((te[i].chr, (te[i].col.bri, pixel2.col.col_b, te[i].col.col_f), ((te[i].pos.x + OBJ.position.x), (te[i].pos.y + OBJ.position.y))));
                        }
                    }
                }
                else
                {
                    te = OBJ.Text.charpixels;
                    if (to_screen)
                    {
                        for (int i = 0; i < te.Count; i++)
                        {
                            Add_Pixel((te[i].chr, te[i].col, ((te[i].pos.x + OBJ.position.x), (te[i].pos.y + OBJ.position.y))));
                        }
                    }
                    else
                    {
                        for (int i = 0; i < te.Count; i++)
                        {
                            pixels_from_obj.Add((te[i].chr, te[i].col, ((te[i].pos.x + OBJ.position.x), (te[i].pos.y + OBJ.position.y))));
                        }
                    }
                }
            }



            return pixels_from_obj;
        }





        ///<summary>
        ///Renders a singular Object into the live pixel list.
        ///</summary>
        private void Render_Object(List<_Object> objects)
        {
            foreach (_Object OBJ in objects)
            {
                Get_Pixels_from_Object(OBJ, true);


                if (OBJ.Active_obj_type == 1)
                {
                    if (OBJ.Player.sprite_animated)
                    {
                        OBJ.Player.Update_Animation();
                        continue;
                    }
                }
                if (OBJ.Active_obj_type == 2)
                {

                }
            }
        }

        ///<summary>
        ///Draws the changes of the live pixel list and the old pixel array
        ///</summary>
        private void Compare_and_Draw()
        {
            List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> pixel_draw = new List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)>();
            for (int i = 0; i < pixel_live.Count; i++)
            {
                bool t = true;
                (char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos) Y = pixel_live[i];
                for (int i2 = 0; i2 < pixel_old.Length; i2++)
                {
                    if ((pixel_old[i2].col.bri == Y.col.bri) && (pixel_old[i2].col.col_b == Y.col.col_b) && (pixel_old[i2].col.col_f == Y.col.col_f) && (pixel_old[i2].pos.x == Y.pos.x) && (pixel_old[i2].pos.y == Y.pos.y) && (pixel_old[i2].chr == Y.chr))
                    {
                        t = false;
                        break;
                    }
                }
                if (t)
                {
                    pixel_draw.Add(pixel_live[i]);
                }
            }


            for (int i2 = 0; i2 < pixel_old.Length; i2++)
            {
                (int x, int y) X = pixel_old[i2].pos;
                bool nhere = true;

                for (int i = 0; i < pixel_live.Count; i++)
                {
                    (int x, int y) temp = pixel_live[i].pos;
                    if ((X.x == temp.x) && (X.y == temp.y))
                    {
                        nhere = false;
                        break;
                    }
                }

                if (nhere)
                {
                    pixel_draw.Add(((char)0, (0, 0, 0), X));
                }
            }


            Dictionary<(char chr, (int bri, int col_b, int col_f) col), List<(int x, int y)>> temp_draw;
            temp_draw = new Dictionary<(char chr, (int bri, int col_b, int col_f) col), List<(int x, int y)>>();

            for (int i = 0; i < pixel_draw.Count; i++)
            {
                (char chr, (int bri, int col_b, int col_f) col) indx = (pixel_draw[i].chr, pixel_draw[i].col);
                if (!temp_draw.ContainsKey(indx))
                {
                    temp_draw.Add(indx, new List<(int x, int y)>());
                }
                temp_draw[indx].Add(pixel_draw[i].pos);
            }

            for (int i = 0; i < temp_draw.Count; i++)
            {
                (char chr, (int bri, int col_b, int col_f) col) temp_col = temp_draw.ElementAt(i).Key;
                Draw_Pixel((temp_col.chr, temp_col.col, temp_draw.ElementAt(i).Value.ToArray()));
            }
            Console.BackgroundColor = System.ConsoleColor.Black;
            Console.SetCursorPosition(0, 0);
        }

        ///<summary>
        ///Redraws a Pixel on a given Position
        ///</summary>
        public void Update_Pixel_at((int x, int y) pos)
        {
            bool draw = true;
            foreach ((char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos) X in pixel_live)
            {
                if ((X.pos.x == pos.x) && (X.pos.y == pos.y))
                {
                    draw = false;
                    Draw_Pixel_singular(X);
                    break;
                }
            }
            if (draw)
            {
                Draw_Pixel_singular(((char)0, (0, 0, 0), pos));
            }
        }


    }
}
