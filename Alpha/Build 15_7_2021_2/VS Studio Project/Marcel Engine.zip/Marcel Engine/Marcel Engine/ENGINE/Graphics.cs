﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Engine
{
    ///<summary>
    ///Graphics go brrrrr
    ///</summary>
    class Graphics
    {
        

        public Graphics()
        {
            
        }
        ///<summary>
        ///Its basically a Sprite Library, where you can have multiple Sprites.
        ///</summary>
        public class Sprite_Lib
        {
            ///<summary>
            ///A Dictionary of Sprites. You can add a Sprite and its name.
            ///</summary>
            public Dictionary<string, Sprite> Sprites;
            public Sprite_Lib()
            {
                Sprites = new Dictionary<string, Sprite>();
            }
        }

        ///<summary>
        ///A Sprite. Its this engines version of images.
        ///</summary>
        public class Sprite
        {
            ///<summary>
            ///Decides if the Sprite even has an image.
            ///</summary>
            public bool has_image { get;}
            ///<summary>
            ///The raw image data.
            ///</summary>
            public List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> image_data;
            ///<summary>
            ///The actual bordersize of the image.
            ///</summary>
            public (int x1, int y1, int x2, int y2) border;

            ///<summary>
            ///Says if the Sprite is centered.
            ///</summary>
            public bool centered { get; set; }

            ///<summary>
            ///A normal Sprite setter.
            ///</summary>
            public Sprite()
            {
                centered = false;
                border = (0,0,0,0);
                has_image = false;
                image_data = new List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)>();
            }
            ///<summary>
            ///Generates a Sprite with a preset Image. (You just enter the Filename and if its supposed to get centered.)
            ///</summary>
            public Sprite(string Filename, bool _centered)
            {
                border = (0, 0, 0, 0);
                has_image = false;
                image_data = new List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)>();
                SetImage_fromfile(Filename, _centered);
            }
            ///<summary>
            ///Imports the Sprite image from a file. (The files are .mesf files and can be created with my Sprite Editor)
            ///</summary>
            public void SetImage_fromfile (string filename, bool _centered)
            {
                /*
                Fileformat is:
                (x_size)|(y_size) // not needed lol.
                (brightness)|(col_b)|(col_f)|(relative_pos_x)|(relative_pos_y)
                (brightness)|(col_b)|(col_f)|(relative_pos_x)|(relative_pos_y)
                (brightness)|(col_b)|(col_f)|(relative_pos_x)|(relative_pos_y)
                (brightness)|(col_b)|(col_f)|(relative_pos_x)|(relative_pos_y)
                ...
                */
                centered = _centered;
                image_data = new List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)>();

                StreamReader reader = new StreamReader(filename);
                string[] temp = reader.ReadLine().Split('|');
                border = (0,0,0,0);

                int[] t;

                if (!reader.EndOfStream)
                {
                    temp = reader.ReadLine().Split('|');
                    t = new int[temp.Length];
                    for (int i = 0; i < temp.Length; i++)
                    {
                        t[i] = int.Parse(temp[i]);
                    }
                    border.x1 = t[3];
                    border.y1 = t[4];
                    border.x2 = t[3];
                    border.y2 = t[4];

                    image_data.Add(((char)0, (t[0], t[1], t[2]), (t[3], t[4])));
                }


                while (!reader.EndOfStream)
                {
                    temp = reader.ReadLine().Split('|');
                    t = new int[temp.Length];
                    for (int i = 0; i < temp.Length; i++)
                    {
                        t[i] = int.Parse(temp[i]);
                    }

                    if (t[3] < border.x1)
                    {
                        border.x1 = t[3];
                    }
                    if (t[3] > border.x2)
                    {
                        border.x2 = t[3];
                    }

                    if (t[4] < border.y1)
                    {
                        border.y1 = t[4];
                    }
                    if (t[4] > border.y2)
                    {
                        border.y2 = t[4];
                    }



                    image_data.Add(((char)0,(t[0], t[1], t[2]),(t[3], t[4])));
                }
                if (_centered)
                {
                    (char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos) pixel;
                    (int xm, int ym) move = (((border.x1 + border.x2) + 1) / 2, ((border.y1 + border.y2) + 1) / 2);
                    for (int i = 0; i < image_data.Count; i++)
                    {
                        pixel = image_data[i];

                        pixel.pos.x -= move.xm;
                        pixel.pos.y -= move.ym;


                        image_data[i] = pixel;
                    }
                }


                reader.Close();

            }
        }
    }
}
