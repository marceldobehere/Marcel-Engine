﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Engine
{
    ///<summary>
    ///Random data for Objects.
    ///<para /> Has an Object-Type Dictionary
    ///</summary>
    class _OBJ_Misc
    {
        private Dictionary<string, int> OBJ_Types;
        public _OBJ_Misc ()
        {
            Do_obj();
        }
        ///<summary>
        ///Here you can get the Typenumber of an Object with the Type String. (example: "Player" is typenum 1)
        ///</summary>
        public int Get_Typenum (string t)
        {
            return OBJ_Types[t];
        }

        private void Do_obj ()
        {
            OBJ_Types = new Dictionary<string, int>();
            OBJ_Types.Add("Player", 1);
            OBJ_Types.Add("Text", 2);
        }
    }


    ///<summary>
    ///Objects go brrrrrrr
    ///</summary>
    class _Object
    {
        ///<summary>
        ///A Player Object.
        ///</summary>
        public type_Player Player { get; set; }
        ///<summary>
        ///A Text Object.
        ///</summary>
        public type_Text Text { get; set; }
        ///<summary>
        ///Sets the active Subobject of this Object. (Look at the OBJ_MISC class!)
        ///</summary>
        public int Active_obj_type { get; set; }
        ///<summary>
        ///Sets the layer that the Object is on. (0 is backround. 1 is infront of 0 and 10 is infront of 5 etc)
        ///</summary>
        public int layer { get; set; }
        ///<summary>
        ///Decides if the Object gets shown
        ///</summary>
        public bool shown { get; set; }
        ///<summary>
        ///The position of the Object. It is a tuple.
        ///</summary>s
        public (int x, int y) position { get; set; }

        ///<summary>
        ///Decides if the Object gets updated next frame.
        ///</summary>
        public bool update_next_frame { get; set; }

        public _Object()
        {
            update_next_frame = true;
            Active_obj_type = -1;
            Player = new type_Player();
            Text = new type_Text();
            layer = 0;
            shown = true;
            position = (0, 0);
        }
        ///<summary>
        ///Updates the object in the screen buffer on the next frame
        ///</summary>
        public void Update()
        {
            update_next_frame = true;
            if (Active_obj_type == 2)
            {
                Text.Update_Text();
            }
        }
        ///<summary>
        ///Moves the Object. (Requires a tuple (x, y))
        ///</summary>
        public void Move((int x, int y) pos)
        {
            position = (position.x + pos.x, position.y + pos.y);
            Update();
        }
        ///<summary>
        ///Moves the Object on the X-Axis
        ///</summary>
        public void Move_x(int amount)
        {
            position = (position.x + amount, position.y);
            Update();
        }
        ///<summary>
        ///Moves the Object on the Y-Axis
        ///</summary>
        public void Move_y(int amount)
        {
            position = (position.x, position.y + amount);
            Update();
        }

        ///<summary>
        ///A Player Object. It can show Sprites and animate them and has an inbuilt Sprite Library.
        ///</summary>
        public class type_Player
        {
            ///<summary>
            ///Sets the active shown Sprite. (If its not being animated)
            ///</summary>
            public Graphics.Sprite active_sprite { get; set; }
            ///<summary>
            ///Sets the active shown Sprite. (If its being animated)
            ///</summary>
            public Graphics.Sprite active_animation_sprite { get; set; }
            ///<summary>
            ///A Sprite Library where you can add Sprites into, if you want to have different sprites saved in one Object.
            ///</summary>
            public Graphics.Sprite_Lib sprite_lib { get; set; }

            ///<summary>
            ///The rotation of the Player.
            ///</summary>
            public double rotation;
            ///<summary>
            ///The scale of the Player.
            ///</summary>
            public double scale;

            ///<summary>
            ///Tells if the Player Object has to be animated
            ///</summary>
            public bool sprite_animated;
            ///<summary>
            ///Here are the spriteframes that should be animated. You can add normal sprites to it.
            ///</summary>
            public Graphics.Sprite_Lib animation_lib { get; set; }
            ///<summary>
            ///The frame the animation is currently on.
            ///</summary>
            public int animation_frame;
            ///<summary>
            ///Sets how many frames should pass until the animation goes to the next frame. Defaults to 1
            ///</summary>
            public int animation_speed;

            private int animation_subcounter;

            public type_Player()
            {
                rotation = 0;
                scale = 1;
                sprite_lib = new Graphics.Sprite_Lib();
                active_sprite = new Graphics.Sprite();
                active_animation_sprite = new Graphics.Sprite();

                sprite_animated = false;
                animation_lib = new Graphics.Sprite_Lib();
                animation_frame = 0;
                animation_speed = 1;
                animation_subcounter = 0;
             }
            ///<summary>
            ///Tells the animation part that one frame has passed.
            ///</summary>
            public void Update_Animation()
            {
                if (animation_subcounter >= animation_speed)
                {
                    active_animation_sprite.og_image_data = animation_lib.Sprites.ElementAt(animation_frame).Value.og_image_data;
                    active_animation_sprite.rotation = rotation;
                    active_animation_sprite.scale = scale;
                    active_animation_sprite.Update_image();
                    animation_frame++;
                    if (animation_frame >= animation_lib.Sprites.Count)
                    {
                        animation_frame = 0;
                    }
                }
                //Update_Sprite();
                animation_subcounter++;
            }

            ///<summary>
            ///Updates the currently displayed Sprite. (Rotation and Scaling)
            ///</summary>
            public void Update_Sprite()
            {
                active_sprite.rotation = rotation;
                active_sprite.scale = scale;
                active_sprite.Update_image();
            }
        }

        ///<summary>
        ///A simple Text Object. It can show text.
        ///</summary>
        public class type_Text
        {
            ///<summary>
            ///Text to be displayed.
            ///</summary>
            public string text { get; set; }
            ///<summary>
            ///Colour of the text.
            ///</summary>
            public (int col_b, int col_f) text_col { get; set; }
            ///<summary>
            ///Charpixels (Just the data of the "sprite")
            ///</summary>
            public List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> charpixels;
            ///<summary>
            ///Decides if the backroundcolour of the text gets ignored and replaced by the pixel it is on.
            ///</summary>
            public bool transparent_backround { get; set; }

            public type_Text()
            {
                transparent_backround = false;
                text_col = (0,10);
                text = "";
                charpixels = new List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)>();
            }
            ///<summary>
            ///Updates the "Sprite" data of the text. Do this if you want to update the changes of text.
            ///</summary>
            public void Update_Text()
            {
                charpixels = new List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)>();
                int i = 0;
                foreach (char x in text)
                {
                    charpixels.Add((x,(0, text_col.col_b, text_col.col_f),(i, 0))); 
                    //Console.Title = $"TEST: {(char)x}";
                    i++;
                }
            }
            
        }
    }
}
