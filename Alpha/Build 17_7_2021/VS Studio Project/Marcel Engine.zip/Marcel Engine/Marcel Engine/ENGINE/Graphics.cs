﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Engine
{
    ///<summary>
    ///Graphics go brrrrr
    ///</summary>
    class Graphics
    {
        

        public Graphics()
        {
            
        }
        ///<summary>
        ///Its basically a Sprite Library, where you can have multiple Sprites.
        ///</summary>
        public class Sprite_Lib
        {
            ///<summary>
            ///A Dictionary of Sprites. You can add a Sprite and its name.
            ///</summary>
            public Dictionary<string, Sprite> Sprites;
            public Sprite_Lib()
            {
                Sprites = new Dictionary<string, Sprite>();
            }
        }

        ///<summary>
        ///A Sprite. Its this engines version of images.
        ///</summary>
        public class Sprite
        {
            ///<summary>
            ///Decides if the Sprite even has an image.
            ///</summary>
            public bool has_image { get;}
            ///<summary>
            ///The raw image data.
            ///</summary>
            public List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> image_data;
            ///<summary>
            ///The raw original image data.
            ///</summary>
            public List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> og_image_data;
            ///<summary>
            ///The actual bordersize of the image.
            ///</summary>
            public (int x1, int y1, int x2, int y2) border;

            ///<summary>
            ///Says if the Sprite is centered.
            ///</summary>
            public bool centered { get; set; }

            ///<summary>
            ///Sets the sprites rotation. (Update the Sprite to see changes)
            ///</summary>
            public double rotation { get; set; }

            ///<summary>
            ///Sets the sprites scale. (Update the Sprite to see changes)
            ///</summary>
            public double scale { get; set; }

            ///<summary>
            ///A normal Sprite setter.
            ///</summary>
            public Sprite()
            {
                rotation = 0;
                scale = 1;
                centered = false;
                border = (0,0,0,0);
                has_image = false;
                og_image_data = new List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)>();
                Update_image();
            }

            ///<summary>
            ///Generates a Sprite with a preset Image. (You just enter the Filename and if its supposed to get centered.)
            ///</summary>
            public Sprite(string Filename, bool _centered)
            {
                rotation = 0;
                scale = 1;
                border = (0, 0, 0, 0);
                has_image = false;
                og_image_data = new List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)>();
                SetImage_fromfile(Filename, _centered);
                Update_image();
            }
            ///<summary>
            ///Imports the Sprite image from a file. (The files are .mesf files and can be created with my Sprite Editor)
            ///</summary>
            public void SetImage_fromfile (string filename, bool _centered)
            {
                /*
                Fileformat is:
                (x_size)|(y_size) // not needed lol.
                (brightness)|(col_b)|(col_f)|(relative_pos_x)|(relative_pos_y)
                (brightness)|(col_b)|(col_f)|(relative_pos_x)|(relative_pos_y)
                (brightness)|(col_b)|(col_f)|(relative_pos_x)|(relative_pos_y)
                (brightness)|(col_b)|(col_f)|(relative_pos_x)|(relative_pos_y)
                ...
                */
                centered = _centered;
                image_data = new List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)>();

                StreamReader reader = new StreamReader(filename);
                string[] temp = reader.ReadLine().Split('|');
                border = (0,0,0,0);

                int[] t;

                if (!reader.EndOfStream)
                {
                    temp = reader.ReadLine().Split('|');
                    t = new int[temp.Length];
                    for (int i = 0; i < temp.Length; i++)
                    {
                        t[i] = int.Parse(temp[i]);
                    }
                    border.x1 = t[3];
                    border.y1 = t[4];
                    border.x2 = t[3];
                    border.y2 = t[4];

                    og_image_data.Add(((char)0, (t[0], t[1], t[2]), (t[3], t[4])));
                }


                while (!reader.EndOfStream)
                {
                    temp = reader.ReadLine().Split('|');
                    t = new int[temp.Length];
                    for (int i = 0; i < temp.Length; i++)
                    {
                        t[i] = int.Parse(temp[i]);
                    }

                    if (t[3] < border.x1)
                    {
                        border.x1 = t[3];
                    }
                    if (t[3] > border.x2)
                    {
                        border.x2 = t[3];
                    }

                    if (t[4] < border.y1)
                    {
                        border.y1 = t[4];
                    }
                    if (t[4] > border.y2)
                    {
                        border.y2 = t[4];
                    }



                    og_image_data.Add(((char)0,(t[0], t[1], t[2]),(t[3], t[4])));
                }


                if (_centered)
                {
                    (char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos) pixel;
                    (int xm, int ym) move = (((border.x1 + border.x2) + 1) / 2, ((border.y1 + border.y2) + 1) / 2);
                    for (int i = 0; i < og_image_data.Count; i++)
                    {
                        pixel = og_image_data[i];

                        pixel.pos.x -= move.xm;
                        pixel.pos.y -= move.ym;


                        og_image_data[i] = pixel;
                    }
                }


                reader.Close();

                Update_image();
            }


            ///<summary>
            ///Updates changes like rotation or scaling.
            ///</summary>
            public void Update_image()
            {
                image_data = new List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)>();
                //image_data.AddRange(og_image_data);

                foreach ((char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos) pixel in Scale_List(og_image_data, scale))
                {
                    (int x, int y) rotpos = Rotate_pos(pixel.pos, rotation);
                    image_data.Add((pixel.chr, pixel.col, rotpos));
                }



            }


            ///<summary>
            ///Scales a List of Pixeldata
            ///</summary>
            public List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> Scale_List (List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> inp, double toscale)
            {
                if (toscale == 1)
                {
                    return inp;
                }
                else
                {
                    List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> scaled;
                    scaled = new List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)>();
                    foreach ((char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos) pixel in inp)
                    {
                        scaled.AddRange(Scale_Point(pixel, toscale));
                    }

                    return scaled;
                }
            }


            ///<summary>
            ///Scales a single Pixel
            ///</summary>
            public List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> Scale_Point((char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos) pixel, double toscale)
            {
                List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> scaled;
                scaled = new List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)>();

                for (int y = 0; y < Math.Ceiling(toscale); y++)
                {
                    for (int x = 0; x < Math.Ceiling(toscale); x++)
                    {
                        scaled.Add((pixel.chr, pixel.col, ((int)Math.Ceiling(pixel.pos.x * toscale + x), (int)Math.Ceiling(pixel.pos.y * toscale + y))));
                    }
                }

                return scaled;
            }




            ///<summary>
            ///Rotates a 2D Point around 0,0 with degrees in °. (not radian)
            ///</summary>
            public (int x, int y) Rotate_pos((int x, int y) pos, double degrees)
            {
                if (degrees == 0)
                {
                    return pos;
                }
                else
                {
                    (int x, int y) new_pos;
                    double conv = degrees * (Math.PI / 180);
                    double radius = Math.Sqrt(pos.x * pos.x + pos.y * pos.y);

                    double angle = Math.Asin(pos.y / radius);
                    new_pos.y = (int)Math.Round(Math.Sin(angle + conv * (pos.x < 0 ? -1 : 1)) * radius);
                    new_pos.x = (int)Math.Round(Math.Cos(angle + conv * (pos.x < 0 ? -1 : 1)) * radius * (pos.x < 0 ? -1 : 1));

                    return new_pos;
                }
            }

        }
    }
}
