﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;

namespace Engine
{
    ///<summary>
    ///Internal Stuff
    ///</summary>
    class Engine_Internal
    {
        ///<summary>
        ///Boot Object (Basically the Splashscreen)
        ///</summary>
        public _Object boot_obj;
        public bool fastboot;
        private Graphics.Sprite boot_sprite;
        public Engine_Internal()
        {
            fastboot = false;
            string image_dir = "Engine\\Internals\\";
            image_dir += "Splashscreen.mesf";
            boot_sprite = new Graphics.Sprite(image_dir, false);
            boot_obj = new _Object();
            boot_obj.Active_obj_type = 1;
            boot_obj.Player.active_sprite = boot_sprite;
            boot_obj.position = (5, 5);
        }

        public class Debug_Logger
        {
            static int max_times = 6;
            public Debug_Logger()
            {
                clear(0);

                Process p = new Process();
                p.StartInfo.WorkingDirectory = "Engine\\Internals\\Debug";
                p.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Normal;
                p.StartInfo.FileName = "logreader.exe";
                p.Start();
                //System.Diagnostics.Process.Start("Engine\\Internals\\Debug\\logreader.exe", "");
            }

            public void Wait(int _t)
            {
                if (_t < max_times)
                {
                    try
                    {
                        StreamReader reader = new StreamReader("Engine\\Internals\\Debug\\Debug.out");
                        bool temp = !reader.EndOfStream;
                        reader.Close();
                        if (temp)
                        {
                            System.Threading.Thread.Sleep(10);
                            Wait(_t + 1);
                        }
                    }
                    catch //(Exception t)
                    {
                        System.Threading.Thread.Sleep(10);
                        Wait(_t + 1);
                    }
                }
            }


            public void Log(string data)
            {
                Log_(data, 0);
            }

            private void Log_(string data, int _t)
            {
                if (_t < max_times)
                {
                    try
                    {
                        Wait(0);
                        StreamWriter writer = new StreamWriter("Engine\\Internals\\Debug\\Debug.out");
                        writer.WriteLine(data);
                        writer.Close();
                    }
                    catch //(Exception t)
                    {
                        Log_(data, _t + 1);
                    }
                }
            }

            static void clear(int _t)
            {
                if (_t < max_times)
                {
                    try
                    {
                        StreamWriter writer = new StreamWriter("Engine\\Internals\\Debug\\Debug.out");
                        writer.Close();
                    }
                    catch //(Exception t)
                    {
                        clear(_t + 1);
                    }
                }
            }

            public void Set_title(string name)
            {
                Log("#TITLE " + name);
            }
        }
    }





}
