﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;

namespace Testing_the_engine_lol
{
    class Program
    {
        static void Main(string[] args)
        {

            Main_Engine engine = new Main_Engine((100, 100, 10));
            Screen scr = engine.display;
            Graphics test = engine.graphics;
            _OBJ_Misc obj = new _OBJ_Misc();

            //create new Object
            _Object Player = new _Object();
            // Set Object type to Player
            Player.Active_obj_type = obj.Get_Typenum("Player");

            // Add Sprite Library
            Graphics.Sprite_Lib spr = new Graphics.Sprite_Lib();
            // Add Player Sprite with an Image
            spr.Sprites.Add("Player_1", new Graphics.Sprite("Engine\\Sprites\\Animation test\\P_middle.mesf"));
            // Set Players active Sprite to "Player_1" Sprite
            Player.Player.active_sprite = spr.Sprites["Player_1"];
            // Set the layer of Player to 1
            Player.layer = 1;

            // Add Player animation frames
            Player.Player.animation_lib.Sprites.Add("1", new Graphics.Sprite("Engine\\Sprites\\Animation test\\P_middle.mesf"));
            Player.Player.animation_lib.Sprites.Add("2", new Graphics.Sprite("Engine\\Sprites\\Animation test\\P_left.mesf"));
            Player.Player.animation_lib.Sprites.Add("3", new Graphics.Sprite("Engine\\Sprites\\Animation test\\P_middle.mesf"));
            Player.Player.animation_lib.Sprites.Add("4", new Graphics.Sprite("Engine\\Sprites\\Animation test\\P_right.mesf"));

            // Set the animation speed to once every 10 frames
            Player.Player.animation_speed = 10;

            // Turn on animation
            Player.Player.sprite_animated = true;

            _Object P2 = new _Object();
            P2.Active_obj_type = 1;
            spr.Sprites.Add("Player_2", new Graphics.Sprite("Engine\\Sprites\\sprite2.mesf"));
            P2.Player.active_sprite = spr.Sprites["Player_2"];
            P2.layer = 3;


            _Object Test_txt = new _Object();
            Test_txt.Active_obj_type = obj.Get_Typenum("Text");
            Test_txt.Text.text = "Hello!";
            Test_txt.Text.Update_Text();
            Test_txt.layer = 2;
            Test_txt.Text.transparent_backround = true;

            P2.position = (20, 0);
            Player.position = (2, 4);

            engine.Add_Obj_to_scene(Player);
            engine.Add_Obj_to_scene(P2);
            engine.Add_Obj_to_scene(Test_txt);

            engine.Render_Frame(100);



            ConsoleKey key;
            key = System.ConsoleKey.Attention;

            while (key != System.ConsoleKey.Q)
            {
                (int x, int y) POS_2 = P2.position;

                Player.Move_x((key == System.ConsoleKey.RightArrow) ? 1 : 0);
                Player.Move_x((key == System.ConsoleKey.LeftArrow) ? -1 : 0);
                Player.Move_y((key == System.ConsoleKey.DownArrow) ? 1 : 0);
                Player.Move_y((key == System.ConsoleKey.UpArrow) ? -1 : 0);

                POS_2.x += (key == System.ConsoleKey.D) ? 1 : 0;
                POS_2.x -= (key == System.ConsoleKey.A) ? 1 : 0;
                POS_2.y += (key == System.ConsoleKey.S) ? 1 : 0;
                POS_2.y -= (key == System.ConsoleKey.W) ? 1 : 0;

                if (key == System.ConsoleKey.Spacebar)
                {
                    Player.shown = !Player.shown;
                }
                if (key == System.ConsoleKey.D2)
                {
                    Player.Player.sprite_animated = !Player.Player.sprite_animated;
                }
                if (key == System.ConsoleKey.D1)
                {
                    P2.shown = !P2.shown;
                }

                P2.position = POS_2;
                engine.Render_Frame(20);
                if (Console.KeyAvailable)
                {
                    key = engine.Get_Key();
                }
                else
                {
                    key = System.ConsoleKey.Attention;
                }
            }

            //engine.Rem_Obj_from_scene(Test_txt);

            Graphics.Sprite amogus = new Graphics.Sprite();
            amogus.SetImage_fromfile("Engine\\Sprites\\among us.mesf");
            P2.Player.active_sprite = amogus;

            Player.Player.sprite_animated = false;
            Player.position = (5, 5);
            P2.position = (30, 5);
            Test_txt.position = (10, 2);

            while (true)
            {
                (int x, int y) POS = Player.position;
                (int x, int y) POS2 = P2.position;
                (int x, int y) POS3 = Test_txt.position;

                for (int i = 0; i < 20; i++)
                {
                    POS.x++;
                    POS2.x++;
                    POS3.x++;
                    Player.position = POS;
                    P2.position = POS2;
                    Test_txt.position = POS3;
                    engine.Render_Frame(-1);
                }

                for (int i = 0; i < 20; i++)
                {
                    POS.y++;
                    POS2.y++;
                    POS3.y++;
                    Player.position = POS;
                    P2.position = POS2;
                    Test_txt.position = POS3;
                    engine.Render_Frame(-1);
                }

                for (int i = 0; i < 20; i++)
                {
                    POS.x--;
                    POS2.x--;
                    POS3.x--;
                    Player.position = POS;
                    P2.position = POS2;
                    Test_txt.position = POS3;
                    engine.Render_Frame(-1);
                }

                for (int i = 0; i < 20; i++)
                {
                    POS.y--;
                    POS2.y--;
                    POS3.y--;
                    Player.position = POS;
                    P2.position = POS2;
                    Test_txt.position = POS3;
                    engine.Render_Frame(-1);
                }
            }



        }
    }
}
