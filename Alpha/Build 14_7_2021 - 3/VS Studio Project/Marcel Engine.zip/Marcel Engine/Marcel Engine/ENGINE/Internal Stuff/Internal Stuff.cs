﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Engine
{
    ///<summary>
    ///Internal Stuff
    ///</summary>
    class Engine_Internal
    {
        ///<summary>
        ///Boot Object (Basically the Splashscreen)
        ///</summary>
        public _Object boot_obj;
        private Graphics.Sprite boot_sprite;
        public Engine_Internal()
        {
            string image_dir = "Engine\\Internals\\";
            image_dir += "Splashscreen.mesf";
            boot_sprite = new Graphics.Sprite(image_dir);
            boot_obj = new _Object();
            boot_obj.Active_obj_type = 1;
            boot_obj.Player.active_sprite = boot_sprite;
            boot_obj.position = (5,5);
        }
    }



    
    
}
