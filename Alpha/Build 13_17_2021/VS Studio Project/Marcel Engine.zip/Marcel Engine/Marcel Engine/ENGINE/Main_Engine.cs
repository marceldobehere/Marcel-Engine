﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine
{
    class Main_Engine
    {
        public Screen display;
        public Graphics graphics;

        static List<_Object> active_objects;


        public ConsoleKey Get_Key()
        {
            Console.SetCursorPosition(0, 0);
            ConsoleKey temp = Console.ReadKey().Key;
            display.Update_Pixel_at((0, 0));
            return temp;
        }

        public Main_Engine((int x, int y, int size) size)
        {
            Console.CursorVisible = false;
            display = new Screen(size);
            graphics = new Graphics();
            frames = 0;
            last_x_frames_time = DateTime.Now;
            active_objects = new List<_Object>();
        }

        public void Add_Obj_to_scene(_Object obj)
        {
            active_objects.Add(obj);
        }

        public void Rem_Obj_from_scene(_Object obj)
        {
            active_objects.Remove(obj);
        }

        static int frames;
        static DateTime last_x_frames_time;

        public void Render_Frame(double fps_it_should_have)
        {
            double time_min;
            DateTime time_where_frame_should_be_done = DateTime.Now;
            if (fps_it_should_have != -1)
            {
                time_min = 1 / fps_it_should_have;
                time_where_frame_should_be_done = time_where_frame_should_be_done.AddSeconds(time_min);
            }

            frames++;
            if (frames > 30)
            {
                frames = 0;
                DateTime diff = DateTime.Now;
                double temp = diff.Subtract(last_x_frames_time).TotalSeconds;
                last_x_frames_time = DateTime.Now;
                display.Update_FPS(30 / temp);
                //Console.Title = $"FPS: {Math.Round(20 / temp)}";
            }



            int max_layer = -1;
            Dictionary<int, List<_Object>> obj_to_render_layered = new Dictionary<int, List<_Object>>();
            foreach(_Object OBJ in active_objects)
            {
                if (OBJ.shown)
                {

                    if (!obj_to_render_layered.ContainsKey(OBJ.layer))
                    {
                        obj_to_render_layered.Add(OBJ.layer, new List<_Object>());
                        if (max_layer < OBJ.layer)
                        {
                            max_layer = OBJ.layer;
                        }
                    }
                    obj_to_render_layered[OBJ.layer].Add(OBJ);


                }
            }

            display.Render_Objects(obj_to_render_layered, max_layer);

            display.Frame();
            if (fps_it_should_have != -1)
            {
                while (DateTime.Now < time_where_frame_should_be_done)
                {

                }
            }
        }
        /*static void Main()
        {
            


            //Console.ReadLine();
        }
        */
    }
}
