﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;



namespace Engine
{
    ///<summary>
    ///Screen go brrrrrrrr and oooof
    ///</summary>
    class Screen
    {
        ///<summary>
        ///Don't ask
        ///</summary>
        [DllImport("user32.dll")]
        public static extern bool ShowWindow(System.IntPtr hWnd, int cmdShow);
        ///<summary>
        ///Maxmizes the Window
        ///</summary>
        private static void Maximize()
        {
            Process p = Process.GetCurrentProcess();
            ShowWindow(p.MainWindowHandle, 3);
        }

        ///<summary>
        ///brightness of the colours go brrrrrr
        ///</summary>
        static string[] col_char = { "░░", "▒▒", "▓▓" };
        ///<summary>
        ///The colour list. Basically just all consolecolours but with an index
        ///</summary>
        static System.ConsoleColor[] cols =
            {
                System.ConsoleColor.Black,
                System.ConsoleColor.Blue,
                System.ConsoleColor.Cyan,
                System.ConsoleColor.DarkBlue,
                System.ConsoleColor.DarkCyan,
                System.ConsoleColor.DarkGray,
                System.ConsoleColor.DarkGreen,
                System.ConsoleColor.DarkMagenta,
                System.ConsoleColor.DarkRed,
                System.ConsoleColor.DarkYellow,
                System.ConsoleColor.Gray,
                System.ConsoleColor.Green,
                System.ConsoleColor.Magenta,
                System.ConsoleColor.Red,
                System.ConsoleColor.White,
                System.ConsoleColor.Yellow,
            };


        ///<summary>
        ///Size of the Window
        ///</summary>
        public static (int x, int y, int size) winsize;
        ///<summary>
        ///fps count
        ///</summary>
        public static double fps { get; set; }

        ///<summary>
        ///Updates the title with the current fps
        ///</summary>
        public void Update_FPS(double fps_)
        {
            fps = fps_;
            Console.Title = $"Marcel Engine - FPS: {Math.Round(fps, 1)}";
        }


        ///<summary>
        ///Screendata.
        ///</summary>
        List<(char chr, (int bri, int col_b, int col_f))>[,] Screen_data;
        ///<summary>
        ///Screendata. OBJ
        ///</summary>
        List<_Object>[,] Screen_data_obj;

        ///<summary>
        ///Shows Positions that need to be updated.
        ///</summary>
        List<((char chr, (int bri, int col_b, int col_f)) coldata, (int x, int y) pos)> update_pos;

        ///<summary>
        ///Just an Object that claims all the backroundpixels.
        ///</summary>
        private _Object backround;

        ///<summary>
        ///Initialises the screen with a size
        ///</summary>
        public Screen((int x, int y, int size) size, bool maximize)
        {
            fps = 1;
            Console.Title = "Marcel Engine";
            Console.Clear();
            Console.WriteLine("Marcel Engine loading...");

            if (size.x > Console.LargestWindowWidth)
            {
                Console.WriteLine($"Decreasing X-Size from {size.x} to {Console.LargestWindowWidth}.");
                size.x = Console.LargestWindowWidth;
            }
            if (size.y > Console.LargestWindowHeight)
            {
                Console.WriteLine($"Decreasing Y-Size from {size.y} to {Console.LargestWindowHeight}.");
                size.y = Console.LargestWindowHeight;
            }
            winsize = size;
            Console.SetWindowSize(1, 1);
            ConsoleHelper.SetCurrentFont("Consolas", (short)winsize.size);
            Console.SetBufferSize(winsize.x * 2, winsize.y);
            Console.SetWindowSize(winsize.x * 2 + 2, winsize.y + 2);

            backround = new _Object();
            //update_pos = new List<((char chr, int bri, int col_b, int col_f) coldata, (int x, int y) pos)>();
            update_pos = new List<((char chr, (int bri, int col_b, int col_f)) coldata, (int x, int y) pos)>();
            Clear_Screen_Memory();


            if (maximize)
            {
                Maximize();
            }

            //logger = new Engine_Internal.Debug_Logger();
            //logger.Set_title("Screen Debugger");




            Console.CursorVisible = false;
            //Console.ReadLine();
            Cls();
        }


        ///<summary>
        ///Clears the Screen Memory.
        ///</summary>
        public void Clear_Screen_Memory()
        {
            Screen_data = new List<(char chr, (int bri, int col_b, int col_f))>[winsize.x, winsize.y];
            Screen_data_obj = new List<_Object>[winsize.x, winsize.y];
            for (int y = 0; y < winsize.y; y++)
            {
                for (int x = 0; x < winsize.x; x++)
                {
                    Screen_data[x, y] = new List<(char chr, (int bri, int col_b, int col_f))>() { (' ', (0, 0, 0)) };
                    Screen_data_obj[x, y] = new List<_Object>() { backround };
                }
            }
        }


        ///<summary>
        ///Clears the Screen.
        ///</summary>
        public void Clear_Screen_and_Memory()
        {
            update_pos = new List<((char chr, (int bri, int col_b, int col_f)) coldata, (int x, int y) pos)>();
            for (int y = 0; y < winsize.y; y++)
            {
                for (int x = 0; x < winsize.x; x++)
                {
                    Update_Pixel((x, y));
                }
            }
            Screen_data = new List<(char chr, (int bri, int col_b, int col_f))>[winsize.x, winsize.y];
            Screen_data_obj = new List<_Object>[winsize.x, winsize.y];
            for (int y = 0; y < winsize.y; y++)
            {
                for (int x = 0; x < winsize.x; x++)
                {
                    Screen_data[x, y] = new List<(char chr, (int bri, int col_b, int col_f))>() { (' ', (0, 0, 0)) };
                    Screen_data_obj[x, y] = new List<_Object>() { backround };
                }
            }
            Frame();
        }





        ///<summary>
        ///Draws a List of Pixels with the same colour but different positions on screen.
        ///</summary>
        public void Draw_Pixels((char chr, (int bri, int col_b, int col_f) col, (int x, int y)[] pos) data)
        {
            Console.BackgroundColor = cols[data.col.col_b];
            Console.ForegroundColor = cols[data.col.col_f];
            if (data.chr == 0)
            {
                string draw_c = col_char[data.col.bri];
                foreach ((int x, int y) pos in data.pos)
                {

                    Console.SetCursorPosition(pos.x * 2, pos.y);
                    Console.Write(draw_c);

                }
            }
            else
            {
                foreach ((int x, int y) pos in data.pos)
                {

                    Console.SetCursorPosition(pos.x * 2, pos.y);
                    Console.Write(data.chr + " ");

                }
            }
        }

        ///<summary>
        ///Updates a Pixel.
        ///</summary>
        public void Update_Pixel((int x, int y) pos)
        {
            if (!((pos.x < 0) || (pos.y < 0) || (pos.x >= winsize.x) || (pos.y >= winsize.y)))
            {
                int indx = -1;

                for (int i = 0; i < update_pos.Count; i++)
                {
                    if ((update_pos[i].pos.x == pos.x) && (update_pos[i].pos.y == pos.y))
                    {
                        indx = i;
                        break;
                    }
                }

                if (indx == -1)
                {
                    update_pos.Add((Get_Pixel_at(pos), pos));
                }

                //else
                //{
                //    update_pos[indx] = (Get_Pixel_at(pos), pos);
                //}
            }
        }

        public (char chr, (int bri, int col_b, int col_f)) Get_Pixel_at((int x, int y) pos)
        {
            (char chr, (int bri, int col_b, int col_f)) x = Screen_data[pos.x, pos.y][Screen_data[pos.x, pos.y].Count - 1];
            return (x.chr, (x.Item2.bri, x.Item2.col_b, x.Item2.col_f));
        }



        public void Set_Pixel((char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos) data, _Object obj)
        {
            if (!((data.pos.x < 0) || (data.pos.y < 0) || (data.pos.x >= winsize.x) || (data.pos.y >= winsize.y)))
            {
                Update_Pixel(data.pos);
                if (Screen_data_obj[data.pos.x, data.pos.y].Contains(obj))
                {
                    int indx2 = Screen_data_obj[data.pos.x, data.pos.y].IndexOf(obj);
                    Screen_data_obj[data.pos.x, data.pos.y].RemoveAt(indx2);
                    Screen_data[data.pos.x, data.pos.y].RemoveAt(indx2);
                }

                //Screen_data[data.pos.x, data.pos.y].A
                int max = Screen_data_obj[data.pos.x, data.pos.y].Count;
                int indx = max - 1;
                if (indx >= 0)
                {
                    while (Screen_data_obj[data.pos.x, data.pos.y][indx].layer > obj.layer && indx > 0)
                    {
                        indx--;
                    }
                }
                indx++;
                Screen_data[data.pos.x, data.pos.y].Insert(indx, (data.chr, data.col));
                Screen_data_obj[data.pos.x, data.pos.y].Insert(indx, obj);

            }
        }

        ///<summary>
        ///Reset/Clears the screen
        ///</summary>
        public void Cls()
        {
            Console.BackgroundColor = System.ConsoleColor.Black;
            Console.ForegroundColor = System.ConsoleColor.Black;
            Console.Clear();
        }

        ///<summary>
        ///Renders a Frame.
        ///</summary>
        public void Frame()
        {
            Compare_and_Draw();
            update_pos = new List<((char chr, (int bri, int col_b, int col_f)) coldata, (int x, int y) pos)>();
        }


        ///<summary>
        ///Gets all Pixels from a given Object.
        ///</summary>
        public void Del_Pixels_from_Obj(_Object OBJ)
        {
            for (int y = 0; y < winsize.y; y++)
            {
                for (int x = 0; x < winsize.x; x++)
                {
                    if (Screen_data_obj[x, y].Contains(OBJ))
                    {
                        Update_Pixel((x, y));
                        int indx = Screen_data_obj[x, y].IndexOf(OBJ);
                        Screen_data[x, y].RemoveAt(indx);
                        Screen_data_obj[x, y].RemoveAt(indx);
                    }
                }
            }
        }




        ///<summary>
        ///Gets all Pixels from a given Object.
        ///</summary>
        public List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> Get_Pixels_from_Object(_Object OBJ, bool to_screen)
        {
            List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> pixels_from_obj = new List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)>();

            List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> te;

            if (OBJ.Active_obj_type == 1)
            {

                if (OBJ.Player.sprite_animated)
                {
                    te = OBJ.Player.active_animation_sprite.image_data;
                }
                else
                {
                    te = OBJ.Player.active_sprite.image_data;
                }

                if (to_screen)
                {
                    for (int i = 0; i < te.Count; i++)
                    {
                        Set_Pixel((te[i].chr, te[i].col, ((OBJ.position.x + te[i].pos.x), (OBJ.position.y + te[i].pos.y))), OBJ);
                    }
                }
                else
                {
                    for (int i = 0; i < te.Count; i++)
                    {
                        pixels_from_obj.Add((te[i].chr, te[i].col, ((te[i].pos.x + OBJ.position.x), (te[i].pos.y + OBJ.position.y))));
                    }
                }

            }
            if (OBJ.Active_obj_type == 2)
            {
                if (OBJ.Text.transparent_backround)
                {
                    te = OBJ.Text.charpixels;
                    if (to_screen)
                    {
                        for (int i = 0; i < te.Count; i++)
                        {
                            (char chr, (int bri, int col_b, int col_f) col) pixel2 = Get_Pixel_at(((te[i].pos.x + OBJ.position.x), (te[i].pos.y + OBJ.position.y)));
                            Set_Pixel((te[i].chr, (te[i].col.bri, pixel2.col.col_b, te[i].col.col_f), ((te[i].pos.x + OBJ.position.x), (te[i].pos.y + OBJ.position.y))), OBJ);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < te.Count; i++)
                        {
                            (char chr, (int bri, int col_b, int col_f) col) pixel2 = Get_Pixel_at(((te[i].pos.x + OBJ.position.x), (te[i].pos.y + OBJ.position.y)));
                            pixels_from_obj.Add((te[i].chr, (te[i].col.bri, pixel2.col.col_b, te[i].col.col_f), ((te[i].pos.x + OBJ.position.x), (te[i].pos.y + OBJ.position.y))));
                        }
                    }
                }
                else
                {
                    te = OBJ.Text.charpixels;
                    if (to_screen)
                    {
                        for (int i = 0; i < te.Count; i++)
                        {
                            Set_Pixel((te[i].chr, te[i].col, ((te[i].pos.x + OBJ.position.x), (te[i].pos.y + OBJ.position.y))), OBJ);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < te.Count; i++)
                        {
                            pixels_from_obj.Add((te[i].chr, te[i].col, ((te[i].pos.x + OBJ.position.x), (te[i].pos.y + OBJ.position.y))));
                        }
                    }
                }
            }



            return pixels_from_obj;
        }





        ///<summary>
        ///Renders a List of Objects into the Screen.
        ///</summary>
        public void Render_Objects(List<_Object> objects)
        {
            foreach (_Object OBJ in objects)
            {
                if (OBJ.Active_obj_type == 1)
                {
                    if (OBJ.Player.sprite_animated)
                    {
                        OBJ.Player.Update_Animation();
                        OBJ.update_next_frame = true;
                    }
                }
                if (OBJ.Active_obj_type == 2)
                {
                    if (OBJ.Text.transparent_backround)
                    {
                        OBJ.update_next_frame = true;
                    }
                }


                if (OBJ.update_next_frame)
                {
                    OBJ.update_next_frame = false;
                    Del_Pixels_from_Obj(OBJ);
                    if (OBJ.shown)
                    {
                        Get_Pixels_from_Object(OBJ, true);
                    }
                }

            }
        }

        ///<summary>
        ///Draws the changes of the live pixel list and the old pixel array
        ///</summary>
        private void Compare_and_Draw()
        {
            List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> pixel_draw = new List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)>();
            for (int i = 0; i < update_pos.Count; i++)
            {
                if (update_pos[i].coldata != Get_Pixel_at(update_pos[i].pos))
                {
                    pixel_draw.Add((Get_Pixel_at(update_pos[i].pos).chr, Get_Pixel_at(update_pos[i].pos).Item2, update_pos[i].pos));
                }
            }

            Dictionary<(char chr, (int bri, int col_b, int col_f) col), List<(int x, int y)>> temp_draw;
            temp_draw = new Dictionary<(char chr, (int bri, int col_b, int col_f) col), List<(int x, int y)>>();

            for (int i = 0; i < pixel_draw.Count; i++)
            {
                (char chr, (int bri, int col_b, int col_f) col) indx = (pixel_draw[i].chr, pixel_draw[i].col);
                if (!temp_draw.ContainsKey(indx))
                {
                    temp_draw.Add(indx, new List<(int x, int y)>());
                }
                temp_draw[indx].Add(pixel_draw[i].pos);
            }

            for (int i = 0; i < temp_draw.Count; i++)
            {
                (char chr, (int bri, int col_b, int col_f) col) temp_col = temp_draw.ElementAt(i).Key;
                Draw_Pixels((temp_col.chr, temp_col.col, temp_draw.ElementAt(i).Value.ToArray()));
            }
            Console.BackgroundColor = System.ConsoleColor.Black;
            Console.SetCursorPosition(0, 0);
        }
    }
}
