﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine
{
    ///<summary>
    ///Engine go brrrrrr
    ///</summary>
    class Main_Engine
    {
        ///<summary>
        ///The Screen of the Engine.
        ///</summary>
        public Screen display;
        ///<summary>
        ///The graphics data.
        ///</summary>
        public Graphics graphics;
        ///<summary>
        ///Internal Stuff.
        ///</summary>
        private Engine_Internal internal_;
        ///<summary>
        ///The active Scene.
        ///</summary>
        public Scene active_scene;

        ///<summary>
        ///Gets a ConsoleKey Key input. (And doesnt mess with the screen while doing it)
        ///</summary>
        public ConsoleKey Get_Key()
        {
            Console.SetCursorPosition(0, 0);
            ConsoleKey temp = Console.ReadKey().Key;
            display.Update_Pixel((0, 0));
            return temp;
        }
        ///<summary>
        ///Gets a Char Keyinput. (And doesnt mess with the screen while doing it)
        ///</summary>
        public char Get_Key_char()
        {
            Console.SetCursorPosition(0, 0);
            char temp = Console.ReadKey().KeyChar;
            display.Update_Pixel((0, 0));
            return temp;
        }
        
        ///<summary>
        ///Inititalises the Engine with a given Screensize and if it should start maximized.
        ///</summary>
        public Main_Engine((int x, int y, int size) size, bool maximize)
        {
            Console.CursorVisible = false;
            display = new Screen(size, maximize);
            graphics = new Graphics();
            frames = 0;
            last_x_frames_time = DateTime.Now;
            active_scene = new Scene("Main");
            internal_ = new Engine_Internal();
            //internal_.fastboot = true;
            if (!internal_.fastboot)
            {
                Add_Obj_to_scene(internal_.boot_obj);
                Render_Frame(0.5);
                Rem_Obj_from_scene(internal_.boot_obj);
                Render_Frame(-1);
            }
        }


        ///<summary>
        ///Returns if two Objects collide with each other
        ///</summary>
        public bool Obj_collision(_Object a, _Object b)
        {
            if (a.layer == b.layer)
            {
                List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> obj_b_pixels = display.Get_Pixels_from_Object(b, false);
                List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> obj_a_pixels = display.Get_Pixels_from_Object(a, false);
                for (int i = 0; i < obj_a_pixels.Count; i++)
                {
                    for (int i2 = 0; i2 < obj_b_pixels.Count; i2++)
                    {
                        if ((obj_a_pixels[i].pos.x == obj_b_pixels[i2].pos.x) && (obj_a_pixels[i].pos.y == obj_b_pixels[i2].pos.y))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            else
            {
                return false;
            }
        }

        ///<summary>
        ///Sets a new active scene.
        ///</summary>
        public void Set_New_Active_Scene(Scene new_scene)
        {
            active_scene = new_scene;
            for (int i = 0; i < active_scene.objects.Count; i++)
            {
                active_scene.objects[i].Update();
            }
            display.Clear_Screen_and_Memory();
        }

        ///<summary>
        ///Adds an Object to the scene.
        ///</summary>
        public void Add_Obj_to_scene(_Object obj)
        {
            active_scene.objects.Add(obj);
        }
        ///<summary>
        ///Removes an Object from the scene.
        ///</summary>s
        public void Rem_Obj_from_scene(_Object obj)
        {
            display.Del_Pixels_from_Obj(obj);
            active_scene.objects.Remove(obj);
        }

        static int frames;
        static DateTime last_x_frames_time;


        ///<summary>
        ///Renders a Frame with the fps it should approximately have.
        ///</summary>
        public void Render_Frame(double fps_it_should_have)
        {
            double time_min;
            DateTime time_where_frame_should_be_done = DateTime.Now;
            if (fps_it_should_have != -1)
            {
                time_min = 1 / fps_it_should_have;
                time_where_frame_should_be_done = time_where_frame_should_be_done.AddSeconds(time_min);
            }

            frames++;
            if (frames > 30)
            {
                frames = 0;
                DateTime diff = DateTime.Now;
                double temp = diff.Subtract(last_x_frames_time).TotalSeconds;
                last_x_frames_time = DateTime.Now;
                display.Update_FPS(30 / temp);
            }

            display.Render_Objects(active_scene.objects);

            display.Frame();
            if (fps_it_should_have != -1)
            {
                while (DateTime.Now < time_where_frame_should_be_done)
                {

                }
            }
        }
        /*static void Main()
        {
            


            //Console.ReadLine();
        }
        */
    }
}
