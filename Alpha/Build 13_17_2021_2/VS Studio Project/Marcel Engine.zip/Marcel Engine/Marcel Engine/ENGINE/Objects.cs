﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Engine
{
    class _OBJ_Misc
    {
        private Dictionary<string, int> OBJ_Types;
        public _OBJ_Misc ()
        {
            Do_obj();
        }

        public int Get_Typenum (string t)
        {
            return OBJ_Types[t];
        }

        private void Do_obj ()
        {
            OBJ_Types = new Dictionary<string, int>();
            OBJ_Types.Add("Player", 1);
            OBJ_Types.Add("Text", 2);
        }
    }



    class _Object
    {
        public type_Player Player { get; set; }
        public type_Text Text { get; set; }
        public int Active_obj_type { get; set; }
        public int layer { get; set; }
        public bool shown { get; set; }
        public (int x, int y) position { get; set; }

        public _Object()
        {
            Active_obj_type = -1;
            Player = new type_Player();
            Text = new type_Text();
            layer = 0;
            shown = true;
            position = (0, 0);
        }

        public void Move((int x, int y) pos)
        {
            position = (position.x + pos.x, position.y + pos.y);
        }
        public void Move_x(int amount)
        {
            position = (position.x + amount, position.y);
        }
        public void Move_y(int amount)
        {
            position = (position.x, position.y + amount);
        }

        public class type_Player
        {
            public Graphics.Sprite active_sprite { get; set; }
            public Graphics.Sprite_Lib sprite_lib { get; set; }

            public type_Player()
            {
                sprite_lib = new Graphics.Sprite_Lib();
                active_sprite = null;
            }
        }


        public class type_Text
        {
            public string text { get; set; }
            public (int col_b, int col_f) text_col { get; set; }
            public List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> charpixels;
            public bool transparent_backround { get; set; }

            public type_Text()
            {
                transparent_backround = false;
                text_col = (0,10);
                text = "";
                charpixels = new List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)>();
            }

            public void Update_Text()
            {
                charpixels = new List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)>();
                int i = 0;
                foreach (char x in text)
                {
                    charpixels.Add((x,(0, text_col.col_b, text_col.col_f),(i, 0))); 
                    //Console.Title = $"TEST: {(char)x}";
                    i++;
                }
            }
            
        }
    }
}
