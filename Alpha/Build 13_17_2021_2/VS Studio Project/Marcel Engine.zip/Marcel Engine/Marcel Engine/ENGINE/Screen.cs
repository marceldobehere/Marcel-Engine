﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Runtime.InteropServices;



namespace Engine
{
    class Screen
    {
        [DllImport("user32.dll")]
        public static extern bool ShowWindow(System.IntPtr hWnd, int cmdShow);
        private static void Maximize()
        {
            Process p = Process.GetCurrentProcess();
            ShowWindow(p.MainWindowHandle, 3);
        }


        static string[] col_char = { "░░", "▒▒", "▓▓" };
        static System.ConsoleColor[] cols =
            {
                System.ConsoleColor.Black,
                System.ConsoleColor.Blue,
                System.ConsoleColor.Cyan,
                System.ConsoleColor.DarkBlue,
                System.ConsoleColor.DarkCyan,
                System.ConsoleColor.DarkGray,
                System.ConsoleColor.DarkGreen,
                System.ConsoleColor.DarkMagenta,
                System.ConsoleColor.DarkRed,
                System.ConsoleColor.DarkYellow,
                System.ConsoleColor.Gray,
                System.ConsoleColor.Green,
                System.ConsoleColor.Magenta,
                System.ConsoleColor.Red,
                System.ConsoleColor.White,
                System.ConsoleColor.Yellow,
            };



        public static (int x, int y, int size) winsize;
        public static double fps { get; set; }

        static List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> pixel_live;
        static (char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)[] pixel_old;

        public void Update_FPS(double fps_)
        {
            fps = fps_;
            Console.Title = $"Marcel Engine - FPS: {Math.Round(fps, 1)}";
        }

        public Screen((int x, int y, int size) size)
        {
            fps = 1;
            winsize = size;
            Console.Title = "Marcel Engine";
            Console.Clear();
            Console.WriteLine("Marcel Engine loading up...");
            Console.SetWindowSize(1, 1);

            ConsoleHelper.SetCurrentFont("Consolas", (short)winsize.size);
            Console.SetBufferSize(winsize.x * 2, winsize.y);
            Console.SetWindowSize(Console.LargestWindowWidth, Console.LargestWindowHeight);

            pixel_old = new(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)[0];
            pixel_live = new List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)>();

            Maximize();

            Console.CursorVisible = false;
            //Console.ReadLine();
            Cls();
        }


        public void Draw_Pixel((char chr, (int bri, int col_b, int col_f) col, (int x, int y)[] pos) data)
        {
            Console.BackgroundColor = cols[data.col.col_b];
            Console.ForegroundColor = cols[data.col.col_f];
            if (data.chr == 0)
            {
                string draw_c = col_char[data.col.bri];
                foreach ((int x, int y) pos in data.pos)
                {

                    Console.SetCursorPosition(pos.x * 2, pos.y);
                    Console.Write(draw_c);

                }
            }
            else
            {
                foreach ((int x, int y) pos in data.pos)
                {

                    Console.SetCursorPosition(pos.x * 2, pos.y);
                    Console.Write(data.chr + " ");

                }
            }
        }


        public void Draw_Pixel_singular((char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos) data)
        {
            Console.BackgroundColor = cols[data.col.col_b];
            Console.ForegroundColor = cols[data.col.col_f];


            Console.SetCursorPosition(data.pos.x * 2, data.pos.y);
            if (data.chr == 0)
            {
                Console.Write(col_char[data.col.bri]);
            }
            else
            {
                Console.Write(data.chr + " ");
            }


        }



        public void Add_Pixel((char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos) data)
        {
            if (!((data.pos.x < 0) || (data.pos.y < 0) || (data.pos.x >= winsize.x) || (data.pos.y >= winsize.y)))
            {
                int indx = -1;

                for (int i = 0; i < pixel_live.Count; i++)
                {
                    if ((pixel_live[i].pos.x == data.pos.x) && (pixel_live[i].pos.y == data.pos.y))
                    {
                        indx = i;
                        break;
                    }
                }

                if (indx == -1)
                {
                    pixel_live.Add(data);
                }
                else
                {
                    pixel_live[indx] = data;
                }
            }
        }


        public void Remove_Pixel((int x, int y) pos)
        {
            for (int i = 0; i < pixel_live.Count; i++)
            {
                if ((pixel_live[i].pos.x == pos.x) && (pixel_live[i].pos.y == pos.y))
                {
                    pixel_live.RemoveAt(i);
                    i--;
                    break;
                }
            }
        }
        public (char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos) Get_Pixel_at ((int x, int y) pos)
        {
            for (int i = 0; i < pixel_live.Count; i++)
            {
                if ((pixel_live[i].pos.x == pos.x) && (pixel_live[i].pos.y == pos.y))
                {
                    return pixel_live[i];
                }
            }

            return ((char)0,(0,0,0),pos);
        }



        public void Cls()
        {
            Console.BackgroundColor = System.ConsoleColor.Black;
            Console.ForegroundColor = System.ConsoleColor.Black;
            Console.Clear();
        }


        public void Frame()
        {
            Compare_and_Draw();

            pixel_old = pixel_live.ToArray();
        }

        public void Render_Objects(Dictionary<int, List<_Object>> objects, int max_layer)
        {
            pixel_live = new List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)>();

            for (int i = 0; i <= max_layer; i++)
            {
                if (objects.ContainsKey(i))
                {
                    Render_Object(objects[i]);
                }
            }
        }

        private void Render_Object(List<_Object> objects)
        {
            foreach (_Object OBJ in objects)
            {
                if (OBJ.Active_obj_type == 1)
                {
                    foreach ((char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos) pixel in OBJ.Player.active_sprite.image_data)
                    {
                        Add_Pixel((pixel.chr, pixel.col, ((pixel.pos.x + OBJ.position.x), (pixel.pos.y + OBJ.position.y))));
                    }
                    continue;
                }
                if (OBJ.Active_obj_type == 2)
                {
                    if (OBJ.Text.transparent_backround)
                    {
                        foreach ((char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos) pixel in OBJ.Text.charpixels)
                        {
                            (char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos) pixel2 = Get_Pixel_at(pixel.pos);
                            Add_Pixel((pixel.chr, (pixel.col.bri, pixel2.col.col_b, pixel.col.col_f), ((pixel.pos.x + OBJ.position.x), (pixel.pos.y + OBJ.position.y))));
                        }
                        continue;
                    }
                    else
                    {
                        foreach ((char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos) pixel in OBJ.Text.charpixels)
                        {
                            Add_Pixel((pixel.chr, pixel.col, ((pixel.pos.x + OBJ.position.x), (pixel.pos.y + OBJ.position.y))));
                        }
                        continue;
                    }
                }
            }
        }


        private void Compare_and_Draw()
        {
            List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)> pixel_draw = new List<(char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos)>();
            for (int i = 0; i < pixel_live.Count; i++)
            {
                bool t = true;
                (char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos) Y = pixel_live[i];
                for (int i2 = 0; i2 < pixel_old.Length; i2++)
                {
                    if ((pixel_old[i2].col.bri == Y.col.bri) && (pixel_old[i2].col.col_b == Y.col.col_b) && (pixel_old[i2].col.col_f == Y.col.col_f) && (pixel_old[i2].pos.x == Y.pos.x) && (pixel_old[i2].pos.y == Y.pos.y) && (pixel_old[i2].chr == Y.chr))
                    {
                        t = false;
                        break;
                    }
                }
                if (t)
                {
                    pixel_draw.Add(pixel_live[i]);
                }
            }


            for (int i2 = 0; i2 < pixel_old.Length; i2++)
            {
                (int x, int y) X = pixel_old[i2].pos;
                bool nhere = true;

                for (int i = 0; i < pixel_live.Count; i++)
                {
                    (int x, int y) temp = pixel_live[i].pos;
                    if ((X.x == temp.x) && (X.y == temp.y))
                    {
                        nhere = false;
                        break;
                    }
                }

                if (nhere)
                {
                    pixel_draw.Add(((char)0, (0, 0, 0), X));
                }
            }


            Dictionary<(char chr, (int bri, int col_b, int col_f) col), List<(int x, int y)>> temp_draw;
            temp_draw = new Dictionary<(char chr, (int bri, int col_b, int col_f) col), List<(int x, int y)>>();

            for (int i = 0; i < pixel_draw.Count; i++)
            {
                (char chr, (int bri, int col_b, int col_f) col) indx = (pixel_draw[i].chr, pixel_draw[i].col);
                if (!temp_draw.ContainsKey(indx))
                {
                    temp_draw.Add(indx, new List<(int x, int y)>());
                }
                temp_draw[indx].Add(pixel_draw[i].pos);
            }

            for (int i = 0; i < temp_draw.Count; i++)
            {
                (char chr, (int bri, int col_b, int col_f) col) temp_col = temp_draw.ElementAt(i).Key;
                Draw_Pixel((temp_col.chr, temp_col.col, temp_draw.ElementAt(i).Value.ToArray()));
            }
            Console.BackgroundColor = System.ConsoleColor.Black;
            Console.SetCursorPosition(0, 0);
        }


        public void Update_Pixel_at((int x, int y) pos)
        {
            bool draw = true;
            foreach ((char chr, (int bri, int col_b, int col_f) col, (int x, int y) pos) X in pixel_live)
            {
                if ((X.pos.x == pos.x) && (X.pos.y == pos.y))
                {
                    draw = false;
                    Draw_Pixel_singular(X);
                    break;
                }
            }
            if (draw)
            {
                Draw_Pixel_singular(((char)0, (0, 0, 0), pos));
            }
        }


    }
}
