﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;

namespace Testing_the_engine_lol
{
    class Program
    {
        static void Main(string[] args)
        {

            Main_Engine engine = new Main_Engine((100, 100, 10));
            Screen scr = engine.display;
            Graphics test = engine.graphics;
            _OBJ_Misc obj = new _OBJ_Misc();
            Input inp = new Input();

            //create new Object
            _Object Player = new _Object();
            // Set Object type to Player
            Player.Active_obj_type = obj.Get_Typenum("Player");

            // Add Sprite Library
            Graphics.Sprite_Lib spr = new Graphics.Sprite_Lib();
            // Add Player Sprite with an Image
            spr.Sprites.Add("Player_1", new Graphics.Sprite("Engine\\Sprites\\Animation test\\P_middle.mesf", true));
            // Set Players active Sprite to "Player_1" Sprite
            Player.Player.active_sprite = spr.Sprites["Player_1"];
            // Set the layer of Player to 1
            Player.layer = 2;

            // Add Player animation frames
            Player.Player.animation_lib.Sprites.Add("1", new Graphics.Sprite("Engine\\Sprites\\Animation test\\P_middle.mesf", true));
            Player.Player.animation_lib.Sprites.Add("2", new Graphics.Sprite("Engine\\Sprites\\Animation test\\P_left.mesf", true));
            Player.Player.animation_lib.Sprites.Add("3", new Graphics.Sprite("Engine\\Sprites\\Animation test\\P_middle.mesf", true));
            Player.Player.animation_lib.Sprites.Add("4", new Graphics.Sprite("Engine\\Sprites\\Animation test\\P_right.mesf", true));

            // Set the animation speed to once every 10 frames
            Player.Player.animation_speed = 10;

            // Turn on animation
            Player.Player.sprite_animated = true;

            // New Player Object P2
            _Object P2 = new _Object();
            P2.Active_obj_type = 1;
            spr.Sprites.Add("Player_2", new Graphics.Sprite("Engine\\Sprites\\sprite2.mesf", false));
            P2.Player.active_sprite = spr.Sprites["Player_2"];
            P2.layer = 4;

            // New Text Object saying Hello!
            _Object Test_txt = new _Object();
            Test_txt.Active_obj_type = obj.Get_Typenum("Text");
            Test_txt.Text.text = "Hello!";
            Test_txt.Text.Update_Text();
            Test_txt.layer = 3;
            Test_txt.Text.transparent_backround = true;

            // New Text Object for testing collision
            _Object TXT_2 = new _Object();
            TXT_2.Active_obj_type = obj.Get_Typenum("Text");
            TXT_2.Text.text = "Collision? -";
            TXT_2.Text.Update_Text();
            TXT_2.layer = 5;
            TXT_2.Text.transparent_backround = true;

            // Set all positions
            P2.position = (20, 2);
            TXT_2.position = (0, 1);
            Player.position = (10, 10);

            // Add all Objects to the scene.
            engine.Add_Obj_to_scene(Player);
            engine.Add_Obj_to_scene(P2);
            engine.Add_Obj_to_scene(Test_txt);
            engine.Add_Obj_to_scene(TXT_2);

            // Render Frame
            engine.Render_Frame(100);

            //Engine_Internal.Debug_Logger logger = new Engine_Internal.Debug_Logger();
            //logger.Set_title("Test Title");
            //logger.Log("This is a Test!");

            //Player.Player.rotation = 0;

            _Object player2 = Player.Clone();

            Scene testscene = new Scene("Test");
            testscene.objects.Add(player2);

            Scene og_scene = engine.active_scene.Clone();
            engine.active_scene = og_scene;
            //inp.KeyPressed(Input.Key.KEY_GOES_HERE) checks if a given Key is pressed
            while (!inp.KeyPressed(Input.Key.Q))
            {
                (int x, int y) POS_2 = P2.position;

                //Move Player according to input
                if (inp.KeyPressed(Input.Key.RightArrow))
                {
                    Player.Move_x(1);
                    player2.Move_x(1);
                }
                if (inp.KeyPressed(Input.Key.LeftArrow))
                {
                    Player.Move_x(-1);
                    player2.Move_x(-1);
                }
                if (inp.KeyPressed(Input.Key.DownArrow))
                {
                    Player.Move_y(1);
                    player2.Move_y(1);
                }
                if (inp.KeyPressed(Input.Key.UpArrow))
                {
                    Player.Move_y(-1);
                    player2.Move_y(-1);
                }

                POS_2.x += inp.KeyPressed(Input.Key.D) ? 1 : 0;
                POS_2.x -= inp.KeyPressed(Input.Key.A) ? 1 : 0;
                POS_2.y += inp.KeyPressed(Input.Key.S) ? 1 : 0;
                POS_2.y -= inp.KeyPressed(Input.Key.W) ? 1 : 0;

                if (inp.KeyPressed(Input.Key.W) || inp.KeyPressed(Input.Key.A) || inp.KeyPressed(Input.Key.S) || inp.KeyPressed(Input.Key.D))
                {
                    P2.Update();
                }

                if (inp.KeyPressed(Input.Key.Three))
                {
                    //Player.rotation--;
                    //logger.Log("Rotation Left");
                    Player.Player.rotation--;
                    Player.Player.Update_Sprite();
                    Player.Update();
                }
                if (inp.KeyPressed(Input.Key.Four))
                {
                    //Player.rotation++;
                    //logger.Log("Rotation Right");
                    Player.Player.rotation++;
                    Player.Player.Update_Sprite();
                    Player.Update();
                }

                if (inp.KeyPressed(Input.Key.Five))
                {
                    Player.Player.scale -= 0.5;
                    Player.Player.Update_Sprite();
                    Player.Update();
                }
                if (inp.KeyPressed(Input.Key.Six))
                {
                    Player.Player.scale += 0.5;
                    Player.Player.Update_Sprite();
                    Player.Update();
                }




                if (inp.KeyPressed(Input.Key.Spacebar))
                {
                    Player.shown = !Player.shown;
                    Player.Update();
                    System.Threading.Thread.Sleep(100);
                }
                if (inp.KeyPressed(Input.Key.Two))
                {
                    Player.Player.sprite_animated = !Player.Player.sprite_animated;
                    Player.Update();
                    System.Threading.Thread.Sleep(100);
                }
                if (inp.KeyPressed(Input.Key.One))
                {
                    P2.shown = !P2.shown;
                    P2.Update();
                    System.Threading.Thread.Sleep(100);
                }

                //Shows Collision of Player and Player2 Objects.
                TXT_2.Text.text = $"Collision? {engine.Obj_collision(Player, P2)} | rot: {Math.Round(Player.Player.rotation,2)}° | frame: {Player.Player.animation_frame}";
                TXT_2.Update();


                P2.position = POS_2;

                if (inp.KeyPressed(Input.Key.Zero))
                {
                    if (engine.active_scene.name == "Main")
                    {
                        engine.Set_New_Active_Scene(testscene);
                    }
                    else
                    {
                        engine.Set_New_Active_Scene(og_scene);
                    }
                    System.Threading.Thread.Sleep(1000);
                }

                engine.Render_Frame(30);
            }





            //engine.Rem_Obj_from_scene(Test_txt);

            Graphics.Sprite amogus = new Graphics.Sprite();
            amogus.SetImage_fromfile("Engine\\Sprites\\among us.mesf", true);
            P2.Player.active_sprite = amogus;
            P2.shown = true;

            TXT_2.shown = false;


            Player.Player.active_sprite = new Graphics.Sprite("Engine\\Sprites\\Animation test\\P_middle.mesf", false);
            Player.Player.sprite_animated = false;
            Player.position = (5, 5);
            P2.position = (30, 5);
            Test_txt.position = (10, 2);

            while (true)
            {
                (int x, int y) POS = Player.position;
                (int x, int y) POS2 = P2.position;
                (int x, int y) POS3 = Test_txt.position;

                for (int i = 0; i < 20; i++)
                {
                    POS.x++;
                    POS2.x++;
                    POS3.x++;
                    Player.position = POS;
                    P2.position = POS2;
                    P2.Player.rotation++;
                    P2.Player.Update_Sprite();
                    Test_txt.position = POS3;
                    Player.Update();
                    P2.Update();
                    Test_txt.Update();
                    engine.Render_Frame(-1);
                }

                for (int i = 0; i < 20; i++)
                {
                    POS.y++;
                    POS2.y++;
                    POS3.y++;
                    Player.position = POS;
                    P2.position = POS2;
                    P2.Player.rotation++;
                    P2.Player.Update_Sprite();
                    Test_txt.position = POS3;
                    Player.Update();
                    P2.Update();
                    Test_txt.Update();
                    engine.Render_Frame(-1);
                }

                for (int i = 0; i < 20; i++)
                {
                    POS.x--;
                    POS2.x--;
                    POS3.x--;
                    Player.position = POS;
                    P2.position = POS2;
                    P2.Player.rotation++;
                    P2.Player.Update_Sprite();
                    Test_txt.position = POS3;
                    Player.Update();
                    P2.Update();
                    Test_txt.Update();
                    engine.Render_Frame(-1);
                }

                for (int i = 0; i < 20; i++)
                {
                    POS.y--;
                    POS2.y--;
                    POS3.y--;
                    Player.position = POS;
                    P2.position = POS2;
                    P2.Player.rotation++;
                    P2.Player.Update_Sprite();
                    Test_txt.position = POS3;
                    Player.Update();
                    P2.Update();
                    Test_txt.Update();
                    engine.Render_Frame(-1);
                }
            }



        }
    }
}
