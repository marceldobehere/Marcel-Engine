﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;
using Object = Engine.Object;

namespace Testing_the_engine_lol
{
    
    class Program
    {
        static void Main()
        {
            //Setting up the Engine
            MainEngine engine = new MainEngine((100, 100, 10), true, "Consolas");
            //Setting up the Input
            Input inp = new Input();





            //Gameloop
            while (true)
            {


                //Render Frame with ~30FPS
                engine.RenderFrame(30);
            }
        }
    }
}
