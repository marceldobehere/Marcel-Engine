﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;

namespace Logger_Test
{
    class Program
    {
        static void aMain(string[] args)
        {
            //Sets the logger up
            Internals.Debug_Logger logger = new Internals.Debug_Logger();

            //Sets a Title
            logger.Set_title("Test Title");

            //Logs a Message
            logger.Log("This is a Test Message!");

            //Logs a Message
            logger.Log("Another one!");

            //will tell the logger to stop logging (Not implemented in the engine yet...)
            logger.Log("#END");

        }
    }
}
